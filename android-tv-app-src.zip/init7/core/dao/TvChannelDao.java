package ch.andeo.init7.core.dao;

import androidx.lifecycle.LiveData;
import ch.andeo.init7.core.model.TvChannel;
import java.util.List;

public interface TvChannelDao {
  void bulkInsert(List<TvChannel> paramList);
  
  void bulkUpdate(List<TvChannel> paramList);
  
  void deleteAll();
  
  LiveData<List<TvChannel>> getAll(String paramString);
  
  List<TvChannel> getAllNow();
  
  List<TvChannel> getAllSync();
  
  List<TvChannel> getAllSync(String paramString);
  
  TvChannel getChannel(String paramString);
  
  LiveData<Integer> getChannelCount();
  
  TvChannel getFirst(String paramString);
  
  LiveData<TvChannel> getWithOffset(int paramInt);
  
  void update(TvChannel paramTvChannel);
}
