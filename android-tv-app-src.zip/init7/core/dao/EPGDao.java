package ch.andeo.init7.core.dao;

import androidx.lifecycle.LiveData;
import ch.andeo.init7.core.model.EPGInfo;
import java.util.List;

public interface EPGDao {
  void add(List<EPGInfo> paramList);
  
  void deletePKs(List<String> paramList);
  
  EPGInfo find(String paramString);
  
  List<EPGInfo> findByStartTsConstraint(String paramString, long paramLong1, long paramLong2);
  
  LiveData<List<EPGInfo>> getByChannel(String paramString, long paramLong);
  
  EPGInfo getEPGInTime(String paramString, long paramLong);
  
  EPGInfo getFirstEPGAfter(String paramString, long paramLong);
  
  EPGInfo getFirstEPGBefore(String paramString, long paramLong);
  
  void update(List<EPGInfo> paramList);
}
