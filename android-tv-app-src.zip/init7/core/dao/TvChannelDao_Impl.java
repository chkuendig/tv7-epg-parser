package ch.andeo.init7.core.dao;

import android.database.Cursor;
import androidx.lifecycle.LiveData;
import androidx.room.EntityDeletionOrUpdateAdapter;
import androidx.room.EntityInsertionAdapter;
import androidx.room.InvalidationTracker;
import androidx.room.RoomDatabase;
import androidx.room.RoomSQLiteQuery;
import androidx.room.SharedSQLiteStatement;
import androidx.room.util.CursorUtil;
import androidx.room.util.DBUtil;
import androidx.sqlite.db.SupportSQLiteStatement;
import ch.andeo.init7.core.model.TvChannel;
import java.util.ArrayList;
import java.util.List;

public final class TvChannelDao_Impl implements TvChannelDao {
  private final RoomDatabase __db;
  
  private final EntityInsertionAdapter __insertionAdapterOfTvChannel;
  
  private final SharedSQLiteStatement __preparedStmtOfDeleteAll;
  
  private final EntityDeletionOrUpdateAdapter __updateAdapterOfTvChannel;
  
  public TvChannelDao_Impl(RoomDatabase paramRoomDatabase) {
    this.__db = paramRoomDatabase;
    this.__insertionAdapterOfTvChannel = new Object(this, paramRoomDatabase);
    this.__updateAdapterOfTvChannel = new Object(this, paramRoomDatabase);
    this.__preparedStmtOfDeleteAll = new Object(this, paramRoomDatabase);
  }
  
  public void bulkInsert(List<TvChannel> paramList) {
    this.__db.assertNotSuspendingTransaction();
    this.__db.beginTransaction();
    try {
      this.__insertionAdapterOfTvChannel.insert(paramList);
      this.__db.setTransactionSuccessful();
      return;
    } finally {
      this.__db.endTransaction();
    } 
  }
  
  public void bulkUpdate(List<TvChannel> paramList) {
    this.__db.assertNotSuspendingTransaction();
    this.__db.beginTransaction();
    try {
      this.__updateAdapterOfTvChannel.handleMultiple(paramList);
      this.__db.setTransactionSuccessful();
      return;
    } finally {
      this.__db.endTransaction();
    } 
  }
  
  public void deleteAll() {
    this.__db.assertNotSuspendingTransaction();
    supportSQLiteStatement = this.__preparedStmtOfDeleteAll.acquire();
    this.__db.beginTransaction();
    try {
      supportSQLiteStatement.executeUpdateDelete();
      this.__db.setTransactionSuccessful();
      return;
    } finally {
      this.__db.endTransaction();
      this.__preparedStmtOfDeleteAll.release(supportSQLiteStatement);
    } 
  }
  
  public LiveData<List<TvChannel>> getAll(String paramString) {
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT * FROM TvChannel ORDER BY CASE languageCode WHEN ? THEN langordernum ELSE ordernum END", 1);
    if (paramString == null) {
      roomSQLiteQuery.bindNull(1);
    } else {
      roomSQLiteQuery.bindString(1, paramString);
    } 
    InvalidationTracker invalidationTracker = this.__db.getInvalidationTracker();
    Object object = new Object(this, roomSQLiteQuery);
    return invalidationTracker.createLiveData(new String[] { "TvChannel" }, false, object);
  }
  
  public List<TvChannel> getAllNow() {
    List<TvChannel> list;
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT * FROM TvChannel ORDER BY ordernum", 0);
    this.__db.assertNotSuspendingTransaction();
    Cursor cursor = DBUtil.query(this.__db, roomSQLiteQuery, false);
    try {
      int j = CursorUtil.getColumnIndexOrThrow(cursor, "uuid");
      int k = CursorUtil.getColumnIndexOrThrow(cursor, "name");
      int m = CursorUtil.getColumnIndexOrThrow(cursor, "hd");
      int n = CursorUtil.getColumnIndexOrThrow(cursor, "multicastSrc");
      int i1 = CursorUtil.getColumnIndexOrThrow(cursor, "hlsSrc");
      int i2 = CursorUtil.getColumnIndexOrThrow(cursor, "epgId");
      int i3 = CursorUtil.getColumnIndexOrThrow(cursor, "logoUrl");
      int i4 = CursorUtil.getColumnIndexOrThrow(cursor, "ordernum");
      int i5 = CursorUtil.getColumnIndexOrThrow(cursor, "langordernum");
      int i6 = CursorUtil.getColumnIndexOrThrow(cursor, "countryCode");
      int i7 = CursorUtil.getColumnIndexOrThrow(cursor, "languageCode");
      int i8 = CursorUtil.getColumnIndexOrThrow(cursor, "hasReplay");
      int i9 = CursorUtil.getColumnIndexOrThrow(cursor, "lastEtag");
      int i = CursorUtil.getColumnIndexOrThrow(cursor, "lastEPGUpdate");
      try {
        list = new ArrayList(cursor.getCount());
        while (true) {
          if (cursor.moveToNext()) {
            boolean bool;
            TvChannel tvChannel = new TvChannel();
            tvChannel.uuid = cursor.getString(j);
            tvChannel.name = cursor.getString(k);
            if (cursor.getInt(m) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            tvChannel.hd = bool;
            tvChannel.multicastSrc = cursor.getString(n);
            tvChannel.hlsSrc = cursor.getString(i1);
            tvChannel.epgId = cursor.getString(i2);
            tvChannel.logoUrl = cursor.getString(i3);
            tvChannel.ordernum = cursor.getInt(i4);
            tvChannel.langordernum = cursor.getInt(i5);
            tvChannel.countryCode = cursor.getString(i6);
            tvChannel.languageCode = cursor.getString(i7);
            if (cursor.getInt(i8) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            tvChannel.hasReplay = bool;
            tvChannel.lastEtag = cursor.getString(i9);
            tvChannel.lastEPGUpdate = cursor.getLong(i);
            list.add(tvChannel);
            continue;
          } 
          cursor.close();
          roomSQLiteQuery.release();
          return list;
        } 
      } finally {}
    } finally {}
    cursor.close();
    roomSQLiteQuery.release();
    throw list;
  }
  
  public List<TvChannel> getAllSync() {
    List<TvChannel> list;
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT * FROM TvChannel", 0);
    this.__db.assertNotSuspendingTransaction();
    Cursor cursor = DBUtil.query(this.__db, roomSQLiteQuery, false);
    try {
      int j = CursorUtil.getColumnIndexOrThrow(cursor, "uuid");
      int k = CursorUtil.getColumnIndexOrThrow(cursor, "name");
      int m = CursorUtil.getColumnIndexOrThrow(cursor, "hd");
      int n = CursorUtil.getColumnIndexOrThrow(cursor, "multicastSrc");
      int i1 = CursorUtil.getColumnIndexOrThrow(cursor, "hlsSrc");
      int i2 = CursorUtil.getColumnIndexOrThrow(cursor, "epgId");
      int i3 = CursorUtil.getColumnIndexOrThrow(cursor, "logoUrl");
      int i4 = CursorUtil.getColumnIndexOrThrow(cursor, "ordernum");
      int i5 = CursorUtil.getColumnIndexOrThrow(cursor, "langordernum");
      int i6 = CursorUtil.getColumnIndexOrThrow(cursor, "countryCode");
      int i7 = CursorUtil.getColumnIndexOrThrow(cursor, "languageCode");
      int i8 = CursorUtil.getColumnIndexOrThrow(cursor, "hasReplay");
      int i9 = CursorUtil.getColumnIndexOrThrow(cursor, "lastEtag");
      int i = CursorUtil.getColumnIndexOrThrow(cursor, "lastEPGUpdate");
      try {
        list = new ArrayList(cursor.getCount());
        while (true) {
          if (cursor.moveToNext()) {
            boolean bool;
            TvChannel tvChannel = new TvChannel();
            tvChannel.uuid = cursor.getString(j);
            tvChannel.name = cursor.getString(k);
            if (cursor.getInt(m) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            tvChannel.hd = bool;
            tvChannel.multicastSrc = cursor.getString(n);
            tvChannel.hlsSrc = cursor.getString(i1);
            tvChannel.epgId = cursor.getString(i2);
            tvChannel.logoUrl = cursor.getString(i3);
            tvChannel.ordernum = cursor.getInt(i4);
            tvChannel.langordernum = cursor.getInt(i5);
            tvChannel.countryCode = cursor.getString(i6);
            tvChannel.languageCode = cursor.getString(i7);
            if (cursor.getInt(i8) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            tvChannel.hasReplay = bool;
            tvChannel.lastEtag = cursor.getString(i9);
            tvChannel.lastEPGUpdate = cursor.getLong(i);
            list.add(tvChannel);
            continue;
          } 
          cursor.close();
          roomSQLiteQuery.release();
          return list;
        } 
      } finally {}
    } finally {}
    cursor.close();
    roomSQLiteQuery.release();
    throw list;
  }
  
  public List<TvChannel> getAllSync(String paramString) {
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT * FROM TvChannel ORDER BY CASE languageCode WHEN ? THEN langordernum ELSE ordernum END", 1);
    if (paramString == null) {
      roomSQLiteQuery.bindNull(1);
    } else {
      roomSQLiteQuery.bindString(1, paramString);
    } 
    this.__db.assertNotSuspendingTransaction();
    Cursor cursor = DBUtil.query(this.__db, roomSQLiteQuery, false);
    try {
      int m = CursorUtil.getColumnIndexOrThrow(cursor, "uuid");
      int j = CursorUtil.getColumnIndexOrThrow(cursor, "name");
      int k = CursorUtil.getColumnIndexOrThrow(cursor, "hd");
      int n = CursorUtil.getColumnIndexOrThrow(cursor, "multicastSrc");
      int i1 = CursorUtil.getColumnIndexOrThrow(cursor, "hlsSrc");
      int i2 = CursorUtil.getColumnIndexOrThrow(cursor, "epgId");
      int i3 = CursorUtil.getColumnIndexOrThrow(cursor, "logoUrl");
      int i4 = CursorUtil.getColumnIndexOrThrow(cursor, "ordernum");
      int i5 = CursorUtil.getColumnIndexOrThrow(cursor, "langordernum");
      int i6 = CursorUtil.getColumnIndexOrThrow(cursor, "countryCode");
      int i7 = CursorUtil.getColumnIndexOrThrow(cursor, "languageCode");
      int i8 = CursorUtil.getColumnIndexOrThrow(cursor, "hasReplay");
      int i9 = CursorUtil.getColumnIndexOrThrow(cursor, "lastEtag");
      int i = CursorUtil.getColumnIndexOrThrow(cursor, "lastEPGUpdate");
      try {
        ArrayList arrayList = new ArrayList(cursor.getCount());
        while (true) {
          if (cursor.moveToNext()) {
            boolean bool;
            TvChannel tvChannel = new TvChannel();
            tvChannel.uuid = cursor.getString(m);
            tvChannel.name = cursor.getString(j);
            if (cursor.getInt(k) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            tvChannel.hd = bool;
            tvChannel.multicastSrc = cursor.getString(n);
            tvChannel.hlsSrc = cursor.getString(i1);
            tvChannel.epgId = cursor.getString(i2);
            tvChannel.logoUrl = cursor.getString(i3);
            tvChannel.ordernum = cursor.getInt(i4);
            tvChannel.langordernum = cursor.getInt(i5);
            tvChannel.countryCode = cursor.getString(i6);
            tvChannel.languageCode = cursor.getString(i7);
            if (cursor.getInt(i8) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            tvChannel.hasReplay = bool;
            tvChannel.lastEtag = cursor.getString(i9);
            tvChannel.lastEPGUpdate = cursor.getLong(i);
            arrayList.add(tvChannel);
            continue;
          } 
          cursor.close();
          roomSQLiteQuery.release();
          return arrayList;
        } 
      } finally {}
    } finally {}
    cursor.close();
    roomSQLiteQuery.release();
    throw paramString;
  }
  
  public TvChannel getChannel(String paramString) {
    roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT * FROM TvChannel WHERE uuid = ?", 1);
    if (paramString == null) {
      roomSQLiteQuery.bindNull(1);
    } else {
      roomSQLiteQuery.bindString(1, paramString);
    } 
    this.__db.assertNotSuspendingTransaction();
    cursor = DBUtil.query(this.__db, roomSQLiteQuery, false);
    try {
      int i = CursorUtil.getColumnIndexOrThrow(cursor, "uuid");
      int j = CursorUtil.getColumnIndexOrThrow(cursor, "name");
      int k = CursorUtil.getColumnIndexOrThrow(cursor, "hd");
      int m = CursorUtil.getColumnIndexOrThrow(cursor, "multicastSrc");
      int n = CursorUtil.getColumnIndexOrThrow(cursor, "hlsSrc");
      int i1 = CursorUtil.getColumnIndexOrThrow(cursor, "epgId");
      int i2 = CursorUtil.getColumnIndexOrThrow(cursor, "logoUrl");
      int i3 = CursorUtil.getColumnIndexOrThrow(cursor, "ordernum");
      int i4 = CursorUtil.getColumnIndexOrThrow(cursor, "langordernum");
      int i5 = CursorUtil.getColumnIndexOrThrow(cursor, "countryCode");
      int i6 = CursorUtil.getColumnIndexOrThrow(cursor, "languageCode");
      int i7 = CursorUtil.getColumnIndexOrThrow(cursor, "hasReplay");
      int i8 = CursorUtil.getColumnIndexOrThrow(cursor, "lastEtag");
      int i9 = CursorUtil.getColumnIndexOrThrow(cursor, "lastEPGUpdate");
      boolean bool = cursor.moveToFirst();
      if (bool) {
        try {
          TvChannel tvChannel = new TvChannel();
          tvChannel.uuid = cursor.getString(i);
          tvChannel.name = cursor.getString(j);
          if (cursor.getInt(k) != 0) {
            bool = true;
          } else {
            bool = false;
          } 
          tvChannel.hd = bool;
          tvChannel.multicastSrc = cursor.getString(m);
          tvChannel.hlsSrc = cursor.getString(n);
          tvChannel.epgId = cursor.getString(i1);
          tvChannel.logoUrl = cursor.getString(i2);
          tvChannel.ordernum = cursor.getInt(i3);
          tvChannel.langordernum = cursor.getInt(i4);
          tvChannel.countryCode = cursor.getString(i5);
          tvChannel.languageCode = cursor.getString(i6);
          if (cursor.getInt(i7) != 0) {
            bool = true;
          } else {
            bool = false;
          } 
          tvChannel.hasReplay = bool;
          tvChannel.lastEtag = cursor.getString(i8);
          tvChannel.lastEPGUpdate = cursor.getLong(i9);
        } finally {}
      } else {
        paramString = null;
      } 
      return paramString;
    } finally {
      cursor.close();
      roomSQLiteQuery.release();
    } 
  }
  
  public LiveData<Integer> getChannelCount() {
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT COUNT(*) FROM TvChannel", 0);
    InvalidationTracker invalidationTracker = this.__db.getInvalidationTracker();
    Object object = new Object(this, roomSQLiteQuery);
    return invalidationTracker.createLiveData(new String[] { "TvChannel" }, false, object);
  }
  
  public TvChannel getFirst(String paramString) {
    roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT * FROM TvChannel ORDER BY CASE languageCode WHEN ? THEN langordernum ELSE ordernum END LIMIT 1", 1);
    if (paramString == null) {
      roomSQLiteQuery.bindNull(1);
    } else {
      roomSQLiteQuery.bindString(1, paramString);
    } 
    this.__db.assertNotSuspendingTransaction();
    cursor = DBUtil.query(this.__db, roomSQLiteQuery, false);
    try {
      int i = CursorUtil.getColumnIndexOrThrow(cursor, "uuid");
      int j = CursorUtil.getColumnIndexOrThrow(cursor, "name");
      int k = CursorUtil.getColumnIndexOrThrow(cursor, "hd");
      int m = CursorUtil.getColumnIndexOrThrow(cursor, "multicastSrc");
      int n = CursorUtil.getColumnIndexOrThrow(cursor, "hlsSrc");
      int i1 = CursorUtil.getColumnIndexOrThrow(cursor, "epgId");
      int i2 = CursorUtil.getColumnIndexOrThrow(cursor, "logoUrl");
      int i3 = CursorUtil.getColumnIndexOrThrow(cursor, "ordernum");
      int i4 = CursorUtil.getColumnIndexOrThrow(cursor, "langordernum");
      int i5 = CursorUtil.getColumnIndexOrThrow(cursor, "countryCode");
      int i6 = CursorUtil.getColumnIndexOrThrow(cursor, "languageCode");
      int i7 = CursorUtil.getColumnIndexOrThrow(cursor, "hasReplay");
      int i8 = CursorUtil.getColumnIndexOrThrow(cursor, "lastEtag");
      int i9 = CursorUtil.getColumnIndexOrThrow(cursor, "lastEPGUpdate");
      boolean bool = cursor.moveToFirst();
      if (bool) {
        try {
          TvChannel tvChannel = new TvChannel();
          tvChannel.uuid = cursor.getString(i);
          tvChannel.name = cursor.getString(j);
          if (cursor.getInt(k) != 0) {
            bool = true;
          } else {
            bool = false;
          } 
          tvChannel.hd = bool;
          tvChannel.multicastSrc = cursor.getString(m);
          tvChannel.hlsSrc = cursor.getString(n);
          tvChannel.epgId = cursor.getString(i1);
          tvChannel.logoUrl = cursor.getString(i2);
          tvChannel.ordernum = cursor.getInt(i3);
          tvChannel.langordernum = cursor.getInt(i4);
          tvChannel.countryCode = cursor.getString(i5);
          tvChannel.languageCode = cursor.getString(i6);
          if (cursor.getInt(i7) != 0) {
            bool = true;
          } else {
            bool = false;
          } 
          tvChannel.hasReplay = bool;
          tvChannel.lastEtag = cursor.getString(i8);
          tvChannel.lastEPGUpdate = cursor.getLong(i9);
        } finally {}
      } else {
        paramString = null;
      } 
      return paramString;
    } finally {
      cursor.close();
      roomSQLiteQuery.release();
    } 
  }
  
  public LiveData<TvChannel> getWithOffset(int paramInt) {
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT * FROM TvChannel LIMIT 1 OFFSET ?", 1);
    roomSQLiteQuery.bindLong(1, paramInt);
    InvalidationTracker invalidationTracker = this.__db.getInvalidationTracker();
    Object object = new Object(this, roomSQLiteQuery);
    return invalidationTracker.createLiveData(new String[] { "TvChannel" }, false, object);
  }
  
  public void update(TvChannel paramTvChannel) {
    this.__db.assertNotSuspendingTransaction();
    this.__db.beginTransaction();
    try {
      this.__updateAdapterOfTvChannel.handle(paramTvChannel);
      this.__db.setTransactionSuccessful();
      return;
    } finally {
      this.__db.endTransaction();
    } 
  }
}
