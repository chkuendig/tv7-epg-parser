package ch.andeo.init7.core.dao;

public interface AllowedStore {
  void setIsAllowed(Boolean paramBoolean);
}
