package ch.andeo.init7.core.dao;

import android.database.Cursor;
import androidx.lifecycle.LiveData;
import androidx.room.EntityDeletionOrUpdateAdapter;
import androidx.room.EntityInsertionAdapter;
import androidx.room.InvalidationTracker;
import androidx.room.RoomDatabase;
import androidx.room.RoomSQLiteQuery;
import androidx.room.util.CursorUtil;
import androidx.room.util.DBUtil;
import androidx.room.util.StringUtil;
import androidx.sqlite.db.SupportSQLiteStatement;
import ch.andeo.init7.core.model.EPGInfo;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class EPGDao_Impl implements EPGDao {
  private final RoomDatabase __db;
  
  private final EntityInsertionAdapter __insertionAdapterOfEPGInfo;
  
  private final EntityDeletionOrUpdateAdapter __updateAdapterOfEPGInfo;
  
  public EPGDao_Impl(RoomDatabase paramRoomDatabase) {
    this.__db = paramRoomDatabase;
    this.__insertionAdapterOfEPGInfo = new Object(this, paramRoomDatabase);
    this.__updateAdapterOfEPGInfo = new Object(this, paramRoomDatabase);
  }
  
  public void add(List<EPGInfo> paramList) {
    this.__db.assertNotSuspendingTransaction();
    this.__db.beginTransaction();
    try {
      this.__insertionAdapterOfEPGInfo.insert(paramList);
      this.__db.setTransactionSuccessful();
      return;
    } finally {
      this.__db.endTransaction();
    } 
  }
  
  public void deletePKs(List<String> paramList) {
    this.__db.assertNotSuspendingTransaction();
    StringBuilder stringBuilder = StringUtil.newStringBuilder();
    stringBuilder.append("DELETE FROM EPGInfo WHERE uuid IN (");
    StringUtil.appendPlaceholders(stringBuilder, paramList.size());
    stringBuilder.append(")");
    String str = stringBuilder.toString();
    SupportSQLiteStatement supportSQLiteStatement = this.__db.compileStatement(str);
    null = paramList.iterator();
    for (byte b = 1; null.hasNext(); b++) {
      String str1 = (String)null.next();
      if (str1 == null) {
        supportSQLiteStatement.bindNull(b);
      } else {
        supportSQLiteStatement.bindString(b, str1);
      } 
    } 
    this.__db.beginTransaction();
    try {
      supportSQLiteStatement.executeUpdateDelete();
      this.__db.setTransactionSuccessful();
      return;
    } finally {
      this.__db.endTransaction();
    } 
  }
  
  public EPGInfo find(String paramString) {
    roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT * FROM EPGInfo WHERE uuid = ?", 1);
    if (paramString == null) {
      roomSQLiteQuery.bindNull(1);
    } else {
      roomSQLiteQuery.bindString(1, paramString);
    } 
    this.__db.assertNotSuspendingTransaction();
    cursor = DBUtil.query(this.__db, roomSQLiteQuery, false);
    try {
      int i = CursorUtil.getColumnIndexOrThrow(cursor, "uuid");
      int j = CursorUtil.getColumnIndexOrThrow(cursor, "channel_uuid");
      int k = CursorUtil.getColumnIndexOrThrow(cursor, "tsStart");
      int m = CursorUtil.getColumnIndexOrThrow(cursor, "tsEnd");
      int n = CursorUtil.getColumnIndexOrThrow(cursor, "title");
      int i1 = CursorUtil.getColumnIndexOrThrow(cursor, "subTitle");
      int i2 = CursorUtil.getColumnIndexOrThrow(cursor, "desc");
      if (cursor.moveToFirst()) {
        EPGInfo ePGInfo = new EPGInfo();
        ePGInfo.uuid = cursor.getString(i);
        ePGInfo.channel_uuid = cursor.getString(j);
        ePGInfo.tsStart = cursor.getLong(k);
        ePGInfo.tsEnd = cursor.getLong(m);
        ePGInfo.title = cursor.getString(n);
        ePGInfo.subTitle = cursor.getString(i1);
        ePGInfo.desc = cursor.getString(i2);
      } else {
        paramString = null;
      } 
      return paramString;
    } finally {
      cursor.close();
      roomSQLiteQuery.release();
    } 
  }
  
  public List<EPGInfo> findByStartTsConstraint(String paramString, long paramLong1, long paramLong2) {
    roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT * FROM EPGInfo WHERE channel_uuid = ? AND tsStart >= ? AND tsStart <= ?", 3);
    if (paramString == null) {
      roomSQLiteQuery.bindNull(1);
    } else {
      roomSQLiteQuery.bindString(1, paramString);
    } 
    roomSQLiteQuery.bindLong(2, paramLong1);
    roomSQLiteQuery.bindLong(3, paramLong2);
    this.__db.assertNotSuspendingTransaction();
    cursor = DBUtil.query(this.__db, roomSQLiteQuery, false);
    try {
      int i = CursorUtil.getColumnIndexOrThrow(cursor, "uuid");
      int j = CursorUtil.getColumnIndexOrThrow(cursor, "channel_uuid");
      int k = CursorUtil.getColumnIndexOrThrow(cursor, "tsStart");
      int m = CursorUtil.getColumnIndexOrThrow(cursor, "tsEnd");
      int n = CursorUtil.getColumnIndexOrThrow(cursor, "title");
      int i1 = CursorUtil.getColumnIndexOrThrow(cursor, "subTitle");
      int i2 = CursorUtil.getColumnIndexOrThrow(cursor, "desc");
      arrayList = new ArrayList(cursor.getCount());
      while (cursor.moveToNext()) {
        EPGInfo ePGInfo = new EPGInfo();
        ePGInfo.uuid = cursor.getString(i);
        ePGInfo.channel_uuid = cursor.getString(j);
        ePGInfo.tsStart = cursor.getLong(k);
        ePGInfo.tsEnd = cursor.getLong(m);
        ePGInfo.title = cursor.getString(n);
        ePGInfo.subTitle = cursor.getString(i1);
        ePGInfo.desc = cursor.getString(i2);
        arrayList.add(ePGInfo);
      } 
      return arrayList;
    } finally {
      cursor.close();
      roomSQLiteQuery.release();
    } 
  }
  
  public LiveData<List<EPGInfo>> getByChannel(String paramString, long paramLong) {
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT * FROM EPGInfo WHERE channel_uuid = ? AND tsStart > ? ORDER BY tsStart ASC", 2);
    if (paramString == null) {
      roomSQLiteQuery.bindNull(1);
    } else {
      roomSQLiteQuery.bindString(1, paramString);
    } 
    roomSQLiteQuery.bindLong(2, paramLong);
    InvalidationTracker invalidationTracker = this.__db.getInvalidationTracker();
    Object object = new Object(this, roomSQLiteQuery);
    return invalidationTracker.createLiveData(new String[] { "EPGInfo" }, false, object);
  }
  
  public EPGInfo getEPGInTime(String paramString, long paramLong) {
    roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT * FROM EPGInfo WHERE channel_uuid = ? AND tsStart <= ? AND tsEnd >= ? LIMIT 1", 3);
    if (paramString == null) {
      roomSQLiteQuery.bindNull(1);
    } else {
      roomSQLiteQuery.bindString(1, paramString);
    } 
    roomSQLiteQuery.bindLong(2, paramLong);
    roomSQLiteQuery.bindLong(3, paramLong);
    this.__db.assertNotSuspendingTransaction();
    cursor = DBUtil.query(this.__db, roomSQLiteQuery, false);
    try {
      int i = CursorUtil.getColumnIndexOrThrow(cursor, "uuid");
      int j = CursorUtil.getColumnIndexOrThrow(cursor, "channel_uuid");
      int k = CursorUtil.getColumnIndexOrThrow(cursor, "tsStart");
      int m = CursorUtil.getColumnIndexOrThrow(cursor, "tsEnd");
      int n = CursorUtil.getColumnIndexOrThrow(cursor, "title");
      int i1 = CursorUtil.getColumnIndexOrThrow(cursor, "subTitle");
      int i2 = CursorUtil.getColumnIndexOrThrow(cursor, "desc");
      if (cursor.moveToFirst()) {
        EPGInfo ePGInfo = new EPGInfo();
        ePGInfo.uuid = cursor.getString(i);
        ePGInfo.channel_uuid = cursor.getString(j);
        ePGInfo.tsStart = cursor.getLong(k);
        ePGInfo.tsEnd = cursor.getLong(m);
        ePGInfo.title = cursor.getString(n);
        ePGInfo.subTitle = cursor.getString(i1);
        ePGInfo.desc = cursor.getString(i2);
      } else {
        paramString = null;
      } 
      return paramString;
    } finally {
      cursor.close();
      roomSQLiteQuery.release();
    } 
  }
  
  public EPGInfo getFirstEPGAfter(String paramString, long paramLong) {
    roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT * FROM EPGInfo WHERE channel_uuid = ? AND tsStart > ? ORDER BY tsStart ASC LIMIT 1", 2);
    if (paramString == null) {
      roomSQLiteQuery.bindNull(1);
    } else {
      roomSQLiteQuery.bindString(1, paramString);
    } 
    roomSQLiteQuery.bindLong(2, paramLong);
    this.__db.assertNotSuspendingTransaction();
    cursor = DBUtil.query(this.__db, roomSQLiteQuery, false);
    try {
      int i = CursorUtil.getColumnIndexOrThrow(cursor, "uuid");
      int j = CursorUtil.getColumnIndexOrThrow(cursor, "channel_uuid");
      int k = CursorUtil.getColumnIndexOrThrow(cursor, "tsStart");
      int m = CursorUtil.getColumnIndexOrThrow(cursor, "tsEnd");
      int n = CursorUtil.getColumnIndexOrThrow(cursor, "title");
      int i1 = CursorUtil.getColumnIndexOrThrow(cursor, "subTitle");
      int i2 = CursorUtil.getColumnIndexOrThrow(cursor, "desc");
      if (cursor.moveToFirst()) {
        EPGInfo ePGInfo = new EPGInfo();
        ePGInfo.uuid = cursor.getString(i);
        ePGInfo.channel_uuid = cursor.getString(j);
        ePGInfo.tsStart = cursor.getLong(k);
        ePGInfo.tsEnd = cursor.getLong(m);
        ePGInfo.title = cursor.getString(n);
        ePGInfo.subTitle = cursor.getString(i1);
        ePGInfo.desc = cursor.getString(i2);
      } else {
        paramString = null;
      } 
      return paramString;
    } finally {
      cursor.close();
      roomSQLiteQuery.release();
    } 
  }
  
  public EPGInfo getFirstEPGBefore(String paramString, long paramLong) {
    roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT * FROM EPGInfo WHERE channel_uuid = ? AND tsStart < ? ORDER BY tsStart DESC LIMIT 1", 2);
    if (paramString == null) {
      roomSQLiteQuery.bindNull(1);
    } else {
      roomSQLiteQuery.bindString(1, paramString);
    } 
    roomSQLiteQuery.bindLong(2, paramLong);
    this.__db.assertNotSuspendingTransaction();
    cursor = DBUtil.query(this.__db, roomSQLiteQuery, false);
    try {
      int i = CursorUtil.getColumnIndexOrThrow(cursor, "uuid");
      int j = CursorUtil.getColumnIndexOrThrow(cursor, "channel_uuid");
      int k = CursorUtil.getColumnIndexOrThrow(cursor, "tsStart");
      int m = CursorUtil.getColumnIndexOrThrow(cursor, "tsEnd");
      int n = CursorUtil.getColumnIndexOrThrow(cursor, "title");
      int i1 = CursorUtil.getColumnIndexOrThrow(cursor, "subTitle");
      int i2 = CursorUtil.getColumnIndexOrThrow(cursor, "desc");
      if (cursor.moveToFirst()) {
        EPGInfo ePGInfo = new EPGInfo();
        ePGInfo.uuid = cursor.getString(i);
        ePGInfo.channel_uuid = cursor.getString(j);
        ePGInfo.tsStart = cursor.getLong(k);
        ePGInfo.tsEnd = cursor.getLong(m);
        ePGInfo.title = cursor.getString(n);
        ePGInfo.subTitle = cursor.getString(i1);
        ePGInfo.desc = cursor.getString(i2);
      } else {
        paramString = null;
      } 
      return paramString;
    } finally {
      cursor.close();
      roomSQLiteQuery.release();
    } 
  }
  
  public void update(List<EPGInfo> paramList) {
    this.__db.assertNotSuspendingTransaction();
    this.__db.beginTransaction();
    try {
      this.__updateAdapterOfEPGInfo.handleMultiple(paramList);
      this.__db.setTransactionSuccessful();
      return;
    } finally {
      this.__db.endTransaction();
    } 
  }
}
