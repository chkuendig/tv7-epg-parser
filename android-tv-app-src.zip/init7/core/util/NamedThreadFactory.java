package ch.andeo.init7.core.util;

import java.util.concurrent.ThreadFactory;

public class NamedThreadFactory implements ThreadFactory {
  private String name;
  
  public NamedThreadFactory(String paramString) { this.name = paramString; }
  
  protected String getName() { return this.name; }
  
  public Thread newThread(Runnable paramRunnable) { return new Thread(paramRunnable, getName()); }
}
