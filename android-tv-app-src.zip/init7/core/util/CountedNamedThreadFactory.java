package ch.andeo.init7.core.util;

public class CountedNamedThreadFactory extends NamedThreadFactory {
  private int count = 1;
  
  public CountedNamedThreadFactory(String paramString) { super(paramString); }
  
  protected String getName() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(super.getName());
    stringBuilder.append("-");
    int i = this.count;
    this.count = i + 1;
    stringBuilder.append(i);
    return stringBuilder.toString();
  }
}
