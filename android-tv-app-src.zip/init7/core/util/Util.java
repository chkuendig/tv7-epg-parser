package ch.andeo.init7.core.util;

import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.MutableLiveData;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

public class Util {
  public static <T> boolean collectionEquals(Collection<T> paramCollection1, Collection<T> paramCollection2) { // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: getstatic ch/andeo/init7/core/util/-$$Lambda$R8sORDbgJ0kW9_H4AyFl7LvUS-I.INSTANCE : Lch/andeo/init7/core/util/-$$Lambda$R8sORDbgJ0kW9_H4AyFl7LvUS-I;
    //   5: invokestatic collectionEquals : (Ljava/util/Collection;Ljava/util/Collection;Lch/andeo/init7/core/util/Util$EqualsComparator;)Z
    //   8: ireturn }
  
  public static <T> boolean collectionEquals(Collection<T> paramCollection1, Collection<T> paramCollection2, EqualsComparator<T> paramEqualsComparator) {
    if (paramCollection1 == null || paramCollection2 == null)
      return (paramCollection1 == paramCollection2); 
    if (paramCollection1.size() != paramCollection2.size())
      return false; 
    Iterator iterator2 = paramCollection2.iterator();
    Iterator iterator1 = paramCollection1.iterator();
    while (iterator1.hasNext()) {
      if (!paramEqualsComparator.test(iterator1.next(), iterator2.next()))
        return false; 
    } 
    return true;
  }
  
  public static String getUserAgent(Context paramContext, String paramString1, String paramString2) {
    String str;
    try {
      String str1 = paramContext.getPackageName();
      str = (paramContext.getPackageManager().getPackageInfo(str1, 0)).versionName;
    } catch (android.content.pm.PackageManager.NameNotFoundException paramContext) {
      str = "?";
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString1);
    stringBuilder.append("/");
    stringBuilder.append(str);
    stringBuilder.append(" ");
    stringBuilder.append(Build.BRAND);
    stringBuilder.append("/");
    stringBuilder.append(Build.MODEL);
    stringBuilder.append(" Android/");
    stringBuilder.append(Build.VERSION.RELEASE);
    stringBuilder.append(" ");
    stringBuilder.append(paramString2);
    return stringBuilder.toString();
  }
  
  public static boolean isMainThread() { return (Looper.getMainLooper() == Looper.myLooper()); }
  
  public static <T> int listIndexOf(List<T> paramList, T paramT, EqualsComparator<T> paramEqualsComparator) {
    for (byte b = 0; b < paramList.size(); b++) {
      if (paramEqualsComparator.test(paramList.get(b), paramT))
        return b; 
    } 
    return -1;
  }
  
  public static <T> void setSafe(MutableLiveData<T> paramMutableLiveData, T paramT) {
    if (isMainThread()) {
      paramMutableLiveData.setValue(paramT);
      return;
    } 
    paramMutableLiveData.postValue(paramT);
  }
  
  public static void startFocusLogger(int paramInt1, String paramString, FragmentActivity paramFragmentActivity, int paramInt2) { // Byte code:
    //   0: new ch/andeo/init7/core/util/NamedThreadFactory
    //   3: dup
    //   4: ldc 'Focus-Debug'
    //   6: invokespecial <init> : (Ljava/lang/String;)V
    //   9: invokestatic newSingleThreadExecutor : (Ljava/util/concurrent/ThreadFactory;)Ljava/util/concurrent/ExecutorService;
    //   12: new ch/andeo/init7/core/util/-$$Lambda$Util$iWJ8Hw30a-gxUtyGdRcENiFBB7g
    //   15: dup
    //   16: aload_1
    //   17: aload_2
    //   18: iload_3
    //   19: iload_0
    //   20: invokespecial <init> : (Ljava/lang/String;Landroidx/fragment/app/FragmentActivity;II)V
    //   23: invokeinterface submit : (Ljava/lang/Runnable;)Ljava/util/concurrent/Future;
    //   28: pop
    //   29: return }
  
  public static <T> void update(MutableLiveData<T> paramMutableLiveData, T paramT) {
    if (!paramT.equals(paramMutableLiveData.getValue()))
      setSafe(paramMutableLiveData, paramT); 
  }
  
  public static <T> void updateList(MutableLiveData<Collection<T>> paramMutableLiveData, Collection<T> paramCollection, EqualsComparator<T> paramEqualsComparator) {
    if (!collectionEquals((Collection)paramMutableLiveData.getValue(), paramCollection, paramEqualsComparator))
      setSafe(paramMutableLiveData, paramCollection); 
  }
  
  public static <T> void updateList(MutableLiveData<List<T>> paramMutableLiveData, List<T> paramList, EqualsComparator<T> paramEqualsComparator) {
    if (!collectionEquals((List)paramMutableLiveData.getValue(), paramList, paramEqualsComparator))
      setSafe(paramMutableLiveData, paramList); 
  }
}
