package ch.andeo.init7.core;

public final class R {}
