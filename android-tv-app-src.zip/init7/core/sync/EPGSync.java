package ch.andeo.init7.core.sync;

import android.util.Log;
import ch.andeo.init7.core.api.TvApi;
import ch.andeo.init7.core.api.responsemodel.EPGListResponse;
import ch.andeo.init7.core.dao.EPGDao;
import ch.andeo.init7.core.dao.TvChannelDao;
import ch.andeo.init7.core.model.TvChannel;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import retrofit2.Response;

public class EPGSync {
  private static final int EPG_LIMIT = 10000;
  
  private static final String TAG = "EPGSync";
  
  private TvApi api;
  
  private EPGDao epgDao;
  
  private TvChannelDao tvChannelDao;
  
  public EPGSync(TvApi paramTvApi, EPGDao paramEPGDao, TvChannelDao paramTvChannelDao) {
    this.api = paramTvApi;
    this.epgDao = paramEPGDao;
    this.tvChannelDao = paramTvChannelDao;
  }
  
  private void syncChannelNearest(TvChannel paramTvChannel) throws IOException {
    Response response1 = this.api.getEPG(paramTvChannel.uuid, 20, true, false).execute();
    Response response2 = this.api.getEPG(paramTvChannel.uuid, 20, false, true).execute();
    updateEPG(paramTvChannel, (EPGListResponse)response1.body());
    updateEPG(paramTvChannel, (EPGListResponse)response2.body());
  }
  
  private void updateEPG(TvChannel paramTvChannel, EPGListResponse paramEPGListResponse) { updateEPG(paramTvChannel, paramEPGListResponse, false); }
  
  private void updateEPG(TvChannel paramTvChannel, EPGListResponse paramEPGListResponse, boolean paramBoolean) { // Byte code:
    //   0: aload_2
    //   1: ifnonnull -> 5
    //   4: return
    //   5: aload_2
    //   6: getfield results : Ljava/util/List;
    //   9: invokeinterface size : ()I
    //   14: ifne -> 18
    //   17: return
    //   18: new java/util/ArrayList
    //   21: dup
    //   22: invokespecial <init> : ()V
    //   25: astore #16
    //   27: aload_2
    //   28: getfield results : Ljava/util/List;
    //   31: invokeinterface iterator : ()Ljava/util/Iterator;
    //   36: astore_2
    //   37: ldc2_w -1
    //   40: lstore #9
    //   42: lload #9
    //   44: lstore #7
    //   46: aload_2
    //   47: invokeinterface hasNext : ()Z
    //   52: ifeq -> 144
    //   55: aload_2
    //   56: invokeinterface next : ()Ljava/lang/Object;
    //   61: checkcast ch/andeo/init7/core/api/responsemodel/EPGInfoResponse
    //   64: invokevirtual toEPGInfo : ()Lch/andeo/init7/core/model/EPGInfo;
    //   67: astore #13
    //   69: aload #16
    //   71: aload #13
    //   73: invokeinterface add : (Ljava/lang/Object;)Z
    //   78: pop
    //   79: lload #9
    //   81: lconst_0
    //   82: lcmp
    //   83: iflt -> 101
    //   86: lload #9
    //   88: lstore #11
    //   90: aload #13
    //   92: getfield tsStart : J
    //   95: lload #9
    //   97: lcmp
    //   98: ifge -> 108
    //   101: aload #13
    //   103: getfield tsStart : J
    //   106: lstore #11
    //   108: lload #7
    //   110: lconst_0
    //   111: lcmp
    //   112: iflt -> 130
    //   115: lload #11
    //   117: lstore #9
    //   119: aload #13
    //   121: getfield tsStart : J
    //   124: lload #7
    //   126: lcmp
    //   127: ifle -> 46
    //   130: aload #13
    //   132: getfield tsStart : J
    //   135: lstore #7
    //   137: lload #11
    //   139: lstore #9
    //   141: goto -> 46
    //   144: new java/util/ArrayList
    //   147: dup
    //   148: invokespecial <init> : ()V
    //   151: astore #13
    //   153: new java/util/ArrayList
    //   156: dup
    //   157: invokespecial <init> : ()V
    //   160: astore_2
    //   161: aload_0
    //   162: getfield epgDao : Lch/andeo/init7/core/dao/EPGDao;
    //   165: aload_1
    //   166: getfield uuid : Ljava/lang/String;
    //   169: lload #9
    //   171: lload #7
    //   173: invokeinterface findByStartTsConstraint : (Ljava/lang/String;JJ)Ljava/util/List;
    //   178: astore #17
    //   180: new android/util/SparseArray
    //   183: dup
    //   184: invokespecial <init> : ()V
    //   187: astore #14
    //   189: new java/util/HashSet
    //   192: dup
    //   193: invokespecial <init> : ()V
    //   196: astore #15
    //   198: aload #17
    //   200: invokeinterface iterator : ()Ljava/util/Iterator;
    //   205: astore #17
    //   207: aload #17
    //   209: invokeinterface hasNext : ()Z
    //   214: ifeq -> 244
    //   217: aload #17
    //   219: invokeinterface next : ()Ljava/lang/Object;
    //   224: checkcast ch/andeo/init7/core/model/EPGInfo
    //   227: astore #18
    //   229: aload #14
    //   231: aload #18
    //   233: invokevirtual hashCode : ()I
    //   236: aload #18
    //   238: invokevirtual put : (ILjava/lang/Object;)V
    //   241: goto -> 207
    //   244: aload #16
    //   246: invokeinterface iterator : ()Ljava/util/Iterator;
    //   251: astore #16
    //   253: aload #16
    //   255: invokeinterface hasNext : ()Z
    //   260: ifeq -> 350
    //   263: aload #16
    //   265: invokeinterface next : ()Ljava/lang/Object;
    //   270: checkcast ch/andeo/init7/core/model/EPGInfo
    //   273: astore #17
    //   275: aload #14
    //   277: aload #17
    //   279: invokevirtual hashCode : ()I
    //   282: invokevirtual get : (I)Ljava/lang/Object;
    //   285: checkcast ch/andeo/init7/core/model/EPGInfo
    //   288: astore #18
    //   290: iload_3
    //   291: ifeq -> 310
    //   294: aload #15
    //   296: aload #17
    //   298: invokevirtual hashCode : ()I
    //   301: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   304: invokeinterface add : (Ljava/lang/Object;)Z
    //   309: pop
    //   310: aload #18
    //   312: ifnull -> 338
    //   315: aload #18
    //   317: aload #17
    //   319: invokevirtual equals : (Ljava/lang/Object;)Z
    //   322: ifne -> 253
    //   325: aload #13
    //   327: aload #17
    //   329: invokeinterface add : (Ljava/lang/Object;)Z
    //   334: pop
    //   335: goto -> 253
    //   338: aload_2
    //   339: aload #17
    //   341: invokeinterface add : (Ljava/lang/Object;)Z
    //   346: pop
    //   347: goto -> 253
    //   350: iload_3
    //   351: ifeq -> 566
    //   354: new java/util/ArrayList
    //   357: dup
    //   358: invokespecial <init> : ()V
    //   361: astore #16
    //   363: iconst_0
    //   364: istore #5
    //   366: iconst_0
    //   367: istore #4
    //   369: iload #4
    //   371: aload #14
    //   373: invokevirtual size : ()I
    //   376: if_icmpge -> 429
    //   379: aload #15
    //   381: aload #14
    //   383: iload #4
    //   385: invokevirtual keyAt : (I)I
    //   388: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   391: invokeinterface contains : (Ljava/lang/Object;)Z
    //   396: ifne -> 420
    //   399: aload #16
    //   401: aload #14
    //   403: iload #4
    //   405: invokevirtual valueAt : (I)Ljava/lang/Object;
    //   408: checkcast ch/andeo/init7/core/model/EPGInfo
    //   411: getfield uuid : Ljava/lang/String;
    //   414: invokeinterface add : (Ljava/lang/Object;)Z
    //   419: pop
    //   420: iload #4
    //   422: iconst_1
    //   423: iadd
    //   424: istore #4
    //   426: goto -> 369
    //   429: new java/lang/StringBuilder
    //   432: dup
    //   433: invokespecial <init> : ()V
    //   436: astore #14
    //   438: aload #14
    //   440: ldc 'Deleting '
    //   442: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   445: pop
    //   446: aload #14
    //   448: aload #16
    //   450: invokeinterface size : ()I
    //   455: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   458: pop
    //   459: aload #14
    //   461: ldc ' from '
    //   463: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   466: pop
    //   467: aload #14
    //   469: aload_1
    //   470: getfield name : Ljava/lang/String;
    //   473: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   476: pop
    //   477: ldc 'EPGSync'
    //   479: aload #14
    //   481: invokevirtual toString : ()Ljava/lang/String;
    //   484: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)I
    //   487: pop
    //   488: iload #5
    //   490: istore #4
    //   492: iload #4
    //   494: aload #16
    //   496: invokeinterface size : ()I
    //   501: if_icmpge -> 566
    //   504: iload #4
    //   506: sipush #500
    //   509: iadd
    //   510: istore #6
    //   512: iload #6
    //   514: istore #5
    //   516: iload #6
    //   518: aload #16
    //   520: invokeinterface size : ()I
    //   525: if_icmple -> 537
    //   528: aload #16
    //   530: invokeinterface size : ()I
    //   535: istore #5
    //   537: aload_0
    //   538: getfield epgDao : Lch/andeo/init7/core/dao/EPGDao;
    //   541: aload #16
    //   543: iload #4
    //   545: iload #5
    //   547: invokeinterface subList : (II)Ljava/util/List;
    //   552: invokeinterface deletePKs : (Ljava/util/List;)V
    //   557: iload #5
    //   559: iconst_1
    //   560: iadd
    //   561: istore #4
    //   563: goto -> 492
    //   566: new java/lang/StringBuilder
    //   569: dup
    //   570: invokespecial <init> : ()V
    //   573: astore #14
    //   575: aload #14
    //   577: ldc 'Updating: '
    //   579: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   582: pop
    //   583: aload #14
    //   585: aload #13
    //   587: invokeinterface size : ()I
    //   592: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   595: pop
    //   596: aload #14
    //   598: ldc ' from '
    //   600: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   603: pop
    //   604: aload #14
    //   606: aload_1
    //   607: getfield name : Ljava/lang/String;
    //   610: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   613: pop
    //   614: ldc 'EPGSync'
    //   616: aload #14
    //   618: invokevirtual toString : ()Ljava/lang/String;
    //   621: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)I
    //   624: pop
    //   625: aload_0
    //   626: getfield epgDao : Lch/andeo/init7/core/dao/EPGDao;
    //   629: aload #13
    //   631: invokeinterface update : (Ljava/util/List;)V
    //   636: new java/lang/StringBuilder
    //   639: dup
    //   640: invokespecial <init> : ()V
    //   643: astore #13
    //   645: aload #13
    //   647: ldc 'Inserting: '
    //   649: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   652: pop
    //   653: aload #13
    //   655: aload_2
    //   656: invokeinterface size : ()I
    //   661: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   664: pop
    //   665: aload #13
    //   667: ldc ' from '
    //   669: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   672: pop
    //   673: aload #13
    //   675: aload_1
    //   676: getfield name : Ljava/lang/String;
    //   679: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   682: pop
    //   683: ldc 'EPGSync'
    //   685: aload #13
    //   687: invokevirtual toString : ()Ljava/lang/String;
    //   690: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)I
    //   693: pop
    //   694: aload_0
    //   695: getfield epgDao : Lch/andeo/init7/core/dao/EPGDao;
    //   698: aload_2
    //   699: invokeinterface add : (Ljava/util/List;)V
    //   704: return }
  
  public void syncChannelAll(TvChannel paramTvChannel) throws IOException {
    int i = 0;
    int j = -1;
    while (true) {
      if (i < j || j == -1) {
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("Fetching epg for channel ");
        stringBuilder2.append(paramTvChannel.name);
        stringBuilder2.append("; offset: ");
        stringBuilder2.append(i);
        Log.d("EPGSync", stringBuilder2.toString());
        StringBuilder stringBuilder1 = this.api.getEPG(paramTvChannel.uuid, 10000, i, paramTvChannel.lastEtag).execute();
        StringBuilder stringBuilder3 = new StringBuilder();
        stringBuilder3.append("Response: ");
        stringBuilder3.append(stringBuilder1.code());
        Log.i("EPGSync", stringBuilder3.toString());
        if (stringBuilder1.code() == 304) {
          stringBuilder1 = new StringBuilder();
          stringBuilder1.append("Not modified: ");
          stringBuilder1.append(paramTvChannel.name);
          Log.d("EPGSync", stringBuilder1.toString());
          return;
        } 
        if (stringBuilder1.body() != null) {
          updateEPG(paramTvChannel, (EPGListResponse)stringBuilder1.body(), true);
          String str = stringBuilder1.headers().get("ETag");
          if (str != null) {
            paramTvChannel.lastEtag = str;
            this.tvChannelDao.update(paramTvChannel);
          } 
          j = ((EPGListResponse)stringBuilder1.body()).count;
          i += ((EPGListResponse)stringBuilder1.body()).results.size();
          continue;
        } 
        break;
      } 
      return;
    } 
    throw new IOException("Response body was null");
  }
  
  public void syncChannelNow(TvChannel paramTvChannel) throws IOException {
    Log.i("EPGSync", "Syncing channels now");
    updateEPG(paramTvChannel, (EPGListResponse)this.api.getCurrentEPG(paramTvChannel.uuid).execute().body());
  }
  
  public void syncChannelsAll(List<TvChannel> paramList) throws IOException {
    Iterator iterator = paramList.iterator();
    while (iterator.hasNext())
      syncChannelAll((TvChannel)iterator.next()); 
  }
}
