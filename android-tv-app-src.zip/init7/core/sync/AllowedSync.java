package ch.andeo.init7.core.sync;

import android.os.AsyncTask;
import android.util.Log;
import ch.andeo.init7.core.api.TvApi;
import ch.andeo.init7.core.api.responsemodel.AllowedResponse;
import ch.andeo.init7.core.dao.AllowedStore;
import java.util.Objects;

public class AllowedSync extends AsyncTask<Void, Integer, Void> {
  private static final String TAG = "AllowedSyncTask";
  
  private AllowedStore store;
  
  private TvApi tvApi;
  
  public AllowedSync(TvApi paramTvApi, AllowedStore paramAllowedStore) {
    this.tvApi = paramTvApi;
    this.store = paramAllowedStore;
  }
  
  protected Void doInBackground(Void... paramVarArgs) {
    try {
      boolean bool = ((AllowedResponse)Objects.requireNonNull((AllowedResponse)this.tvApi.allowed().execute().body())).allowed;
      this.store.setIsAllowed(Boolean.valueOf(bool));
      return null;
    } catch (Exception paramVarArgs) {
      Log.e("AllowedSyncTask", "Failed to fetch Allowed status", paramVarArgs);
      this.store.setIsAllowed(null);
      return null;
    } 
  }
}
