package ch.andeo.init7.core.sync;

import android.os.AsyncTask;
import android.util.Log;
import ch.andeo.init7.core.api.TvApi;
import ch.andeo.init7.core.api.responsemodel.TvChannelListResponse;
import ch.andeo.init7.core.dao.TvChannelDao;
import ch.andeo.init7.core.model.TvChannel;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ChannelListSync extends AsyncTask<Void, Void, Void> {
  private static final String TAG = "ChannelListSync";
  
  private TvApi tvApi;
  
  private TvChannelDao tvChannelDao;
  
  public ChannelListSync(TvApi paramTvApi, TvChannelDao paramTvChannelDao) {
    this.tvApi = paramTvApi;
    this.tvChannelDao = paramTvChannelDao;
  }
  
  protected Void doInBackground(Void... paramVarArgs) {
    List list = this.tvChannelDao.getAllSync();
    hashMap = new HashMap();
    for (TvChannel tvChannel : list)
      hashMap.put(tvChannel.uuid, tvChannel); 
    try {
      List list1 = ((TvChannelListResponse)this.tvApi.tvChannelList().execute().body()).results;
      list = new ArrayList();
      ArrayList arrayList = new ArrayList();
      for (TvChannel tvChannel : list1) {
        if (hashMap.containsKey(tvChannel.uuid)) {
          if (!tvChannel.equals((TvChannel)hashMap.get(tvChannel.uuid)))
            list.add(tvChannel); 
          continue;
        } 
        arrayList.add(tvChannel);
      } 
      this.tvChannelDao.bulkUpdate(list);
      this.tvChannelDao.bulkInsert(arrayList);
    } catch (Exception hashMap) {
      Log.e("ChannelListSync", "Failed to update", hashMap);
    } 
    return null;
  }
}
