package ch.andeo.init7.core.sync;

import android.os.AsyncTask;
import ch.andeo.init7.core.dao.TvChannelDao;
import ch.andeo.init7.core.model.TvChannel;

public class EPGSyncTask extends AsyncTask<Void, Integer, Void> {
  private static final String TAG = "EPGSyncTask";
  
  private static final int THREAD_COUNT = 10;
  
  private final EPGSync epgSync;
  
  private final TvChannelDao tvChannelDao;
  
  public EPGSyncTask(TvChannelDao paramTvChannelDao, EPGSync paramEPGSync) {
    this.tvChannelDao = paramTvChannelDao;
    this.epgSync = paramEPGSync;
  }
  
  protected Void doInBackground(Void... paramVarArgs) { // Byte code:
    //   0: bipush #10
    //   2: new ch/andeo/init7/core/util/CountedNamedThreadFactory
    //   5: dup
    //   6: ldc 'EPGSyncTask'
    //   8: invokespecial <init> : (Ljava/lang/String;)V
    //   11: invokestatic newFixedThreadPool : (ILjava/util/concurrent/ThreadFactory;)Ljava/util/concurrent/ExecutorService;
    //   14: astore_1
    //   15: new java/util/concurrent/ExecutorCompletionService
    //   18: dup
    //   19: aload_1
    //   20: invokespecial <init> : (Ljava/util/concurrent/Executor;)V
    //   23: astore #4
    //   25: aload_0
    //   26: getfield tvChannelDao : Lch/andeo/init7/core/dao/TvChannelDao;
    //   29: invokeinterface getAllNow : ()Ljava/util/List;
    //   34: astore #5
    //   36: aload #5
    //   38: invokeinterface iterator : ()Ljava/util/Iterator;
    //   43: astore #6
    //   45: aload #6
    //   47: invokeinterface hasNext : ()Z
    //   52: ifeq -> 84
    //   55: aload #4
    //   57: new ch/andeo/init7/core/sync/-$$Lambda$EPGSyncTask$RFkbZxfQfr17KPettU3PJbHo1T8
    //   60: dup
    //   61: aload_0
    //   62: aload #6
    //   64: invokeinterface next : ()Ljava/lang/Object;
    //   69: checkcast ch/andeo/init7/core/model/TvChannel
    //   72: invokespecial <init> : (Lch/andeo/init7/core/sync/EPGSyncTask;Lch/andeo/init7/core/model/TvChannel;)V
    //   75: invokeinterface submit : (Ljava/util/concurrent/Callable;)Ljava/util/concurrent/Future;
    //   80: pop
    //   81: goto -> 45
    //   84: aload #5
    //   86: invokeinterface size : ()I
    //   91: istore_3
    //   92: iconst_0
    //   93: istore_2
    //   94: iload_2
    //   95: iload_3
    //   96: if_icmpge -> 138
    //   99: aload #4
    //   101: invokeinterface take : ()Ljava/util/concurrent/Future;
    //   106: invokeinterface get : ()Ljava/lang/Object;
    //   111: pop
    //   112: iload_2
    //   113: iconst_1
    //   114: iadd
    //   115: istore_2
    //   116: goto -> 94
    //   119: astore #4
    //   121: ldc 'EPGSyncTask'
    //   123: ldc 'Failed to fetch EPG for channels'
    //   125: aload #4
    //   127: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   130: pop
    //   131: aload_1
    //   132: invokeinterface shutdownNow : ()Ljava/util/List;
    //   137: pop
    //   138: aconst_null
    //   139: areturn
    // Exception table:
    //   from	to	target	type
    //   99	112	119	java/lang/Exception }
}
