package ch.andeo.init7.core;

import android.content.Context;
import androidx.room.Room;

public class TvDbFactory {
  public static TvDB createDB(Context paramContext) { return (TvDB)Room.databaseBuilder(paramContext, TvDB.class, "tvdb").fallbackToDestructiveMigration().build(); }
}
