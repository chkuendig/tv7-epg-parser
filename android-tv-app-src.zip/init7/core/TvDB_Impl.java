package ch.andeo.init7.core;

import androidx.room.DatabaseConfiguration;
import androidx.room.InvalidationTracker;
import androidx.room.RoomOpenHelper;
import androidx.sqlite.db.SupportSQLiteDatabase;
import androidx.sqlite.db.SupportSQLiteOpenHelper;
import ch.andeo.init7.core.dao.EPGDao;
import ch.andeo.init7.core.dao.TvChannelDao;
import java.util.HashMap;
import java.util.List;

public final class TvDB_Impl extends TvDB {
  public void clearAllTables() { // Byte code:
    //   0: aload_0
    //   1: invokespecial assertNotMainThread : ()V
    //   4: aload_0
    //   5: invokespecial getOpenHelper : ()Landroidx/sqlite/db/SupportSQLiteOpenHelper;
    //   8: invokeinterface getWritableDatabase : ()Landroidx/sqlite/db/SupportSQLiteDatabase;
    //   13: astore_2
    //   14: getstatic android/os/Build$VERSION.SDK_INT : I
    //   17: bipush #21
    //   19: if_icmplt -> 27
    //   22: iconst_1
    //   23: istore_1
    //   24: goto -> 29
    //   27: iconst_0
    //   28: istore_1
    //   29: iload_1
    //   30: ifne -> 41
    //   33: aload_2
    //   34: ldc 'PRAGMA foreign_keys = FALSE'
    //   36: invokeinterface execSQL : (Ljava/lang/String;)V
    //   41: aload_0
    //   42: invokespecial beginTransaction : ()V
    //   45: iload_1
    //   46: ifeq -> 57
    //   49: aload_2
    //   50: ldc 'PRAGMA defer_foreign_keys = TRUE'
    //   52: invokeinterface execSQL : (Ljava/lang/String;)V
    //   57: aload_2
    //   58: ldc 'DELETE FROM `TvChannel`'
    //   60: invokeinterface execSQL : (Ljava/lang/String;)V
    //   65: aload_2
    //   66: ldc 'DELETE FROM `EPGInfo`'
    //   68: invokeinterface execSQL : (Ljava/lang/String;)V
    //   73: aload_0
    //   74: invokespecial setTransactionSuccessful : ()V
    //   77: aload_0
    //   78: invokespecial endTransaction : ()V
    //   81: iload_1
    //   82: ifne -> 93
    //   85: aload_2
    //   86: ldc 'PRAGMA foreign_keys = TRUE'
    //   88: invokeinterface execSQL : (Ljava/lang/String;)V
    //   93: aload_2
    //   94: ldc 'PRAGMA wal_checkpoint(FULL)'
    //   96: invokeinterface query : (Ljava/lang/String;)Landroid/database/Cursor;
    //   101: invokeinterface close : ()V
    //   106: aload_2
    //   107: invokeinterface inTransaction : ()Z
    //   112: ifne -> 123
    //   115: aload_2
    //   116: ldc 'VACUUM'
    //   118: invokeinterface execSQL : (Ljava/lang/String;)V
    //   123: return
    //   124: astore_3
    //   125: aload_0
    //   126: invokespecial endTransaction : ()V
    //   129: iload_1
    //   130: ifne -> 141
    //   133: aload_2
    //   134: ldc 'PRAGMA foreign_keys = TRUE'
    //   136: invokeinterface execSQL : (Ljava/lang/String;)V
    //   141: aload_2
    //   142: ldc 'PRAGMA wal_checkpoint(FULL)'
    //   144: invokeinterface query : (Ljava/lang/String;)Landroid/database/Cursor;
    //   149: invokeinterface close : ()V
    //   154: aload_2
    //   155: invokeinterface inTransaction : ()Z
    //   160: ifne -> 171
    //   163: aload_2
    //   164: ldc 'VACUUM'
    //   166: invokeinterface execSQL : (Ljava/lang/String;)V
    //   171: aload_3
    //   172: athrow
    // Exception table:
    //   from	to	target	type
    //   33	41	124	finally
    //   41	45	124	finally
    //   49	57	124	finally
    //   57	77	124	finally }
  
  protected InvalidationTracker createInvalidationTracker() { return new InvalidationTracker(this, new HashMap(0), new HashMap(0), new String[] { "TvChannel", "EPGInfo" }); }
  
  protected SupportSQLiteOpenHelper createOpenHelper(DatabaseConfiguration paramDatabaseConfiguration) {
    RoomOpenHelper roomOpenHelper = new RoomOpenHelper(paramDatabaseConfiguration, new Object(this, 3), "72238ef99e270568004953b04b9c8d11", "bd5067a8fdcd3c371184b752f3a14bfe");
    SupportSQLiteOpenHelper.Configuration configuration = SupportSQLiteOpenHelper.Configuration.builder(paramDatabaseConfiguration.context).name(paramDatabaseConfiguration.name).callback(roomOpenHelper).build();
    return paramDatabaseConfiguration.sqliteOpenHelperFactory.create(configuration);
  }
  
  public EPGDao epgDao() { // Byte code:
    //   0: aload_0
    //   1: getfield _ePGDao : Lch/andeo/init7/core/dao/EPGDao;
    //   4: ifnull -> 12
    //   7: aload_0
    //   8: getfield _ePGDao : Lch/andeo/init7/core/dao/EPGDao;
    //   11: areturn
    //   12: aload_0
    //   13: monitorenter
    //   14: aload_0
    //   15: getfield _ePGDao : Lch/andeo/init7/core/dao/EPGDao;
    //   18: ifnonnull -> 33
    //   21: aload_0
    //   22: new ch/andeo/init7/core/dao/EPGDao_Impl
    //   25: dup
    //   26: aload_0
    //   27: invokespecial <init> : (Landroidx/room/RoomDatabase;)V
    //   30: putfield _ePGDao : Lch/andeo/init7/core/dao/EPGDao;
    //   33: aload_0
    //   34: getfield _ePGDao : Lch/andeo/init7/core/dao/EPGDao;
    //   37: astore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_1
    //   41: areturn
    //   42: astore_1
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_1
    //   46: athrow
    // Exception table:
    //   from	to	target	type
    //   14	33	42	finally
    //   33	40	42	finally
    //   43	45	42	finally }
  
  public TvChannelDao tvChannelDao() { // Byte code:
    //   0: aload_0
    //   1: getfield _tvChannelDao : Lch/andeo/init7/core/dao/TvChannelDao;
    //   4: ifnull -> 12
    //   7: aload_0
    //   8: getfield _tvChannelDao : Lch/andeo/init7/core/dao/TvChannelDao;
    //   11: areturn
    //   12: aload_0
    //   13: monitorenter
    //   14: aload_0
    //   15: getfield _tvChannelDao : Lch/andeo/init7/core/dao/TvChannelDao;
    //   18: ifnonnull -> 33
    //   21: aload_0
    //   22: new ch/andeo/init7/core/dao/TvChannelDao_Impl
    //   25: dup
    //   26: aload_0
    //   27: invokespecial <init> : (Landroidx/room/RoomDatabase;)V
    //   30: putfield _tvChannelDao : Lch/andeo/init7/core/dao/TvChannelDao;
    //   33: aload_0
    //   34: getfield _tvChannelDao : Lch/andeo/init7/core/dao/TvChannelDao;
    //   37: astore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_1
    //   41: areturn
    //   42: astore_1
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_1
    //   46: athrow
    // Exception table:
    //   from	to	target	type
    //   14	33	42	finally
    //   33	40	42	finally
    //   43	45	42	finally }
}
