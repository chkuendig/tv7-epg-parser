package ch.andeo.init7.core.api.responsemodel;

import java.util.List;

public class EPGListResponse {
  public int count;
  
  public String next;
  
  public String previous;
  
  public List<EPGInfoResponse> results;
}
