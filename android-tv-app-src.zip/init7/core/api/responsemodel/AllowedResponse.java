package ch.andeo.init7.core.api.responsemodel;

import java.io.Serializable;
import java.net.InetAddress;

public class AllowedResponse implements Serializable {
  public boolean allowed;
  
  public boolean authenticated;
  
  public InetAddress ip;
  
  public AllowedResponse(InetAddress paramInetAddress, boolean paramBoolean1, boolean paramBoolean2) {
    this.ip = paramInetAddress;
    this.allowed = paramBoolean1;
    this.authenticated = paramBoolean2;
  }
}
