package ch.andeo.init7.core.api.responsemodel;

import ch.andeo.init7.core.model.EPGInfo;
import ch.andeo.init7.core.model.TvChannel;
import com.google.gson.annotations.SerializedName;
import java.io.Serializable;

public class EPGInfoResponse implements Serializable {
  public String[] categories;
  
  public TvChannel channel;
  
  public Object country;
  
  public String desc;
  
  public String[] icons;
  
  public String pk;
  
  @SerializedName("sub_title")
  public String subTitle;
  
  public TimeSlot timeslot;
  
  public String title;
  
  @SerializedName("date")
  public int year;
  
  public EPGInfo toEPGInfo() {
    EPGInfo ePGInfo = new EPGInfo();
    ePGInfo.uuid = this.pk;
    ePGInfo.tsStart = this.timeslot.lower.getTime();
    ePGInfo.tsEnd = this.timeslot.upper.getTime();
    ePGInfo.title = this.title;
    ePGInfo.subTitle = this.subTitle;
    ePGInfo.desc = this.desc;
    ePGInfo.channel_uuid = this.channel.uuid;
    return ePGInfo;
  }
}
