package ch.andeo.init7.core.api.responsemodel;

import ch.andeo.init7.core.model.TvChannel;
import java.util.List;

public class TvChannelListResponse {
  public int count;
  
  public List<TvChannel> results;
}
