package ch.andeo.init7.core.api;

import ch.andeo.init7.core.api.responsemodel.AllowedResponse;
import ch.andeo.init7.core.api.responsemodel.EPGListResponse;
import ch.andeo.init7.core.api.responsemodel.TvChannelListResponse;
import java.util.Date;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Query;

public interface TvApi {
  @GET("allowed/")
  Call<AllowedResponse> allowed();
  
  @GET("epg/?now__lte=true&now__gte=true")
  Call<EPGListResponse> getCurrentEPG(@Query("channel") String paramString);
  
  @GET("epg/")
  Call<EPGListResponse> getEPG(@Query("channel") String paramString);
  
  @GET("epg/")
  Call<EPGListResponse> getEPG(@Query("channel") String paramString1, @Query("limit") int paramInt1, @Query("offset") int paramInt2, @Header("If-None-Match") String paramString2);
  
  @GET("epg/")
  Call<EPGListResponse> getEPG(@Query("channel") String paramString, @Query("limit") int paramInt, @Query("now__lte") boolean paramBoolean1, @Query("now__gte") boolean paramBoolean2);
  
  @GET("replay/")
  Call replayData(String paramString, Date paramDate1, Date paramDate2);
  
  @GET("tvchannel/")
  Call<TvChannelListResponse> tvChannelList();
}
