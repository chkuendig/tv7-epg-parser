package ch.andeo.init7.core.api;

import android.content.Context;
import java.io.File;
import java.util.concurrent.TimeUnit;
import okhttp3.Cache;
import okhttp3.ConnectionPool;
import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class TvApiFactory {
  private static int CACHE_SIZE = 104857600;
  
  static  {
  
  }
  
  public static TvApi provideTvApi(Context paramContext, String paramString) {
    File file = new File(paramContext.getCacheDir(), "okhttp");
    if (file.isDirectory() || file.mkdirs())
      return (TvApi)(new Retrofit.Builder()).baseUrl("https://tv7api2.tv.init7.net/api/").addConverterFactory(GsonConverterFactory.create()).client((new OkHttpClient.Builder()).connectionPool(new ConnectionPool(15, 5L, TimeUnit.MINUTES)).cache(new Cache(file, CACHE_SIZE)).addInterceptor(new UserAgentInterceptor(paramString)).build()).build().create(TvApi.class); 
    throw new RuntimeException("Unable to create cache directory");
  }
}
