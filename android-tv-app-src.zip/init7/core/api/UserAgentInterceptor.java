package ch.andeo.init7.core.api;

import java.io.IOException;
import okhttp3.Interceptor;
import okhttp3.Response;

public class UserAgentInterceptor implements Interceptor {
  private String userAgent;
  
  public UserAgentInterceptor(String paramString) { this.userAgent = paramString; }
  
  public Response intercept(Interceptor.Chain paramChain) throws IOException { return paramChain.proceed(paramChain.request().newBuilder().header("User-Agent", this.userAgent).build()); }
}
