package ch.andeo.init7.core.model;

import android.content.Context;
import ch.andeo.init7.core.R;
import java.text.DateFormat;
import java.util.Date;
import java.util.Objects;

public class EPGInfo implements SourceProvider {
  private static EPGInfo EMPTY_EPG;
  
  public String channel_uuid;
  
  public String desc;
  
  private String startEndString = null;
  
  public String subTitle;
  
  public String title;
  
  public long tsEnd;
  
  public long tsStart;
  
  public String uuid;
  
  static  {
  
  }
  
  public static EPGInfo emptyEPG() { return EMPTY_EPG; }
  
  public static void initEmpty(Context paramContext) {
    if (EMPTY_EPG != null)
      return; 
    EMPTY_EPG = new EPGInfo();
    EPGInfo ePGInfo = EMPTY_EPG;
    ePGInfo.uuid = "EMPTY";
    ePGInfo.channel_uuid = "EMPTY";
    ePGInfo.tsStart = 0L;
    ePGInfo.tsEnd = Float.MAX_VALUE;
    ePGInfo.title = paramContext.getString(R.string.no_information);
    ePGInfo = EMPTY_EPG;
    ePGInfo.subTitle = "";
    ePGInfo.desc = paramContext.getString(R.string.no_information);
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject != null) {
      if (getClass() != paramObject.getClass())
        return false; 
      paramObject = (EPGInfo)paramObject;
      return (this.tsStart == paramObject.tsStart && this.tsEnd == paramObject.tsEnd && this.uuid.equals(paramObject.uuid) && Objects.equals(this.channel_uuid, paramObject.channel_uuid) && Objects.equals(this.title, paramObject.title) && Objects.equals(this.subTitle, paramObject.subTitle) && Objects.equals(this.desc, paramObject.desc));
    } 
    return false;
  }
  
  public String formatStartEndTime(DateFormat paramDateFormat) {
    if (this.startEndString == null) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(paramDateFormat.format(new Date(this.tsStart)));
      stringBuilder.append(" - ");
      stringBuilder.append(paramDateFormat.format(new Date(this.tsEnd)));
      this.startEndString = stringBuilder.toString();
    } 
    return this.startEndString;
  }
  
  public String getSource(boolean paramBoolean) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("https://tv7api2.tv.init7.net/api/replay/?epg_pk=");
    stringBuilder.append(this.uuid);
    return stringBuilder.toString();
  }
  
  public boolean hasMulticast() { return false; }
  
  public int hashCode() { return Objects.hash(new Object[] { this.uuid }); }
  
  public boolean isEmpty() { return equals(EMPTY_EPG); }
  
  public boolean isInPast(long paramLong) { return (this.tsStart <= paramLong); }
  
  public boolean isLive(long paramLong) { return (this.tsStart <= paramLong && paramLong <= this.tsEnd); }
}
