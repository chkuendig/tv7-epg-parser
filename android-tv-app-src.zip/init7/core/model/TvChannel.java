package ch.andeo.init7.core.model;

import com.google.gson.annotations.SerializedName;
import java.io.Serializable;
import java.util.Objects;

public class TvChannel implements Serializable, SourceProvider {
  private static TvChannel EMPTY_CHANNEL;
  
  @SerializedName("country")
  public String countryCode;
  
  @SerializedName("epg_id")
  public String epgId;
  
  @SerializedName("has_replay")
  public boolean hasReplay;
  
  public boolean hd;
  
  @SerializedName("hls_src")
  public String hlsSrc;
  
  public int langordernum;
  
  @SerializedName("language")
  public String languageCode;
  
  public long lastEPGUpdate = -1L;
  
  public String lastEtag = null;
  
  @SerializedName("logo")
  public String logoUrl;
  
  @SerializedName("src")
  public String multicastSrc;
  
  public String name;
  
  public int ordernum;
  
  @SerializedName("pk")
  public String uuid;
  
  public static TvChannel empty() {
    TvChannel tvChannel = EMPTY_CHANNEL;
    if (tvChannel != null)
      return tvChannel; 
    EMPTY_CHANNEL = new TvChannel();
    tvChannel = EMPTY_CHANNEL;
    tvChannel.uuid = "EMPTY";
    tvChannel.hasReplay = false;
    tvChannel.hlsSrc = "";
    return tvChannel;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject != null) {
      if (getClass() != paramObject.getClass())
        return false; 
      paramObject = (TvChannel)paramObject;
      return (this.hd == paramObject.hd && this.ordernum == paramObject.ordernum && this.langordernum == paramObject.langordernum && this.hasReplay == paramObject.hasReplay && this.lastEPGUpdate == paramObject.lastEPGUpdate && this.uuid.equals(paramObject.uuid) && Objects.equals(this.name, paramObject.name) && Objects.equals(this.multicastSrc, paramObject.multicastSrc) && Objects.equals(this.hlsSrc, paramObject.hlsSrc) && Objects.equals(this.epgId, paramObject.epgId) && Objects.equals(this.logoUrl, paramObject.logoUrl) && Objects.equals(this.countryCode, paramObject.countryCode) && Objects.equals(this.languageCode, paramObject.languageCode) && Objects.equals(this.lastEtag, paramObject.lastEtag));
    } 
    return false;
  }
  
  public String getSource(boolean paramBoolean) { return paramBoolean ? this.multicastSrc : this.hlsSrc; }
  
  public boolean hasMulticast() {
    String str = this.multicastSrc;
    return (str != null && !str.equals(""));
  }
  
  public int hashCode() { return Objects.hash(new Object[] { 
          this.uuid, this.name, Boolean.valueOf(this.hd), this.multicastSrc, this.hlsSrc, this.epgId, this.logoUrl, Integer.valueOf(this.ordernum), Integer.valueOf(this.langordernum), this.countryCode, 
          this.languageCode, Boolean.valueOf(this.hasReplay), this.lastEtag, Long.valueOf(this.lastEPGUpdate) }); }
  
  public boolean isEmpty() { return equals(EMPTY_CHANNEL); }
  
  public boolean prettyEqual(TvChannel paramTvChannel) {
    byte b = 0;
    if (paramTvChannel == null)
      return false; 
    int i = b;
    if (paramTvChannel.uuid.equals(this.uuid)) {
      i = b;
      if (paramTvChannel.multicastSrc.equals(this.multicastSrc)) {
        i = b;
        if (paramTvChannel.hlsSrc.equals(this.hlsSrc)) {
          i = b;
          if (paramTvChannel.name.equals(this.name)) {
            i = b;
            if (paramTvChannel.logoUrl.equals(this.logoUrl)) {
              i = b;
              if (paramTvChannel.hasReplay == this.hasReplay)
                i = 1; 
            } 
          } 
        } 
      } 
    } 
    return i;
  }
}
