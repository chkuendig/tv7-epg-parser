package ch.andeo.init7.core.model;

public interface SourceProvider {
  String getSource(boolean paramBoolean);
  
  boolean hasMulticast();
}
