package ch.andeo.init7.core;

import androidx.room.RoomDatabase;
import ch.andeo.init7.core.dao.EPGDao;
import ch.andeo.init7.core.dao.TvChannelDao;

public abstract class TvDB extends RoomDatabase {
  public abstract EPGDao epgDao();
  
  public abstract TvChannelDao tvChannelDao();
}
