package ch.andeo.init7.tvapp.databinding;

import android.util.SparseIntArray;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.widget.AppCompatButton;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import ch.andeo.init7.tvapp.androidutil.NNMediatorLiveData;
import ch.andeo.init7.tvapp.viewmodels.EPGSelectorViewModel;

public class FragmentTvplayerEpgBindingImpl extends FragmentTvplayerEpgBinding {
  private static final ViewDataBinding.IncludedLayouts sIncludes;
  
  private static final SparseIntArray sViewsWithIds = new SparseIntArray();
  
  private long mDirtyFlags = -1L;
  
  private final ConstraintLayout mboundView0;
  
  static  {
    sViewsWithIds.put(2131296508, 6);
    sViewsWithIds.put(2131296509, 7);
    sViewsWithIds.put(2131296510, 8);
    sViewsWithIds.put(2131296503, 9);
  }
  
  public FragmentTvplayerEpgBindingImpl(DataBindingComponent paramDataBindingComponent, View paramView) { this(paramDataBindingComponent, paramView, mapBindings(paramDataBindingComponent, paramView, 10, sIncludes, sViewsWithIds)); }
  
  private FragmentTvplayerEpgBindingImpl(DataBindingComponent paramDataBindingComponent, View paramView, Object[] paramArrayOfObject) {
    super(paramDataBindingComponent, paramView, 5, (ImageView)paramArrayOfObject[9], (AppCompatButton)paramArrayOfObject[4], (ImageView)paramArrayOfObject[6], (ImageView)paramArrayOfObject[7], (ImageView)paramArrayOfObject[8], (TextView)paramArrayOfObject[3], (TextView)paramArrayOfObject[5], (TextView)paramArrayOfObject[2], (TextView)paramArrayOfObject[1]);
    this.imageViewStartReplayButton.setTag(null);
    this.mboundView0 = (ConstraintLayout)paramArrayOfObject[0];
    this.mboundView0.setTag(null);
    this.textViewProgramDescription.setTag(null);
    this.textViewProgramDuration.setTag(null);
    this.textViewProgramSubtitle.setTag(null);
    this.textViewProgramTitle.setTag(null);
    setRootTag(paramView);
    invalidateAll();
  }
  
  private boolean onChangeLivedataHasReplay(NNMediatorLiveData<Boolean> paramNNMediatorLiveData, int paramInt) { // Byte code:
    //   0: iload_2
    //   1: ifne -> 27
    //   4: aload_0
    //   5: monitorenter
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mDirtyFlags : J
    //   11: ldc2_w 8
    //   14: lor
    //   15: putfield mDirtyFlags : J
    //   18: aload_0
    //   19: monitorexit
    //   20: iconst_1
    //   21: ireturn
    //   22: astore_1
    //   23: aload_0
    //   24: monitorexit
    //   25: aload_1
    //   26: athrow
    //   27: iconst_0
    //   28: ireturn
    // Exception table:
    //   from	to	target	type
    //   6	20	22	finally
    //   23	25	22	finally }
  
  private boolean onChangeLivedataProgramDesc(NNMediatorLiveData<String> paramNNMediatorLiveData, int paramInt) { // Byte code:
    //   0: iload_2
    //   1: ifne -> 27
    //   4: aload_0
    //   5: monitorenter
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mDirtyFlags : J
    //   11: ldc2_w 2
    //   14: lor
    //   15: putfield mDirtyFlags : J
    //   18: aload_0
    //   19: monitorexit
    //   20: iconst_1
    //   21: ireturn
    //   22: astore_1
    //   23: aload_0
    //   24: monitorexit
    //   25: aload_1
    //   26: athrow
    //   27: iconst_0
    //   28: ireturn
    // Exception table:
    //   from	to	target	type
    //   6	20	22	finally
    //   23	25	22	finally }
  
  private boolean onChangeLivedataProgramName(NNMediatorLiveData<String> paramNNMediatorLiveData, int paramInt) { // Byte code:
    //   0: iload_2
    //   1: ifne -> 25
    //   4: aload_0
    //   5: monitorenter
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mDirtyFlags : J
    //   11: lconst_1
    //   12: lor
    //   13: putfield mDirtyFlags : J
    //   16: aload_0
    //   17: monitorexit
    //   18: iconst_1
    //   19: ireturn
    //   20: astore_1
    //   21: aload_0
    //   22: monitorexit
    //   23: aload_1
    //   24: athrow
    //   25: iconst_0
    //   26: ireturn
    // Exception table:
    //   from	to	target	type
    //   6	18	20	finally
    //   21	23	20	finally }
  
  private boolean onChangeLivedataProgramSubtitle(NNMediatorLiveData<String> paramNNMediatorLiveData, int paramInt) { // Byte code:
    //   0: iload_2
    //   1: ifne -> 27
    //   4: aload_0
    //   5: monitorenter
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mDirtyFlags : J
    //   11: ldc2_w 16
    //   14: lor
    //   15: putfield mDirtyFlags : J
    //   18: aload_0
    //   19: monitorexit
    //   20: iconst_1
    //   21: ireturn
    //   22: astore_1
    //   23: aload_0
    //   24: monitorexit
    //   25: aload_1
    //   26: athrow
    //   27: iconst_0
    //   28: ireturn
    // Exception table:
    //   from	to	target	type
    //   6	20	22	finally
    //   23	25	22	finally }
  
  private boolean onChangeLivedataProgramTime(NNMediatorLiveData<String> paramNNMediatorLiveData, int paramInt) { // Byte code:
    //   0: iload_2
    //   1: ifne -> 27
    //   4: aload_0
    //   5: monitorenter
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mDirtyFlags : J
    //   11: ldc2_w 4
    //   14: lor
    //   15: putfield mDirtyFlags : J
    //   18: aload_0
    //   19: monitorexit
    //   20: iconst_1
    //   21: ireturn
    //   22: astore_1
    //   23: aload_0
    //   24: monitorexit
    //   25: aload_1
    //   26: athrow
    //   27: iconst_0
    //   28: ireturn
    // Exception table:
    //   from	to	target	type
    //   6	20	22	finally
    //   23	25	22	finally }
  
  protected void executeBindings() { // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mDirtyFlags : J
    //   6: lstore_2
    //   7: aload_0
    //   8: lconst_0
    //   9: putfield mDirtyFlags : J
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_0
    //   15: getfield mLivedata : Lch/andeo/init7/tvapp/viewmodels/EPGSelectorViewModel;
    //   18: astore #11
    //   20: ldc2_w 127
    //   23: lload_2
    //   24: land
    //   25: lconst_0
    //   26: lcmp
    //   27: ifeq -> 379
    //   30: lload_2
    //   31: ldc2_w 97
    //   34: land
    //   35: lconst_0
    //   36: lcmp
    //   37: ifeq -> 84
    //   40: aload #11
    //   42: ifnull -> 55
    //   45: aload #11
    //   47: invokevirtual getProgramName : ()Lch/andeo/init7/tvapp/androidutil/NNMediatorLiveData;
    //   50: astore #7
    //   52: goto -> 58
    //   55: aconst_null
    //   56: astore #7
    //   58: aload_0
    //   59: iconst_0
    //   60: aload #7
    //   62: invokevirtual updateLiveDataRegistration : (ILandroidx/lifecycle/LiveData;)Z
    //   65: pop
    //   66: aload #7
    //   68: ifnull -> 84
    //   71: aload #7
    //   73: invokevirtual getValue : ()Ljava/lang/Object;
    //   76: checkcast java/lang/String
    //   79: astore #7
    //   81: goto -> 87
    //   84: aconst_null
    //   85: astore #7
    //   87: lload_2
    //   88: ldc2_w 98
    //   91: land
    //   92: lconst_0
    //   93: lcmp
    //   94: ifeq -> 141
    //   97: aload #11
    //   99: ifnull -> 112
    //   102: aload #11
    //   104: invokevirtual getProgramDesc : ()Lch/andeo/init7/tvapp/androidutil/NNMediatorLiveData;
    //   107: astore #8
    //   109: goto -> 115
    //   112: aconst_null
    //   113: astore #8
    //   115: aload_0
    //   116: iconst_1
    //   117: aload #8
    //   119: invokevirtual updateLiveDataRegistration : (ILandroidx/lifecycle/LiveData;)Z
    //   122: pop
    //   123: aload #8
    //   125: ifnull -> 141
    //   128: aload #8
    //   130: invokevirtual getValue : ()Ljava/lang/Object;
    //   133: checkcast java/lang/String
    //   136: astore #8
    //   138: goto -> 144
    //   141: aconst_null
    //   142: astore #8
    //   144: lload_2
    //   145: ldc2_w 100
    //   148: land
    //   149: lconst_0
    //   150: lcmp
    //   151: ifeq -> 198
    //   154: aload #11
    //   156: ifnull -> 169
    //   159: aload #11
    //   161: invokevirtual getProgramTime : ()Lch/andeo/init7/tvapp/androidutil/NNMediatorLiveData;
    //   164: astore #9
    //   166: goto -> 172
    //   169: aconst_null
    //   170: astore #9
    //   172: aload_0
    //   173: iconst_2
    //   174: aload #9
    //   176: invokevirtual updateLiveDataRegistration : (ILandroidx/lifecycle/LiveData;)Z
    //   179: pop
    //   180: aload #9
    //   182: ifnull -> 198
    //   185: aload #9
    //   187: invokevirtual getValue : ()Ljava/lang/Object;
    //   190: checkcast java/lang/String
    //   193: astore #9
    //   195: goto -> 201
    //   198: aconst_null
    //   199: astore #9
    //   201: lload_2
    //   202: ldc2_w 104
    //   205: land
    //   206: lconst_0
    //   207: lcmp
    //   208: istore_1
    //   209: iload_1
    //   210: ifeq -> 317
    //   213: aload #11
    //   215: ifnull -> 228
    //   218: aload #11
    //   220: invokevirtual getHasReplay : ()Lch/andeo/init7/tvapp/androidutil/NNMediatorLiveData;
    //   223: astore #10
    //   225: goto -> 231
    //   228: aconst_null
    //   229: astore #10
    //   231: aload_0
    //   232: iconst_3
    //   233: aload #10
    //   235: invokevirtual updateLiveDataRegistration : (ILandroidx/lifecycle/LiveData;)Z
    //   238: pop
    //   239: aload #10
    //   241: ifnull -> 257
    //   244: aload #10
    //   246: invokevirtual getValue : ()Ljava/lang/Object;
    //   249: checkcast java/lang/Boolean
    //   252: astore #10
    //   254: goto -> 260
    //   257: aconst_null
    //   258: astore #10
    //   260: aload #10
    //   262: invokestatic safeUnbox : (Ljava/lang/Boolean;)Z
    //   265: istore #6
    //   267: lload_2
    //   268: lstore #4
    //   270: iload_1
    //   271: ifeq -> 298
    //   274: iload #6
    //   276: ifeq -> 287
    //   279: ldc2_w 256
    //   282: lstore #4
    //   284: goto -> 292
    //   287: ldc2_w 128
    //   290: lstore #4
    //   292: lload_2
    //   293: lload #4
    //   295: lor
    //   296: lstore #4
    //   298: iload #6
    //   300: ifeq -> 308
    //   303: iconst_0
    //   304: istore_1
    //   305: goto -> 311
    //   308: bipush #8
    //   310: istore_1
    //   311: lload #4
    //   313: lstore_2
    //   314: goto -> 319
    //   317: iconst_0
    //   318: istore_1
    //   319: lload_2
    //   320: ldc2_w 112
    //   323: land
    //   324: lconst_0
    //   325: lcmp
    //   326: ifeq -> 373
    //   329: aload #11
    //   331: ifnull -> 344
    //   334: aload #11
    //   336: invokevirtual getProgramSubtitle : ()Lch/andeo/init7/tvapp/androidutil/NNMediatorLiveData;
    //   339: astore #10
    //   341: goto -> 347
    //   344: aconst_null
    //   345: astore #10
    //   347: aload_0
    //   348: iconst_4
    //   349: aload #10
    //   351: invokevirtual updateLiveDataRegistration : (ILandroidx/lifecycle/LiveData;)Z
    //   354: pop
    //   355: aload #10
    //   357: ifnull -> 373
    //   360: aload #10
    //   362: invokevirtual getValue : ()Ljava/lang/Object;
    //   365: checkcast java/lang/String
    //   368: astore #10
    //   370: goto -> 393
    //   373: aconst_null
    //   374: astore #10
    //   376: goto -> 393
    //   379: aconst_null
    //   380: astore #10
    //   382: aconst_null
    //   383: astore #7
    //   385: aconst_null
    //   386: astore #8
    //   388: iconst_0
    //   389: istore_1
    //   390: aconst_null
    //   391: astore #9
    //   393: lload_2
    //   394: ldc2_w 104
    //   397: land
    //   398: lconst_0
    //   399: lcmp
    //   400: ifeq -> 411
    //   403: aload_0
    //   404: getfield imageViewStartReplayButton : Landroidx/appcompat/widget/AppCompatButton;
    //   407: iload_1
    //   408: invokevirtual setVisibility : (I)V
    //   411: ldc2_w 98
    //   414: lload_2
    //   415: land
    //   416: lconst_0
    //   417: lcmp
    //   418: ifeq -> 430
    //   421: aload_0
    //   422: getfield textViewProgramDescription : Landroid/widget/TextView;
    //   425: aload #8
    //   427: invokestatic setText : (Landroid/widget/TextView;Ljava/lang/CharSequence;)V
    //   430: lload_2
    //   431: ldc2_w 100
    //   434: land
    //   435: lconst_0
    //   436: lcmp
    //   437: ifeq -> 449
    //   440: aload_0
    //   441: getfield textViewProgramDuration : Landroid/widget/TextView;
    //   444: aload #9
    //   446: invokestatic setText : (Landroid/widget/TextView;Ljava/lang/CharSequence;)V
    //   449: ldc2_w 112
    //   452: lload_2
    //   453: land
    //   454: lconst_0
    //   455: lcmp
    //   456: ifeq -> 468
    //   459: aload_0
    //   460: getfield textViewProgramSubtitle : Landroid/widget/TextView;
    //   463: aload #10
    //   465: invokestatic setText : (Landroid/widget/TextView;Ljava/lang/CharSequence;)V
    //   468: lload_2
    //   469: ldc2_w 97
    //   472: land
    //   473: lconst_0
    //   474: lcmp
    //   475: ifeq -> 487
    //   478: aload_0
    //   479: getfield textViewProgramTitle : Landroid/widget/TextView;
    //   482: aload #7
    //   484: invokestatic setText : (Landroid/widget/TextView;Ljava/lang/CharSequence;)V
    //   487: return
    //   488: astore #7
    //   490: aload_0
    //   491: monitorexit
    //   492: aload #7
    //   494: athrow
    // Exception table:
    //   from	to	target	type
    //   2	14	488	finally
    //   490	492	488	finally }
  
  public boolean hasPendingBindings() { // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mDirtyFlags : J
    //   6: lconst_0
    //   7: lcmp
    //   8: ifeq -> 15
    //   11: aload_0
    //   12: monitorexit
    //   13: iconst_1
    //   14: ireturn
    //   15: aload_0
    //   16: monitorexit
    //   17: iconst_0
    //   18: ireturn
    //   19: astore_1
    //   20: aload_0
    //   21: monitorexit
    //   22: aload_1
    //   23: athrow
    // Exception table:
    //   from	to	target	type
    //   2	13	19	finally
    //   15	17	19	finally
    //   20	22	19	finally }
  
  public void invalidateAll() { // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: ldc2_w 64
    //   6: putfield mDirtyFlags : J
    //   9: aload_0
    //   10: monitorexit
    //   11: aload_0
    //   12: invokevirtual requestRebind : ()V
    //   15: return
    //   16: astore_1
    //   17: aload_0
    //   18: monitorexit
    //   19: aload_1
    //   20: athrow
    // Exception table:
    //   from	to	target	type
    //   2	11	16	finally
    //   17	19	16	finally }
  
  protected boolean onFieldChange(int paramInt1, Object paramObject, int paramInt2) { return (paramInt1 != 0) ? ((paramInt1 != 1) ? ((paramInt1 != 2) ? ((paramInt1 != 3) ? ((paramInt1 != 4) ? false : onChangeLivedataProgramSubtitle((NNMediatorLiveData)paramObject, paramInt2)) : onChangeLivedataHasReplay((NNMediatorLiveData)paramObject, paramInt2)) : onChangeLivedataProgramTime((NNMediatorLiveData)paramObject, paramInt2)) : onChangeLivedataProgramDesc((NNMediatorLiveData)paramObject, paramInt2)) : onChangeLivedataProgramName((NNMediatorLiveData)paramObject, paramInt2); }
  
  public void setLivedata(EPGSelectorViewModel paramEPGSelectorViewModel) { // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: putfield mLivedata : Lch/andeo/init7/tvapp/viewmodels/EPGSelectorViewModel;
    //   5: aload_0
    //   6: monitorenter
    //   7: aload_0
    //   8: aload_0
    //   9: getfield mDirtyFlags : J
    //   12: ldc2_w 32
    //   15: lor
    //   16: putfield mDirtyFlags : J
    //   19: aload_0
    //   20: monitorexit
    //   21: aload_0
    //   22: iconst_1
    //   23: invokevirtual notifyPropertyChanged : (I)V
    //   26: aload_0
    //   27: invokespecial requestRebind : ()V
    //   30: return
    //   31: astore_1
    //   32: aload_0
    //   33: monitorexit
    //   34: aload_1
    //   35: athrow
    // Exception table:
    //   from	to	target	type
    //   7	21	31	finally
    //   32	34	31	finally }
  
  public boolean setVariable(int paramInt, Object paramObject) {
    if (1 == paramInt) {
      setLivedata((EPGSelectorViewModel)paramObject);
      return true;
    } 
    return false;
  }
}
