package ch.andeo.init7.tvapp.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.widget.AppCompatButton;
import androidx.databinding.Bindable;
import androidx.databinding.DataBindingUtil;
import androidx.databinding.ViewDataBinding;
import ch.andeo.init7.tvapp.viewmodels.EPGSelectorViewModel;

public abstract class FragmentTvplayerEpgBinding extends ViewDataBinding {
  public final ImageView imageViewChannel;
  
  public final AppCompatButton imageViewStartReplayButton;
  
  public final ImageView indicatorLeft;
  
  public final ImageView indicatorRight;
  
  public final ImageView indicatorTop;
  
  @Bindable
  protected EPGSelectorViewModel mLivedata;
  
  public final TextView textViewProgramDescription;
  
  public final TextView textViewProgramDuration;
  
  public final TextView textViewProgramSubtitle;
  
  public final TextView textViewProgramTitle;
  
  protected FragmentTvplayerEpgBinding(Object paramObject, View paramView, int paramInt, ImageView paramImageView1, AppCompatButton paramAppCompatButton, ImageView paramImageView2, ImageView paramImageView3, ImageView paramImageView4, TextView paramTextView1, TextView paramTextView2, TextView paramTextView3, TextView paramTextView4) {
    super(paramObject, paramView, paramInt);
    this.imageViewChannel = paramImageView1;
    this.imageViewStartReplayButton = paramAppCompatButton;
    this.indicatorLeft = paramImageView2;
    this.indicatorRight = paramImageView3;
    this.indicatorTop = paramImageView4;
    this.textViewProgramDescription = paramTextView1;
    this.textViewProgramDuration = paramTextView2;
    this.textViewProgramSubtitle = paramTextView3;
    this.textViewProgramTitle = paramTextView4;
  }
  
  public static FragmentTvplayerEpgBinding bind(View paramView) { return bind(paramView, DataBindingUtil.getDefaultComponent()); }
  
  @Deprecated
  public static FragmentTvplayerEpgBinding bind(View paramView, Object paramObject) { return (FragmentTvplayerEpgBinding)bind(paramObject, paramView, 2131492906); }
  
  public static FragmentTvplayerEpgBinding inflate(LayoutInflater paramLayoutInflater) { return inflate(paramLayoutInflater, DataBindingUtil.getDefaultComponent()); }
  
  public static FragmentTvplayerEpgBinding inflate(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, boolean paramBoolean) { return inflate(paramLayoutInflater, paramViewGroup, paramBoolean, DataBindingUtil.getDefaultComponent()); }
  
  @Deprecated
  public static FragmentTvplayerEpgBinding inflate(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, boolean paramBoolean, Object paramObject) { return (FragmentTvplayerEpgBinding)ViewDataBinding.inflateInternal(paramLayoutInflater, 2131492906, paramViewGroup, paramBoolean, paramObject); }
  
  @Deprecated
  public static FragmentTvplayerEpgBinding inflate(LayoutInflater paramLayoutInflater, Object paramObject) { return (FragmentTvplayerEpgBinding)ViewDataBinding.inflateInternal(paramLayoutInflater, 2131492906, null, false, paramObject); }
  
  public EPGSelectorViewModel getLivedata() { return this.mLivedata; }
  
  public abstract void setLivedata(EPGSelectorViewModel paramEPGSelectorViewModel);
}
