package ch.andeo.init7.tvapp.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.databinding.Bindable;
import androidx.databinding.DataBindingUtil;
import androidx.databinding.ViewDataBinding;
import ch.andeo.init7.tvapp.ui.MultiStateConstraintLayout;

public abstract class LayoutChannelListitemBinding extends ViewDataBinding {
  public final MultiStateConstraintLayout constraintLayoutWrapper;
  
  public final ImageView imageViewChannelLogo;
  
  @Bindable
  protected String mChannelName;
  
  public final TextView textViewChannelName;
  
  protected LayoutChannelListitemBinding(Object paramObject, View paramView, int paramInt, MultiStateConstraintLayout paramMultiStateConstraintLayout, ImageView paramImageView, TextView paramTextView) {
    super(paramObject, paramView, paramInt);
    this.constraintLayoutWrapper = paramMultiStateConstraintLayout;
    this.imageViewChannelLogo = paramImageView;
    this.textViewChannelName = paramTextView;
  }
  
  public static LayoutChannelListitemBinding bind(View paramView) { return bind(paramView, DataBindingUtil.getDefaultComponent()); }
  
  @Deprecated
  public static LayoutChannelListitemBinding bind(View paramView, Object paramObject) { return (LayoutChannelListitemBinding)bind(paramObject, paramView, 2131492908); }
  
  public static LayoutChannelListitemBinding inflate(LayoutInflater paramLayoutInflater) { return inflate(paramLayoutInflater, DataBindingUtil.getDefaultComponent()); }
  
  public static LayoutChannelListitemBinding inflate(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, boolean paramBoolean) { return inflate(paramLayoutInflater, paramViewGroup, paramBoolean, DataBindingUtil.getDefaultComponent()); }
  
  @Deprecated
  public static LayoutChannelListitemBinding inflate(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, boolean paramBoolean, Object paramObject) { return (LayoutChannelListitemBinding)ViewDataBinding.inflateInternal(paramLayoutInflater, 2131492908, paramViewGroup, paramBoolean, paramObject); }
  
  @Deprecated
  public static LayoutChannelListitemBinding inflate(LayoutInflater paramLayoutInflater, Object paramObject) { return (LayoutChannelListitemBinding)ViewDataBinding.inflateInternal(paramLayoutInflater, 2131492908, null, false, paramObject); }
  
  public String getChannelName() { return this.mChannelName; }
  
  public abstract void setChannelName(String paramString);
}
