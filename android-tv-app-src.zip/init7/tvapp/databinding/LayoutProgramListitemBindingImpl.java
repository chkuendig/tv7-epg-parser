package ch.andeo.init7.tvapp.databinding;

import android.util.SparseIntArray;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import ch.andeo.init7.core.model.EPGInfo;
import ch.andeo.init7.tvapp.ui.MultiStateConstraintLayout;

public class LayoutProgramListitemBindingImpl extends LayoutProgramListitemBinding {
  private static final ViewDataBinding.IncludedLayouts sIncludes;
  
  private static final SparseIntArray sViewsWithIds;
  
  private long mDirtyFlags = -1L;
  
  static  {
  
  }
  
  public LayoutProgramListitemBindingImpl(DataBindingComponent paramDataBindingComponent, View paramView) { this(paramDataBindingComponent, paramView, mapBindings(paramDataBindingComponent, paramView, 4, sIncludes, sViewsWithIds)); }
  
  private LayoutProgramListitemBindingImpl(DataBindingComponent paramDataBindingComponent, View paramView, Object[] paramArrayOfObject) {
    super(paramDataBindingComponent, paramView, 0, (MultiStateConstraintLayout)paramArrayOfObject[0], (ImageView)paramArrayOfObject[3], (TextView)paramArrayOfObject[2], (TextView)paramArrayOfObject[1]);
    this.constraintLayoutWrapper.setTag(null);
    this.imageViewEpgReplayIcon.setTag(null);
    this.textViewShowTime.setTag(null);
    this.textViewShowTitle.setTag(null);
    setRootTag(paramView);
    invalidateAll();
  }
  
  protected void executeBindings() { // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mDirtyFlags : J
    //   6: lstore #6
    //   8: aload_0
    //   9: lconst_0
    //   10: putfield mDirtyFlags : J
    //   13: aload_0
    //   14: monitorexit
    //   15: aconst_null
    //   16: astore #10
    //   18: aload_0
    //   19: getfield mHasReplay : Ljava/lang/Boolean;
    //   22: astore #9
    //   24: aload_0
    //   25: getfield mShowTime : Ljava/lang/String;
    //   28: astore #11
    //   30: aload_0
    //   31: getfield mEpg : Lch/andeo/init7/core/model/EPGInfo;
    //   34: astore #12
    //   36: iconst_0
    //   37: istore_2
    //   38: lload #6
    //   40: ldc2_w 9
    //   43: land
    //   44: lconst_0
    //   45: lcmp
    //   46: istore_3
    //   47: lload #6
    //   49: lstore #4
    //   51: iload_2
    //   52: istore_1
    //   53: iload_3
    //   54: ifeq -> 110
    //   57: aload #9
    //   59: invokestatic safeUnbox : (Ljava/lang/Boolean;)Z
    //   62: istore #8
    //   64: lload #6
    //   66: lstore #4
    //   68: iload_3
    //   69: ifeq -> 97
    //   72: iload #8
    //   74: ifeq -> 85
    //   77: ldc2_w 32
    //   80: lstore #4
    //   82: goto -> 90
    //   85: ldc2_w 16
    //   88: lstore #4
    //   90: lload #6
    //   92: lload #4
    //   94: lor
    //   95: lstore #4
    //   97: iload #8
    //   99: ifeq -> 107
    //   102: iload_2
    //   103: istore_1
    //   104: goto -> 110
    //   107: bipush #8
    //   109: istore_1
    //   110: ldc2_w 12
    //   113: lload #4
    //   115: land
    //   116: lconst_0
    //   117: lcmp
    //   118: istore_2
    //   119: aload #10
    //   121: astore #9
    //   123: iload_2
    //   124: ifeq -> 143
    //   127: aload #10
    //   129: astore #9
    //   131: aload #12
    //   133: ifnull -> 143
    //   136: aload #12
    //   138: getfield title : Ljava/lang/String;
    //   141: astore #9
    //   143: lload #4
    //   145: ldc2_w 9
    //   148: land
    //   149: lconst_0
    //   150: lcmp
    //   151: ifeq -> 162
    //   154: aload_0
    //   155: getfield imageViewEpgReplayIcon : Landroid/widget/ImageView;
    //   158: iload_1
    //   159: invokevirtual setVisibility : (I)V
    //   162: ldc2_w 10
    //   165: lload #4
    //   167: land
    //   168: lconst_0
    //   169: lcmp
    //   170: ifeq -> 182
    //   173: aload_0
    //   174: getfield textViewShowTime : Landroid/widget/TextView;
    //   177: aload #11
    //   179: invokestatic setText : (Landroid/widget/TextView;Ljava/lang/CharSequence;)V
    //   182: iload_2
    //   183: ifeq -> 195
    //   186: aload_0
    //   187: getfield textViewShowTitle : Landroid/widget/TextView;
    //   190: aload #9
    //   192: invokestatic setText : (Landroid/widget/TextView;Ljava/lang/CharSequence;)V
    //   195: return
    //   196: astore #9
    //   198: aload_0
    //   199: monitorexit
    //   200: aload #9
    //   202: athrow
    // Exception table:
    //   from	to	target	type
    //   2	15	196	finally
    //   198	200	196	finally }
  
  public boolean hasPendingBindings() { // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mDirtyFlags : J
    //   6: lconst_0
    //   7: lcmp
    //   8: ifeq -> 15
    //   11: aload_0
    //   12: monitorexit
    //   13: iconst_1
    //   14: ireturn
    //   15: aload_0
    //   16: monitorexit
    //   17: iconst_0
    //   18: ireturn
    //   19: astore_1
    //   20: aload_0
    //   21: monitorexit
    //   22: aload_1
    //   23: athrow
    // Exception table:
    //   from	to	target	type
    //   2	13	19	finally
    //   15	17	19	finally
    //   20	22	19	finally }
  
  public void invalidateAll() { // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: ldc2_w 8
    //   6: putfield mDirtyFlags : J
    //   9: aload_0
    //   10: monitorexit
    //   11: aload_0
    //   12: invokevirtual requestRebind : ()V
    //   15: return
    //   16: astore_1
    //   17: aload_0
    //   18: monitorexit
    //   19: aload_1
    //   20: athrow
    // Exception table:
    //   from	to	target	type
    //   2	11	16	finally
    //   17	19	16	finally }
  
  protected boolean onFieldChange(int paramInt1, Object paramObject, int paramInt2) { return false; }
  
  public void setEpg(EPGInfo paramEPGInfo) { // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: putfield mEpg : Lch/andeo/init7/core/model/EPGInfo;
    //   5: aload_0
    //   6: monitorenter
    //   7: aload_0
    //   8: aload_0
    //   9: getfield mDirtyFlags : J
    //   12: ldc2_w 4
    //   15: lor
    //   16: putfield mDirtyFlags : J
    //   19: aload_0
    //   20: monitorexit
    //   21: aload_0
    //   22: iconst_5
    //   23: invokevirtual notifyPropertyChanged : (I)V
    //   26: aload_0
    //   27: invokespecial requestRebind : ()V
    //   30: return
    //   31: astore_1
    //   32: aload_0
    //   33: monitorexit
    //   34: aload_1
    //   35: athrow
    // Exception table:
    //   from	to	target	type
    //   7	21	31	finally
    //   32	34	31	finally }
  
  public void setHasReplay(Boolean paramBoolean) { // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: putfield mHasReplay : Ljava/lang/Boolean;
    //   5: aload_0
    //   6: monitorenter
    //   7: aload_0
    //   8: aload_0
    //   9: getfield mDirtyFlags : J
    //   12: lconst_1
    //   13: lor
    //   14: putfield mDirtyFlags : J
    //   17: aload_0
    //   18: monitorexit
    //   19: aload_0
    //   20: bipush #6
    //   22: invokevirtual notifyPropertyChanged : (I)V
    //   25: aload_0
    //   26: invokespecial requestRebind : ()V
    //   29: return
    //   30: astore_1
    //   31: aload_0
    //   32: monitorexit
    //   33: aload_1
    //   34: athrow
    // Exception table:
    //   from	to	target	type
    //   7	19	30	finally
    //   31	33	30	finally }
  
  public void setShowTime(String paramString) { // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: putfield mShowTime : Ljava/lang/String;
    //   5: aload_0
    //   6: monitorenter
    //   7: aload_0
    //   8: aload_0
    //   9: getfield mDirtyFlags : J
    //   12: ldc2_w 2
    //   15: lor
    //   16: putfield mDirtyFlags : J
    //   19: aload_0
    //   20: monitorexit
    //   21: aload_0
    //   22: iconst_3
    //   23: invokevirtual notifyPropertyChanged : (I)V
    //   26: aload_0
    //   27: invokespecial requestRebind : ()V
    //   30: return
    //   31: astore_1
    //   32: aload_0
    //   33: monitorexit
    //   34: aload_1
    //   35: athrow
    // Exception table:
    //   from	to	target	type
    //   7	21	31	finally
    //   32	34	31	finally }
  
  public boolean setVariable(int paramInt, Object paramObject) {
    if (6 == paramInt) {
      setHasReplay((Boolean)paramObject);
    } else if (3 == paramInt) {
      setShowTime((String)paramObject);
    } else {
      if (5 == paramInt) {
        setEpg((EPGInfo)paramObject);
        return true;
      } 
      return false;
    } 
    return true;
  }
}
