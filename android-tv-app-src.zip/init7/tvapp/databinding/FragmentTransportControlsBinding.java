package ch.andeo.init7.tvapp.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import androidx.databinding.Bindable;
import androidx.databinding.DataBindingUtil;
import androidx.databinding.ViewDataBinding;
import ch.andeo.init7.tvapp.ui.TintedImageButton;
import ch.andeo.init7.tvapp.viewmodels.TVPlayerControlsViewModel;

public abstract class FragmentTransportControlsBinding extends ViewDataBinding {
  public final TintedImageButton buttonGoToLive;
  
  public final TintedImageButton buttonPlay;
  
  public final TintedImageButton buttonTracksAudio;
  
  public final TintedImageButton buttonTracksText;
  
  public final ImageView imageViewChannel;
  
  public final ImageView imageViewIsReplay;
  
  public final ImageView indicatorArrowDown;
  
  @Bindable
  protected TVPlayerControlsViewModel mVm;
  
  public final SeekBar seekBar;
  
  public final TextView textViewCurrentTime;
  
  public final TextView textViewGoToLiveLabel;
  
  public final TextView textViewProgramName;
  
  public final TextView textViewProgramSubtitle;
  
  public final TextView textViewTracksAudioLabel;
  
  public final TextView textViewTracksTextLabel;
  
  protected FragmentTransportControlsBinding(Object paramObject, View paramView, int paramInt, TintedImageButton paramTintedImageButton1, TintedImageButton paramTintedImageButton2, TintedImageButton paramTintedImageButton3, TintedImageButton paramTintedImageButton4, ImageView paramImageView1, ImageView paramImageView2, ImageView paramImageView3, SeekBar paramSeekBar, TextView paramTextView1, TextView paramTextView2, TextView paramTextView3, TextView paramTextView4, TextView paramTextView5, TextView paramTextView6) {
    super(paramObject, paramView, paramInt);
    this.buttonGoToLive = paramTintedImageButton1;
    this.buttonPlay = paramTintedImageButton2;
    this.buttonTracksAudio = paramTintedImageButton3;
    this.buttonTracksText = paramTintedImageButton4;
    this.imageViewChannel = paramImageView1;
    this.imageViewIsReplay = paramImageView2;
    this.indicatorArrowDown = paramImageView3;
    this.seekBar = paramSeekBar;
    this.textViewCurrentTime = paramTextView1;
    this.textViewGoToLiveLabel = paramTextView2;
    this.textViewProgramName = paramTextView3;
    this.textViewProgramSubtitle = paramTextView4;
    this.textViewTracksAudioLabel = paramTextView5;
    this.textViewTracksTextLabel = paramTextView6;
  }
  
  public static FragmentTransportControlsBinding bind(View paramView) { return bind(paramView, DataBindingUtil.getDefaultComponent()); }
  
  @Deprecated
  public static FragmentTransportControlsBinding bind(View paramView, Object paramObject) { return (FragmentTransportControlsBinding)bind(paramObject, paramView, 2131492904); }
  
  public static FragmentTransportControlsBinding inflate(LayoutInflater paramLayoutInflater) { return inflate(paramLayoutInflater, DataBindingUtil.getDefaultComponent()); }
  
  public static FragmentTransportControlsBinding inflate(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, boolean paramBoolean) { return inflate(paramLayoutInflater, paramViewGroup, paramBoolean, DataBindingUtil.getDefaultComponent()); }
  
  @Deprecated
  public static FragmentTransportControlsBinding inflate(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, boolean paramBoolean, Object paramObject) { return (FragmentTransportControlsBinding)ViewDataBinding.inflateInternal(paramLayoutInflater, 2131492904, paramViewGroup, paramBoolean, paramObject); }
  
  @Deprecated
  public static FragmentTransportControlsBinding inflate(LayoutInflater paramLayoutInflater, Object paramObject) { return (FragmentTransportControlsBinding)ViewDataBinding.inflateInternal(paramLayoutInflater, 2131492904, null, false, paramObject); }
  
  public TVPlayerControlsViewModel getVm() { return this.mVm; }
  
  public abstract void setVm(TVPlayerControlsViewModel paramTVPlayerControlsViewModel);
}
