package ch.andeo.init7.tvapp.databinding;

import android.util.SparseIntArray;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import ch.andeo.init7.tvapp.ui.MultiStateConstraintLayout;

public class LayoutChannelListitemBindingImpl extends LayoutChannelListitemBinding {
  private static final ViewDataBinding.IncludedLayouts sIncludes;
  
  private static final SparseIntArray sViewsWithIds;
  
  private long mDirtyFlags = -1L;
  
  static  {
  
  }
  
  public LayoutChannelListitemBindingImpl(DataBindingComponent paramDataBindingComponent, View paramView) { this(paramDataBindingComponent, paramView, mapBindings(paramDataBindingComponent, paramView, 3, sIncludes, sViewsWithIds)); }
  
  private LayoutChannelListitemBindingImpl(DataBindingComponent paramDataBindingComponent, View paramView, Object[] paramArrayOfObject) {
    super(paramDataBindingComponent, paramView, 0, (MultiStateConstraintLayout)paramArrayOfObject[0], (ImageView)paramArrayOfObject[1], (TextView)paramArrayOfObject[2]);
    this.constraintLayoutWrapper.setTag(null);
    this.imageViewChannelLogo.setTag(null);
    this.textViewChannelName.setTag(null);
    setRootTag(paramView);
    invalidateAll();
  }
  
  protected void executeBindings() { // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mDirtyFlags : J
    //   6: lstore_1
    //   7: aload_0
    //   8: lconst_0
    //   9: putfield mDirtyFlags : J
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_0
    //   15: getfield mChannelName : Ljava/lang/String;
    //   18: astore_3
    //   19: lload_1
    //   20: ldc2_w 3
    //   23: land
    //   24: lconst_0
    //   25: lcmp
    //   26: ifeq -> 52
    //   29: invokestatic getBuildSdkInt : ()I
    //   32: iconst_4
    //   33: if_icmplt -> 44
    //   36: aload_0
    //   37: getfield imageViewChannelLogo : Landroid/widget/ImageView;
    //   40: aload_3
    //   41: invokevirtual setContentDescription : (Ljava/lang/CharSequence;)V
    //   44: aload_0
    //   45: getfield textViewChannelName : Landroid/widget/TextView;
    //   48: aload_3
    //   49: invokestatic setText : (Landroid/widget/TextView;Ljava/lang/CharSequence;)V
    //   52: return
    //   53: astore_3
    //   54: aload_0
    //   55: monitorexit
    //   56: aload_3
    //   57: athrow
    // Exception table:
    //   from	to	target	type
    //   2	14	53	finally
    //   54	56	53	finally }
  
  public boolean hasPendingBindings() { // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mDirtyFlags : J
    //   6: lconst_0
    //   7: lcmp
    //   8: ifeq -> 15
    //   11: aload_0
    //   12: monitorexit
    //   13: iconst_1
    //   14: ireturn
    //   15: aload_0
    //   16: monitorexit
    //   17: iconst_0
    //   18: ireturn
    //   19: astore_1
    //   20: aload_0
    //   21: monitorexit
    //   22: aload_1
    //   23: athrow
    // Exception table:
    //   from	to	target	type
    //   2	13	19	finally
    //   15	17	19	finally
    //   20	22	19	finally }
  
  public void invalidateAll() { // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: ldc2_w 2
    //   6: putfield mDirtyFlags : J
    //   9: aload_0
    //   10: monitorexit
    //   11: aload_0
    //   12: invokevirtual requestRebind : ()V
    //   15: return
    //   16: astore_1
    //   17: aload_0
    //   18: monitorexit
    //   19: aload_1
    //   20: athrow
    // Exception table:
    //   from	to	target	type
    //   2	11	16	finally
    //   17	19	16	finally }
  
  protected boolean onFieldChange(int paramInt1, Object paramObject, int paramInt2) { return false; }
  
  public void setChannelName(String paramString) { // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: putfield mChannelName : Ljava/lang/String;
    //   5: aload_0
    //   6: monitorenter
    //   7: aload_0
    //   8: aload_0
    //   9: getfield mDirtyFlags : J
    //   12: lconst_1
    //   13: lor
    //   14: putfield mDirtyFlags : J
    //   17: aload_0
    //   18: monitorexit
    //   19: aload_0
    //   20: iconst_4
    //   21: invokevirtual notifyPropertyChanged : (I)V
    //   24: aload_0
    //   25: invokespecial requestRebind : ()V
    //   28: return
    //   29: astore_1
    //   30: aload_0
    //   31: monitorexit
    //   32: aload_1
    //   33: athrow
    // Exception table:
    //   from	to	target	type
    //   7	19	29	finally
    //   30	32	29	finally }
  
  public boolean setVariable(int paramInt, Object paramObject) {
    if (4 == paramInt) {
      setChannelName((String)paramObject);
      return true;
    } 
    return false;
  }
}
