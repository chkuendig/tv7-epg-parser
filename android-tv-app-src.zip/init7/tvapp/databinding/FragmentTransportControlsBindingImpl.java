package ch.andeo.init7.tvapp.databinding;

import android.util.SparseIntArray;
import android.view.View;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import androidx.lifecycle.LiveData;
import ch.andeo.init7.tvapp.generated.callback.OnClickListener;
import ch.andeo.init7.tvapp.ui.TintedImageButton;
import ch.andeo.init7.tvapp.viewmodels.TVPlayerControlsViewModel;

public class FragmentTransportControlsBindingImpl extends FragmentTransportControlsBinding implements OnClickListener.Listener {
  private static final ViewDataBinding.IncludedLayouts sIncludes;
  
  private static final SparseIntArray sViewsWithIds = new SparseIntArray();
  
  private final View.OnClickListener mCallback1;
  
  private final View.OnClickListener mCallback2;
  
  private long mDirtyFlags = -1L;
  
  private final ConstraintLayout mboundView0;
  
  static  {
    sViewsWithIds.put(2131296357, 8);
    sViewsWithIds.put(2131296695, 9);
    sViewsWithIds.put(2131296356, 10);
    sViewsWithIds.put(2131296694, 11);
    sViewsWithIds.put(2131296688, 12);
    sViewsWithIds.put(2131296638, 13);
    sViewsWithIds.put(2131296507, 14);
  }
  
  public FragmentTransportControlsBindingImpl(DataBindingComponent paramDataBindingComponent, View paramView) { this(paramDataBindingComponent, paramView, mapBindings(paramDataBindingComponent, paramView, 15, sIncludes, sViewsWithIds)); }
  
  private FragmentTransportControlsBindingImpl(DataBindingComponent paramDataBindingComponent, View paramView, Object[] paramArrayOfObject) {
    super(paramDataBindingComponent, paramView, 7, (TintedImageButton)paramArrayOfObject[2], (TintedImageButton)paramArrayOfObject[1], (TintedImageButton)paramArrayOfObject[10], (TintedImageButton)paramArrayOfObject[8], (ImageView)paramArrayOfObject[4], (ImageView)paramArrayOfObject[6], (ImageView)paramArrayOfObject[14], (SeekBar)paramArrayOfObject[13], (TextView)paramArrayOfObject[7], (TextView)paramArrayOfObject[12], (TextView)paramArrayOfObject[5], (TextView)paramArrayOfObject[3], (TextView)paramArrayOfObject[11], (TextView)paramArrayOfObject[9]);
    this.buttonGoToLive.setTag(null);
    this.buttonPlay.setTag(null);
    this.imageViewChannel.setTag(null);
    this.imageViewIsReplay.setTag(null);
    this.mboundView0 = (ConstraintLayout)paramArrayOfObject[0];
    this.mboundView0.setTag(null);
    this.textViewCurrentTime.setTag(null);
    this.textViewProgramName.setTag(null);
    this.textViewProgramSubtitle.setTag(null);
    setRootTag(paramView);
    this.mCallback2 = new OnClickListener(this, 2);
    this.mCallback1 = new OnClickListener(this, 1);
    invalidateAll();
  }
  
  private boolean onChangeVmChannelName(LiveData<String> paramLiveData, int paramInt) { // Byte code:
    //   0: iload_2
    //   1: ifne -> 27
    //   4: aload_0
    //   5: monitorenter
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mDirtyFlags : J
    //   11: ldc2_w 32
    //   14: lor
    //   15: putfield mDirtyFlags : J
    //   18: aload_0
    //   19: monitorexit
    //   20: iconst_1
    //   21: ireturn
    //   22: astore_1
    //   23: aload_0
    //   24: monitorexit
    //   25: aload_1
    //   26: athrow
    //   27: iconst_0
    //   28: ireturn
    // Exception table:
    //   from	to	target	type
    //   6	20	22	finally
    //   23	25	22	finally }
  
  private boolean onChangeVmCurrentSeekTime(LiveData<String> paramLiveData, int paramInt) { // Byte code:
    //   0: iload_2
    //   1: ifne -> 25
    //   4: aload_0
    //   5: monitorenter
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mDirtyFlags : J
    //   11: lconst_1
    //   12: lor
    //   13: putfield mDirtyFlags : J
    //   16: aload_0
    //   17: monitorexit
    //   18: iconst_1
    //   19: ireturn
    //   20: astore_1
    //   21: aload_0
    //   22: monitorexit
    //   23: aload_1
    //   24: athrow
    //   25: iconst_0
    //   26: ireturn
    // Exception table:
    //   from	to	target	type
    //   6	18	20	finally
    //   21	23	20	finally }
  
  private boolean onChangeVmIsLivePlayback(LiveData<Boolean> paramLiveData, int paramInt) { // Byte code:
    //   0: iload_2
    //   1: ifne -> 27
    //   4: aload_0
    //   5: monitorenter
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mDirtyFlags : J
    //   11: ldc2_w 64
    //   14: lor
    //   15: putfield mDirtyFlags : J
    //   18: aload_0
    //   19: monitorexit
    //   20: iconst_1
    //   21: ireturn
    //   22: astore_1
    //   23: aload_0
    //   24: monitorexit
    //   25: aload_1
    //   26: athrow
    //   27: iconst_0
    //   28: ireturn
    // Exception table:
    //   from	to	target	type
    //   6	20	22	finally
    //   23	25	22	finally }
  
  private boolean onChangeVmIsPaused(LiveData<Boolean> paramLiveData, int paramInt) { // Byte code:
    //   0: iload_2
    //   1: ifne -> 27
    //   4: aload_0
    //   5: monitorenter
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mDirtyFlags : J
    //   11: ldc2_w 8
    //   14: lor
    //   15: putfield mDirtyFlags : J
    //   18: aload_0
    //   19: monitorexit
    //   20: iconst_1
    //   21: ireturn
    //   22: astore_1
    //   23: aload_0
    //   24: monitorexit
    //   25: aload_1
    //   26: athrow
    //   27: iconst_0
    //   28: ireturn
    // Exception table:
    //   from	to	target	type
    //   6	20	22	finally
    //   23	25	22	finally }
  
  private boolean onChangeVmProgramName(LiveData<String> paramLiveData, int paramInt) { // Byte code:
    //   0: iload_2
    //   1: ifne -> 27
    //   4: aload_0
    //   5: monitorenter
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mDirtyFlags : J
    //   11: ldc2_w 2
    //   14: lor
    //   15: putfield mDirtyFlags : J
    //   18: aload_0
    //   19: monitorexit
    //   20: iconst_1
    //   21: ireturn
    //   22: astore_1
    //   23: aload_0
    //   24: monitorexit
    //   25: aload_1
    //   26: athrow
    //   27: iconst_0
    //   28: ireturn
    // Exception table:
    //   from	to	target	type
    //   6	20	22	finally
    //   23	25	22	finally }
  
  private boolean onChangeVmProgramStartEndTime(LiveData<String> paramLiveData, int paramInt) { // Byte code:
    //   0: iload_2
    //   1: ifne -> 27
    //   4: aload_0
    //   5: monitorenter
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mDirtyFlags : J
    //   11: ldc2_w 4
    //   14: lor
    //   15: putfield mDirtyFlags : J
    //   18: aload_0
    //   19: monitorexit
    //   20: iconst_1
    //   21: ireturn
    //   22: astore_1
    //   23: aload_0
    //   24: monitorexit
    //   25: aload_1
    //   26: athrow
    //   27: iconst_0
    //   28: ireturn
    // Exception table:
    //   from	to	target	type
    //   6	20	22	finally
    //   23	25	22	finally }
  
  private boolean onChangeVmSeekAvailable(LiveData<Boolean> paramLiveData, int paramInt) { // Byte code:
    //   0: iload_2
    //   1: ifne -> 27
    //   4: aload_0
    //   5: monitorenter
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mDirtyFlags : J
    //   11: ldc2_w 16
    //   14: lor
    //   15: putfield mDirtyFlags : J
    //   18: aload_0
    //   19: monitorexit
    //   20: iconst_1
    //   21: ireturn
    //   22: astore_1
    //   23: aload_0
    //   24: monitorexit
    //   25: aload_1
    //   26: athrow
    //   27: iconst_0
    //   28: ireturn
    // Exception table:
    //   from	to	target	type
    //   6	20	22	finally
    //   23	25	22	finally }
  
  public final void _internalCallbackOnClick(int paramInt, View paramView) {
    int j = 0;
    int i = 0;
    if (paramInt != 1) {
      if (paramInt != 2)
        return; 
      TVPlayerControlsViewModel tVPlayerControlsViewModel = this.mVm;
      paramInt = i;
      if (tVPlayerControlsViewModel != null)
        paramInt = 1; 
      if (paramInt != 0) {
        tVPlayerControlsViewModel.requestLivePlayback(paramView);
        return;
      } 
    } else {
      TVPlayerControlsViewModel tVPlayerControlsViewModel = this.mVm;
      paramInt = j;
      if (tVPlayerControlsViewModel != null)
        paramInt = 1; 
      if (paramInt != 0)
        tVPlayerControlsViewModel.onTogglePause(); 
    } 
  }
  
  protected void executeBindings() { // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mDirtyFlags : J
    //   6: lstore_2
    //   7: aload_0
    //   8: lconst_0
    //   9: putfield mDirtyFlags : J
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_0
    //   15: getfield mVm : Lch/andeo/init7/tvapp/viewmodels/TVPlayerControlsViewModel;
    //   18: astore #14
    //   20: ldc2_w 511
    //   23: lload_2
    //   24: land
    //   25: lconst_0
    //   26: lcmp
    //   27: ifeq -> 596
    //   30: lload_2
    //   31: ldc2_w 385
    //   34: land
    //   35: lconst_0
    //   36: lcmp
    //   37: ifeq -> 84
    //   40: aload #14
    //   42: ifnull -> 55
    //   45: aload #14
    //   47: invokevirtual getCurrentSeekTime : ()Landroidx/lifecycle/LiveData;
    //   50: astore #9
    //   52: goto -> 58
    //   55: aconst_null
    //   56: astore #9
    //   58: aload_0
    //   59: iconst_0
    //   60: aload #9
    //   62: invokevirtual updateLiveDataRegistration : (ILandroidx/lifecycle/LiveData;)Z
    //   65: pop
    //   66: aload #9
    //   68: ifnull -> 84
    //   71: aload #9
    //   73: invokevirtual getValue : ()Ljava/lang/Object;
    //   76: checkcast java/lang/String
    //   79: astore #9
    //   81: goto -> 87
    //   84: aconst_null
    //   85: astore #9
    //   87: lload_2
    //   88: ldc2_w 386
    //   91: land
    //   92: lconst_0
    //   93: lcmp
    //   94: ifeq -> 141
    //   97: aload #14
    //   99: ifnull -> 112
    //   102: aload #14
    //   104: invokevirtual getProgramName : ()Landroidx/lifecycle/LiveData;
    //   107: astore #10
    //   109: goto -> 115
    //   112: aconst_null
    //   113: astore #10
    //   115: aload_0
    //   116: iconst_1
    //   117: aload #10
    //   119: invokevirtual updateLiveDataRegistration : (ILandroidx/lifecycle/LiveData;)Z
    //   122: pop
    //   123: aload #10
    //   125: ifnull -> 141
    //   128: aload #10
    //   130: invokevirtual getValue : ()Ljava/lang/Object;
    //   133: checkcast java/lang/String
    //   136: astore #10
    //   138: goto -> 144
    //   141: aconst_null
    //   142: astore #10
    //   144: lload_2
    //   145: ldc2_w 388
    //   148: land
    //   149: lconst_0
    //   150: lcmp
    //   151: ifeq -> 198
    //   154: aload #14
    //   156: ifnull -> 169
    //   159: aload #14
    //   161: invokevirtual getProgramStartEndTime : ()Landroidx/lifecycle/LiveData;
    //   164: astore #11
    //   166: goto -> 172
    //   169: aconst_null
    //   170: astore #11
    //   172: aload_0
    //   173: iconst_2
    //   174: aload #11
    //   176: invokevirtual updateLiveDataRegistration : (ILandroidx/lifecycle/LiveData;)Z
    //   179: pop
    //   180: aload #11
    //   182: ifnull -> 198
    //   185: aload #11
    //   187: invokevirtual getValue : ()Ljava/lang/Object;
    //   190: checkcast java/lang/String
    //   193: astore #11
    //   195: goto -> 201
    //   198: aconst_null
    //   199: astore #11
    //   201: lload_2
    //   202: ldc2_w 392
    //   205: land
    //   206: lconst_0
    //   207: lcmp
    //   208: istore_1
    //   209: iload_1
    //   210: ifeq -> 332
    //   213: aload #14
    //   215: ifnull -> 228
    //   218: aload #14
    //   220: invokevirtual getIsPaused : ()Landroidx/lifecycle/LiveData;
    //   223: astore #12
    //   225: goto -> 231
    //   228: aconst_null
    //   229: astore #12
    //   231: aload_0
    //   232: iconst_3
    //   233: aload #12
    //   235: invokevirtual updateLiveDataRegistration : (ILandroidx/lifecycle/LiveData;)Z
    //   238: pop
    //   239: aload #12
    //   241: ifnull -> 257
    //   244: aload #12
    //   246: invokevirtual getValue : ()Ljava/lang/Object;
    //   249: checkcast java/lang/Boolean
    //   252: astore #12
    //   254: goto -> 260
    //   257: aconst_null
    //   258: astore #12
    //   260: aload #12
    //   262: invokestatic safeUnbox : (Ljava/lang/Boolean;)Z
    //   265: istore #6
    //   267: lload_2
    //   268: lstore #4
    //   270: iload_1
    //   271: ifeq -> 298
    //   274: iload #6
    //   276: ifeq -> 287
    //   279: ldc2_w 4096
    //   282: lstore #4
    //   284: goto -> 292
    //   287: ldc2_w 2048
    //   290: lstore #4
    //   292: lload_2
    //   293: lload #4
    //   295: lor
    //   296: lstore #4
    //   298: aload_0
    //   299: getfield buttonPlay : Lch/andeo/init7/tvapp/ui/TintedImageButton;
    //   302: astore #12
    //   304: iload #6
    //   306: ifeq -> 315
    //   309: ldc 2131165319
    //   311: istore_1
    //   312: goto -> 318
    //   315: ldc 2131165318
    //   317: istore_1
    //   318: aload #12
    //   320: iload_1
    //   321: invokestatic getDrawableFromResource : (Landroid/view/View;I)Landroid/graphics/drawable/Drawable;
    //   324: astore #12
    //   326: lload #4
    //   328: lstore_2
    //   329: goto -> 335
    //   332: aconst_null
    //   333: astore #12
    //   335: lload_2
    //   336: ldc2_w 400
    //   339: land
    //   340: lconst_0
    //   341: lcmp
    //   342: ifeq -> 402
    //   345: aload #14
    //   347: ifnull -> 360
    //   350: aload #14
    //   352: invokevirtual getSeekAvailable : ()Landroidx/lifecycle/LiveData;
    //   355: astore #13
    //   357: goto -> 363
    //   360: aconst_null
    //   361: astore #13
    //   363: aload_0
    //   364: iconst_4
    //   365: aload #13
    //   367: invokevirtual updateLiveDataRegistration : (ILandroidx/lifecycle/LiveData;)Z
    //   370: pop
    //   371: aload #13
    //   373: ifnull -> 389
    //   376: aload #13
    //   378: invokevirtual getValue : ()Ljava/lang/Object;
    //   381: checkcast java/lang/Boolean
    //   384: astore #13
    //   386: goto -> 392
    //   389: aconst_null
    //   390: astore #13
    //   392: aload #13
    //   394: invokestatic safeUnbox : (Ljava/lang/Boolean;)Z
    //   397: istore #6
    //   399: goto -> 405
    //   402: iconst_0
    //   403: istore #6
    //   405: lload_2
    //   406: ldc2_w 416
    //   409: land
    //   410: lconst_0
    //   411: lcmp
    //   412: ifeq -> 459
    //   415: aload #14
    //   417: ifnull -> 430
    //   420: aload #14
    //   422: invokevirtual getChannelName : ()Landroidx/lifecycle/LiveData;
    //   425: astore #13
    //   427: goto -> 433
    //   430: aconst_null
    //   431: astore #13
    //   433: aload_0
    //   434: iconst_5
    //   435: aload #13
    //   437: invokevirtual updateLiveDataRegistration : (ILandroidx/lifecycle/LiveData;)Z
    //   440: pop
    //   441: aload #13
    //   443: ifnull -> 459
    //   446: aload #13
    //   448: invokevirtual getValue : ()Ljava/lang/Object;
    //   451: checkcast java/lang/String
    //   454: astore #13
    //   456: goto -> 462
    //   459: aconst_null
    //   460: astore #13
    //   462: lload_2
    //   463: ldc2_w 448
    //   466: land
    //   467: lconst_0
    //   468: lcmp
    //   469: istore_1
    //   470: iload_1
    //   471: ifeq -> 588
    //   474: aload #14
    //   476: ifnull -> 489
    //   479: aload #14
    //   481: invokevirtual getIsLivePlayback : ()Landroidx/lifecycle/LiveData;
    //   484: astore #14
    //   486: goto -> 492
    //   489: aconst_null
    //   490: astore #14
    //   492: aload_0
    //   493: bipush #6
    //   495: aload #14
    //   497: invokevirtual updateLiveDataRegistration : (ILandroidx/lifecycle/LiveData;)Z
    //   500: pop
    //   501: aload #14
    //   503: ifnull -> 519
    //   506: aload #14
    //   508: invokevirtual getValue : ()Ljava/lang/Object;
    //   511: checkcast java/lang/Boolean
    //   514: astore #14
    //   516: goto -> 522
    //   519: aconst_null
    //   520: astore #14
    //   522: aload #14
    //   524: invokestatic safeUnbox : (Ljava/lang/Boolean;)Z
    //   527: istore #8
    //   529: lload_2
    //   530: lstore #4
    //   532: iload_1
    //   533: ifeq -> 560
    //   536: iload #8
    //   538: ifeq -> 549
    //   541: ldc2_w 1024
    //   544: lstore #4
    //   546: goto -> 554
    //   549: ldc2_w 512
    //   552: lstore #4
    //   554: lload_2
    //   555: lload #4
    //   557: lor
    //   558: lstore #4
    //   560: iload #8
    //   562: iconst_1
    //   563: ixor
    //   564: istore #7
    //   566: iload #8
    //   568: ifeq -> 580
    //   571: bipush #8
    //   573: istore_1
    //   574: lload #4
    //   576: lstore_2
    //   577: goto -> 619
    //   580: iconst_0
    //   581: istore_1
    //   582: lload #4
    //   584: lstore_2
    //   585: goto -> 619
    //   588: iconst_0
    //   589: istore_1
    //   590: iconst_0
    //   591: istore #7
    //   593: goto -> 619
    //   596: iconst_0
    //   597: istore_1
    //   598: aconst_null
    //   599: astore #9
    //   601: aconst_null
    //   602: astore #10
    //   604: aconst_null
    //   605: astore #13
    //   607: aconst_null
    //   608: astore #12
    //   610: aconst_null
    //   611: astore #11
    //   613: iconst_0
    //   614: istore #7
    //   616: iconst_0
    //   617: istore #6
    //   619: lload_2
    //   620: ldc2_w 448
    //   623: land
    //   624: lconst_0
    //   625: lcmp
    //   626: ifeq -> 646
    //   629: aload_0
    //   630: getfield buttonGoToLive : Lch/andeo/init7/tvapp/ui/TintedImageButton;
    //   633: iload #7
    //   635: invokevirtual setEnabled : (Z)V
    //   638: aload_0
    //   639: getfield imageViewIsReplay : Landroid/widget/ImageView;
    //   642: iload_1
    //   643: invokevirtual setVisibility : (I)V
    //   646: ldc2_w 256
    //   649: lload_2
    //   650: land
    //   651: lconst_0
    //   652: lcmp
    //   653: ifeq -> 678
    //   656: aload_0
    //   657: getfield buttonGoToLive : Lch/andeo/init7/tvapp/ui/TintedImageButton;
    //   660: aload_0
    //   661: getfield mCallback2 : Landroid/view/View$OnClickListener;
    //   664: invokevirtual setOnClickListener : (Landroid/view/View$OnClickListener;)V
    //   667: aload_0
    //   668: getfield buttonPlay : Lch/andeo/init7/tvapp/ui/TintedImageButton;
    //   671: aload_0
    //   672: getfield mCallback1 : Landroid/view/View$OnClickListener;
    //   675: invokevirtual setOnClickListener : (Landroid/view/View$OnClickListener;)V
    //   678: lload_2
    //   679: ldc2_w 400
    //   682: land
    //   683: lconst_0
    //   684: lcmp
    //   685: ifeq -> 706
    //   688: aload_0
    //   689: getfield buttonPlay : Lch/andeo/init7/tvapp/ui/TintedImageButton;
    //   692: iload #6
    //   694: invokevirtual setEnabled : (Z)V
    //   697: aload_0
    //   698: getfield buttonPlay : Lch/andeo/init7/tvapp/ui/TintedImageButton;
    //   701: iload #6
    //   703: invokevirtual setFocusable : (Z)V
    //   706: ldc2_w 392
    //   709: lload_2
    //   710: land
    //   711: lconst_0
    //   712: lcmp
    //   713: ifeq -> 725
    //   716: aload_0
    //   717: getfield buttonPlay : Lch/andeo/init7/tvapp/ui/TintedImageButton;
    //   720: aload #12
    //   722: invokestatic setImageDrawable : (Landroid/widget/ImageView;Landroid/graphics/drawable/Drawable;)V
    //   725: ldc2_w 416
    //   728: lload_2
    //   729: land
    //   730: lconst_0
    //   731: lcmp
    //   732: ifeq -> 751
    //   735: invokestatic getBuildSdkInt : ()I
    //   738: iconst_4
    //   739: if_icmplt -> 751
    //   742: aload_0
    //   743: getfield imageViewChannel : Landroid/widget/ImageView;
    //   746: aload #13
    //   748: invokevirtual setContentDescription : (Ljava/lang/CharSequence;)V
    //   751: lload_2
    //   752: ldc2_w 385
    //   755: land
    //   756: lconst_0
    //   757: lcmp
    //   758: ifeq -> 770
    //   761: aload_0
    //   762: getfield textViewCurrentTime : Landroid/widget/TextView;
    //   765: aload #9
    //   767: invokestatic setText : (Landroid/widget/TextView;Ljava/lang/CharSequence;)V
    //   770: lload_2
    //   771: ldc2_w 386
    //   774: land
    //   775: lconst_0
    //   776: lcmp
    //   777: ifeq -> 789
    //   780: aload_0
    //   781: getfield textViewProgramName : Landroid/widget/TextView;
    //   784: aload #10
    //   786: invokestatic setText : (Landroid/widget/TextView;Ljava/lang/CharSequence;)V
    //   789: lload_2
    //   790: ldc2_w 388
    //   793: land
    //   794: lconst_0
    //   795: lcmp
    //   796: ifeq -> 808
    //   799: aload_0
    //   800: getfield textViewProgramSubtitle : Landroid/widget/TextView;
    //   803: aload #11
    //   805: invokestatic setText : (Landroid/widget/TextView;Ljava/lang/CharSequence;)V
    //   808: return
    //   809: astore #9
    //   811: aload_0
    //   812: monitorexit
    //   813: aload #9
    //   815: athrow
    // Exception table:
    //   from	to	target	type
    //   2	14	809	finally
    //   811	813	809	finally }
  
  public boolean hasPendingBindings() { // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mDirtyFlags : J
    //   6: lconst_0
    //   7: lcmp
    //   8: ifeq -> 15
    //   11: aload_0
    //   12: monitorexit
    //   13: iconst_1
    //   14: ireturn
    //   15: aload_0
    //   16: monitorexit
    //   17: iconst_0
    //   18: ireturn
    //   19: astore_1
    //   20: aload_0
    //   21: monitorexit
    //   22: aload_1
    //   23: athrow
    // Exception table:
    //   from	to	target	type
    //   2	13	19	finally
    //   15	17	19	finally
    //   20	22	19	finally }
  
  public void invalidateAll() { // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: ldc2_w 256
    //   6: putfield mDirtyFlags : J
    //   9: aload_0
    //   10: monitorexit
    //   11: aload_0
    //   12: invokevirtual requestRebind : ()V
    //   15: return
    //   16: astore_1
    //   17: aload_0
    //   18: monitorexit
    //   19: aload_1
    //   20: athrow
    // Exception table:
    //   from	to	target	type
    //   2	11	16	finally
    //   17	19	16	finally }
  
  protected boolean onFieldChange(int paramInt1, Object paramObject, int paramInt2) {
    switch (paramInt1) {
      default:
        return false;
      case 6:
        return onChangeVmIsLivePlayback((LiveData)paramObject, paramInt2);
      case 5:
        return onChangeVmChannelName((LiveData)paramObject, paramInt2);
      case 4:
        return onChangeVmSeekAvailable((LiveData)paramObject, paramInt2);
      case 3:
        return onChangeVmIsPaused((LiveData)paramObject, paramInt2);
      case 2:
        return onChangeVmProgramStartEndTime((LiveData)paramObject, paramInt2);
      case 1:
        return onChangeVmProgramName((LiveData)paramObject, paramInt2);
      case 0:
        break;
    } 
    return onChangeVmCurrentSeekTime((LiveData)paramObject, paramInt2);
  }
  
  public boolean setVariable(int paramInt, Object paramObject) {
    if (2 == paramInt) {
      setVm((TVPlayerControlsViewModel)paramObject);
      return true;
    } 
    return false;
  }
  
  public void setVm(TVPlayerControlsViewModel paramTVPlayerControlsViewModel) { // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: putfield mVm : Lch/andeo/init7/tvapp/viewmodels/TVPlayerControlsViewModel;
    //   5: aload_0
    //   6: monitorenter
    //   7: aload_0
    //   8: aload_0
    //   9: getfield mDirtyFlags : J
    //   12: ldc2_w 128
    //   15: lor
    //   16: putfield mDirtyFlags : J
    //   19: aload_0
    //   20: monitorexit
    //   21: aload_0
    //   22: iconst_2
    //   23: invokevirtual notifyPropertyChanged : (I)V
    //   26: aload_0
    //   27: invokespecial requestRebind : ()V
    //   30: return
    //   31: astore_1
    //   32: aload_0
    //   33: monitorexit
    //   34: aload_1
    //   35: athrow
    // Exception table:
    //   from	to	target	type
    //   7	21	31	finally
    //   32	34	31	finally }
}
