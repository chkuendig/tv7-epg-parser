package ch.andeo.init7.tvapp.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.databinding.Bindable;
import androidx.databinding.DataBindingUtil;
import androidx.databinding.ViewDataBinding;
import ch.andeo.init7.core.model.EPGInfo;
import ch.andeo.init7.tvapp.ui.MultiStateConstraintLayout;

public abstract class LayoutProgramListitemBinding extends ViewDataBinding {
  public final MultiStateConstraintLayout constraintLayoutWrapper;
  
  public final ImageView imageViewEpgReplayIcon;
  
  @Bindable
  protected EPGInfo mEpg;
  
  @Bindable
  protected Boolean mHasReplay;
  
  @Bindable
  protected String mShowTime;
  
  public final TextView textViewShowTime;
  
  public final TextView textViewShowTitle;
  
  protected LayoutProgramListitemBinding(Object paramObject, View paramView, int paramInt, MultiStateConstraintLayout paramMultiStateConstraintLayout, ImageView paramImageView, TextView paramTextView1, TextView paramTextView2) {
    super(paramObject, paramView, paramInt);
    this.constraintLayoutWrapper = paramMultiStateConstraintLayout;
    this.imageViewEpgReplayIcon = paramImageView;
    this.textViewShowTime = paramTextView1;
    this.textViewShowTitle = paramTextView2;
  }
  
  public static LayoutProgramListitemBinding bind(View paramView) { return bind(paramView, DataBindingUtil.getDefaultComponent()); }
  
  @Deprecated
  public static LayoutProgramListitemBinding bind(View paramView, Object paramObject) { return (LayoutProgramListitemBinding)bind(paramObject, paramView, 2131492910); }
  
  public static LayoutProgramListitemBinding inflate(LayoutInflater paramLayoutInflater) { return inflate(paramLayoutInflater, DataBindingUtil.getDefaultComponent()); }
  
  public static LayoutProgramListitemBinding inflate(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, boolean paramBoolean) { return inflate(paramLayoutInflater, paramViewGroup, paramBoolean, DataBindingUtil.getDefaultComponent()); }
  
  @Deprecated
  public static LayoutProgramListitemBinding inflate(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, boolean paramBoolean, Object paramObject) { return (LayoutProgramListitemBinding)ViewDataBinding.inflateInternal(paramLayoutInflater, 2131492910, paramViewGroup, paramBoolean, paramObject); }
  
  @Deprecated
  public static LayoutProgramListitemBinding inflate(LayoutInflater paramLayoutInflater, Object paramObject) { return (LayoutProgramListitemBinding)ViewDataBinding.inflateInternal(paramLayoutInflater, 2131492910, null, false, paramObject); }
  
  public EPGInfo getEpg() { return this.mEpg; }
  
  public Boolean getHasReplay() { return this.mHasReplay; }
  
  public String getShowTime() { return this.mShowTime; }
  
  public abstract void setEpg(EPGInfo paramEPGInfo);
  
  public abstract void setHasReplay(Boolean paramBoolean);
  
  public abstract void setShowTime(String paramString);
}
