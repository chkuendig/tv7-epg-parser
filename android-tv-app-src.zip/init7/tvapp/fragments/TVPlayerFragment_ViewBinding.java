package ch.andeo.init7.tvapp.fragments;

import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import butterknife.Unbinder;
import butterknife.internal.Utils;
import com.google.android.exoplayer2.ui.PlayerView;
import com.google.android.exoplayer2.ui.SubtitleView;

public class TVPlayerFragment_ViewBinding implements Unbinder {
  private TVPlayerFragment target;
  
  public TVPlayerFragment_ViewBinding(TVPlayerFragment paramTVPlayerFragment, View paramView) {
    this.target = paramTVPlayerFragment;
    paramTVPlayerFragment.exoPlayerView = (PlayerView)Utils.findRequiredViewAsType(paramView, 2131296442, "field 'exoPlayerView'", PlayerView.class);
    paramTVPlayerFragment.textView_debug = (TextView)Utils.findRequiredViewAsType(paramView, 2131296687, "field 'textView_debug'", TextView.class);
    paramTVPlayerFragment.subtitleView = (SubtitleView)Utils.findRequiredViewAsType(paramView, 2131296665, "field 'subtitleView'", SubtitleView.class);
    paramTVPlayerFragment.progressBar_buffer = (ProgressBar)Utils.findRequiredViewAsType(paramView, 2131296608, "field 'progressBar_buffer'", ProgressBar.class);
  }
  
  public void unbind() {
    TVPlayerFragment tVPlayerFragment = this.target;
    if (tVPlayerFragment != null) {
      this.target = null;
      tVPlayerFragment.exoPlayerView = null;
      tVPlayerFragment.textView_debug = null;
      tVPlayerFragment.subtitleView = null;
      tVPlayerFragment.progressBar_buffer = null;
      return;
    } 
    throw new IllegalStateException("Bindings already cleared.");
  }
}
