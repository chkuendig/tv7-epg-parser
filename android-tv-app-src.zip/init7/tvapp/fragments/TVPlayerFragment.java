package ch.andeo.init7.tvapp.fragments;

import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import ch.andeo.init7.tvapp.App;
import ch.andeo.init7.tvapp.TVPlayerActivity;
import ch.andeo.init7.tvapp.exoplayerutil.DebugUtil;
import ch.andeo.init7.tvapp.exoplayerutil.ExtendedDebugTextViewHelper;
import ch.andeo.init7.tvapp.exoplayerutil.FormatInfo;
import ch.andeo.init7.tvapp.viewmodels.MediaState;
import ch.andeo.init7.tvapp.viewmodels.TrackSelectionViewModel;
import com.google.android.exoplayer2.ExoPlaybackException;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.PlaybackParameters;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.Timeline;
import com.google.android.exoplayer2.source.ConcatenatingMediaSource;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.source.TrackGroup;
import com.google.android.exoplayer2.source.TrackGroupArray;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.trackselection.MappingTrackSelector;
import com.google.android.exoplayer2.trackselection.TrackSelectionArray;
import com.google.android.exoplayer2.ui.PlayerView;
import com.google.android.exoplayer2.ui.SubtitleView;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;

public class TVPlayerFragment extends TVPlayerActivity.TVPlayerActivityFragment implements Player.EventListener, TVPlayerActivity.FragmentKeyListener, MediaState.MediaStateEventListener {
  private static final String TAG = "TVPlayerFragment";
  
  private MappingTrackSelector.MappedTrackInfo currentMappedTrackInfo = null;
  
  private ExtendedDebugTextViewHelper debugTextViewHelper;
  
  @BindView(2131296442)
  PlayerView exoPlayerView;
  
  private MediaState mediaState;
  
  private SimpleExoPlayer player;
  
  private ExecutorService playerProgressExecutor;
  
  private ConcatenatingMediaSource playlist;
  
  @BindView(2131296608)
  ProgressBar progressBar_buffer;
  
  @BindView(2131296665)
  SubtitleView subtitleView;
  
  @BindView(2131296687)
  TextView textView_debug;
  
  private TrackSelectionViewModel trackSelectionViewModel;
  
  private DefaultTrackSelector trackSelector;
  
  private void deinitPlayer() {
    this.playerProgressExecutor.shutdownNow();
    this.player.release();
    this.player = null;
  }
  
  private List<FormatInfo> getAudioTracks() { return getTracksForType(1); }
  
  private int getCurrentMediaIndex() {
    Object object = this.player.getCurrentTag();
    for (byte b = 0; b < this.playlist.getSize(); b++) {
      if (object == this.playlist.getMediaSource(b).getTag())
        return b; 
    } 
    return -1;
  }
  
  private static int getRendererIndexForType(MappingTrackSelector.MappedTrackInfo paramMappedTrackInfo, int paramInt) {
    for (byte b = 0; b < paramMappedTrackInfo.getRendererCount(); b++) {
      if (paramMappedTrackInfo.getRendererType(b) == paramInt)
        return b; 
    } 
    return -1;
  }
  
  private List<FormatInfo> getTextTracks() { return getTracksForType(3); }
  
  private List<FormatInfo> getTracksForType(int paramInt) {
    MappingTrackSelector.MappedTrackInfo mappedTrackInfo = this.currentMappedTrackInfo;
    if (mappedTrackInfo == null)
      return Collections.emptyList(); 
    int i = getRendererIndexForType(mappedTrackInfo, paramInt);
    if (i == -1)
      return Collections.emptyList(); 
    TrackGroupArray trackGroupArray = this.currentMappedTrackInfo.getTrackGroups(i);
    ArrayList arrayList = new ArrayList();
    for (paramInt = 0; paramInt < trackGroupArray.length; paramInt++) {
      TrackGroup trackGroup = trackGroupArray.get(paramInt);
      for (byte b = 0; b < trackGroup.length; b++) {
        Format format = trackGroup.getFormat(b);
        if (this.currentMappedTrackInfo.getTrackSupport(i, paramInt, b) == 4)
          arrayList.add(new FormatInfo(paramInt, b, format, i, trackGroupArray)); 
      } 
    } 
    return arrayList;
  }
  
  private void initPlayer() { // Byte code:
    //   0: aload_0
    //   1: new com/google/android/exoplayer2/trackselection/DefaultTrackSelector
    //   4: dup
    //   5: invokespecial <init> : ()V
    //   8: putfield trackSelector : Lcom/google/android/exoplayer2/trackselection/DefaultTrackSelector;
    //   11: aload_0
    //   12: getfield trackSelector : Lcom/google/android/exoplayer2/trackselection/DefaultTrackSelector;
    //   15: astore_1
    //   16: aload_1
    //   17: aload_1
    //   18: invokevirtual getParameters : ()Lcom/google/android/exoplayer2/trackselection/DefaultTrackSelector$Parameters;
    //   21: invokevirtual buildUpon : ()Lcom/google/android/exoplayer2/trackselection/DefaultTrackSelector$ParametersBuilder;
    //   24: invokevirtual build : ()Lcom/google/android/exoplayer2/trackselection/DefaultTrackSelector$Parameters;
    //   27: invokevirtual setParameters : (Lcom/google/android/exoplayer2/trackselection/DefaultTrackSelector$Parameters;)V
    //   30: new com/google/android/exoplayer2/DefaultRenderersFactory
    //   33: dup
    //   34: aload_0
    //   35: invokevirtual getOwner : ()Landroidx/fragment/app/FragmentActivity;
    //   38: invokespecial <init> : (Landroid/content/Context;)V
    //   41: astore_1
    //   42: aload_1
    //   43: iconst_2
    //   44: invokevirtual setExtensionRendererMode : (I)Lcom/google/android/exoplayer2/DefaultRenderersFactory;
    //   47: pop
    //   48: aload_0
    //   49: aload_0
    //   50: invokevirtual getOwner : ()Landroidx/fragment/app/FragmentActivity;
    //   53: aload_1
    //   54: aload_0
    //   55: getfield trackSelector : Lcom/google/android/exoplayer2/trackselection/DefaultTrackSelector;
    //   58: invokestatic newSimpleInstance : (Landroid/content/Context;Lcom/google/android/exoplayer2/RenderersFactory;Lcom/google/android/exoplayer2/trackselection/TrackSelector;)Lcom/google/android/exoplayer2/SimpleExoPlayer;
    //   61: putfield player : Lcom/google/android/exoplayer2/SimpleExoPlayer;
    //   64: aload_0
    //   65: getfield player : Lcom/google/android/exoplayer2/SimpleExoPlayer;
    //   68: aload_0
    //   69: invokevirtual addListener : (Lcom/google/android/exoplayer2/Player$EventListener;)V
    //   72: aload_0
    //   73: getfield player : Lcom/google/android/exoplayer2/SimpleExoPlayer;
    //   76: new com/google/android/exoplayer2/util/EventLogger
    //   79: dup
    //   80: aload_0
    //   81: getfield trackSelector : Lcom/google/android/exoplayer2/trackselection/DefaultTrackSelector;
    //   84: invokespecial <init> : (Lcom/google/android/exoplayer2/trackselection/MappingTrackSelector;)V
    //   87: invokevirtual addAnalyticsListener : (Lcom/google/android/exoplayer2/analytics/AnalyticsListener;)V
    //   90: aload_0
    //   91: getfield exoPlayerView : Lcom/google/android/exoplayer2/ui/PlayerView;
    //   94: aload_0
    //   95: getfield player : Lcom/google/android/exoplayer2/SimpleExoPlayer;
    //   98: invokevirtual setPlayer : (Lcom/google/android/exoplayer2/Player;)V
    //   101: aload_0
    //   102: new ch/andeo/init7/tvapp/exoplayerutil/ExtendedDebugTextViewHelper
    //   105: dup
    //   106: aload_0
    //   107: getfield player : Lcom/google/android/exoplayer2/SimpleExoPlayer;
    //   110: aload_0
    //   111: getfield textView_debug : Landroid/widget/TextView;
    //   114: invokespecial <init> : (Lcom/google/android/exoplayer2/SimpleExoPlayer;Landroid/widget/TextView;)V
    //   117: putfield debugTextViewHelper : Lch/andeo/init7/tvapp/exoplayerutil/ExtendedDebugTextViewHelper;
    //   120: aload_0
    //   121: getfield player : Lcom/google/android/exoplayer2/SimpleExoPlayer;
    //   124: new ch/andeo/init7/tvapp/fragments/-$$Lambda$TVPlayerFragment$nVGrZnGMIqQAThMu23polnhXCPE
    //   127: dup
    //   128: aload_0
    //   129: invokespecial <init> : (Lch/andeo/init7/tvapp/fragments/TVPlayerFragment;)V
    //   132: invokevirtual addTextOutput : (Lcom/google/android/exoplayer2/text/TextOutput;)V
    //   135: aload_0
    //   136: new ch/andeo/init7/core/util/NamedThreadFactory
    //   139: dup
    //   140: ldc 'Player-Progress'
    //   142: invokespecial <init> : (Ljava/lang/String;)V
    //   145: invokestatic newSingleThreadExecutor : (Ljava/util/concurrent/ThreadFactory;)Ljava/util/concurrent/ExecutorService;
    //   148: putfield playerProgressExecutor : Ljava/util/concurrent/ExecutorService;
    //   151: aload_0
    //   152: getfield playerProgressExecutor : Ljava/util/concurrent/ExecutorService;
    //   155: new ch/andeo/init7/tvapp/fragments/-$$Lambda$TVPlayerFragment$dmWb7u2C9pUAJO2U_8CxnGf9Gy8
    //   158: dup
    //   159: aload_0
    //   160: invokespecial <init> : (Lch/andeo/init7/tvapp/fragments/TVPlayerFragment;)V
    //   163: invokeinterface submit : (Ljava/lang/Runnable;)Ljava/util/concurrent/Future;
    //   168: pop
    //   169: aload_0
    //   170: new com/google/android/exoplayer2/source/ConcatenatingMediaSource
    //   173: dup
    //   174: iconst_0
    //   175: anewarray com/google/android/exoplayer2/source/MediaSource
    //   178: invokespecial <init> : ([Lcom/google/android/exoplayer2/source/MediaSource;)V
    //   181: putfield playlist : Lcom/google/android/exoplayer2/source/ConcatenatingMediaSource;
    //   184: aload_0
    //   185: getfield player : Lcom/google/android/exoplayer2/SimpleExoPlayer;
    //   188: aload_0
    //   189: getfield playlist : Lcom/google/android/exoplayer2/source/ConcatenatingMediaSource;
    //   192: invokevirtual prepare : (Lcom/google/android/exoplayer2/source/MediaSource;)V
    //   195: aload_0
    //   196: getfield player : Lcom/google/android/exoplayer2/SimpleExoPlayer;
    //   199: iconst_1
    //   200: invokevirtual setPlayWhenReady : (Z)V
    //   203: return }
  
  private void updateCurrentPosition() {
    int i = this.player.getCurrentWindowIndex();
    Long long = Long.valueOf(0L);
    if (i == -1 || this.player.getCurrentTimeline().getWindowCount() == 0) {
      this.mediaState.getCurrentPosition().postValue(long);
      return;
    } 
    Timeline.Window window = new Timeline.Window();
    this.player.getCurrentTimeline().getWindow(i, window);
    if (window.windowStartTimeMs != -9223372036854775807L) {
      long l1 = window.windowStartTimeMs;
      long l2 = this.player.getCurrentPosition();
      this.mediaState.getCurrentPosition().postValue(Long.valueOf(l1 + l2));
      return;
    } 
    this.mediaState.getCurrentPosition().postValue(long);
  }
  
  public void onActivityCreated(Bundle paramBundle) { // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokespecial onActivityCreated : (Landroid/os/Bundle;)V
    //   5: aload_0
    //   6: invokevirtual getActivity : ()Landroidx/fragment/app/FragmentActivity;
    //   9: ifnull -> 144
    //   12: aload_0
    //   13: aload_0
    //   14: invokevirtual getViewModelProvider : ()Landroidx/lifecycle/ViewModelProvider;
    //   17: ldc_w ch/andeo/init7/tvapp/viewmodels/TrackSelectionViewModel
    //   20: invokevirtual get : (Ljava/lang/Class;)Landroidx/lifecycle/ViewModel;
    //   23: checkcast ch/andeo/init7/tvapp/viewmodels/TrackSelectionViewModel
    //   26: putfield trackSelectionViewModel : Lch/andeo/init7/tvapp/viewmodels/TrackSelectionViewModel;
    //   29: new ch/andeo/init7/tvapp/fragments/-$$Lambda$TVPlayerFragment$lQEejDaEbu_Kg5tys7_NSBPS_pM
    //   32: dup
    //   33: aload_0
    //   34: invokespecial <init> : (Lch/andeo/init7/tvapp/fragments/TVPlayerFragment;)V
    //   37: astore_1
    //   38: aload_0
    //   39: getfield trackSelectionViewModel : Lch/andeo/init7/tvapp/viewmodels/TrackSelectionViewModel;
    //   42: invokevirtual getAudioOverride : ()Landroidx/lifecycle/MutableLiveData;
    //   45: aload_0
    //   46: invokevirtual getViewLifecycleOwner : ()Landroidx/lifecycle/LifecycleOwner;
    //   49: aload_1
    //   50: invokevirtual observe : (Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Observer;)V
    //   53: aload_0
    //   54: getfield trackSelectionViewModel : Lch/andeo/init7/tvapp/viewmodels/TrackSelectionViewModel;
    //   57: invokevirtual getTextOverride : ()Landroidx/lifecycle/MutableLiveData;
    //   60: aload_0
    //   61: invokevirtual getViewLifecycleOwner : ()Landroidx/lifecycle/LifecycleOwner;
    //   64: aload_1
    //   65: invokevirtual observe : (Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Observer;)V
    //   68: aload_0
    //   69: invokevirtual getViewModelProvider : ()Landroidx/lifecycle/ViewModelProvider;
    //   72: ldc_w ch/andeo/init7/tvapp/viewmodels/PreferenceViewModel
    //   75: invokevirtual get : (Ljava/lang/Class;)Landroidx/lifecycle/ViewModel;
    //   78: checkcast ch/andeo/init7/tvapp/viewmodels/PreferenceViewModel
    //   81: invokevirtual getDebugInfoEnabled : ()Lch/andeo/init7/tvapp/androidutil/NNMutableLiveData;
    //   84: aload_0
    //   85: invokevirtual getViewLifecycleOwner : ()Landroidx/lifecycle/LifecycleOwner;
    //   88: new ch/andeo/init7/tvapp/fragments/-$$Lambda$TVPlayerFragment$MS5NezDMPx45gbnVIIBuh3YVzl0
    //   91: dup
    //   92: aload_0
    //   93: invokespecial <init> : (Lch/andeo/init7/tvapp/fragments/TVPlayerFragment;)V
    //   96: invokevirtual observe : (Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Observer;)V
    //   99: aload_0
    //   100: getfield mediaState : Lch/andeo/init7/tvapp/viewmodels/MediaState;
    //   103: invokevirtual getSeekRequest : ()Lch/andeo/init7/tvapp/androidutil/NNMutableLiveData;
    //   106: aload_0
    //   107: invokevirtual getViewLifecycleOwner : ()Landroidx/lifecycle/LifecycleOwner;
    //   110: new ch/andeo/init7/tvapp/fragments/-$$Lambda$TVPlayerFragment$iSIfAfJQdcktiEA68vJWAOxCY1A
    //   113: dup
    //   114: aload_0
    //   115: invokespecial <init> : (Lch/andeo/init7/tvapp/fragments/TVPlayerFragment;)V
    //   118: invokevirtual observe : (Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Observer;)V
    //   121: aload_0
    //   122: getfield mediaState : Lch/andeo/init7/tvapp/viewmodels/MediaState;
    //   125: invokevirtual getIsPaused : ()Lch/andeo/init7/tvapp/androidutil/NNMutableLiveData;
    //   128: aload_0
    //   129: invokevirtual getViewLifecycleOwner : ()Landroidx/lifecycle/LifecycleOwner;
    //   132: new ch/andeo/init7/tvapp/fragments/-$$Lambda$TVPlayerFragment$4up4ayKVHakFLwZVSMSYNzRywvQ
    //   135: dup
    //   136: aload_0
    //   137: invokespecial <init> : (Lch/andeo/init7/tvapp/fragments/TVPlayerFragment;)V
    //   140: invokevirtual observe : (Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Observer;)V
    //   143: return
    //   144: new java/lang/RuntimeException
    //   147: dup
    //   148: ldc_w 'Activity is null'
    //   151: invokespecial <init> : (Ljava/lang/String;)V
    //   154: athrow }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    this.mediaState = App.getInstance().getMediaState();
  }
  
  public View onCreateView(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle) {
    View view = paramLayoutInflater.inflate(2131492903, paramViewGroup, false);
    ButterKnife.bind(this, view);
    return view;
  }
  
  public void onMediaSourceAdded() { // Byte code:
    //   0: aload_0
    //   1: invokevirtual getActivity : ()Landroidx/fragment/app/FragmentActivity;
    //   4: new ch/andeo/init7/tvapp/fragments/-$$Lambda$TVPlayerFragment$TMKvWPp3CqoHZokZaVw9xaaxwXc
    //   7: dup
    //   8: aload_0
    //   9: invokespecial <init> : (Lch/andeo/init7/tvapp/fragments/TVPlayerFragment;)V
    //   12: invokevirtual runOnUiThread : (Ljava/lang/Runnable;)V
    //   15: return }
  
  public void onMediaSourcesChanged() { // Byte code:
    //   0: aload_0
    //   1: invokevirtual getActivity : ()Landroidx/fragment/app/FragmentActivity;
    //   4: new ch/andeo/init7/tvapp/fragments/-$$Lambda$TVPlayerFragment$OWA9g7-5YOsTwYqDKFV1YvgjYJU
    //   7: dup
    //   8: aload_0
    //   9: invokespecial <init> : (Lch/andeo/init7/tvapp/fragments/TVPlayerFragment;)V
    //   12: invokevirtual runOnUiThread : (Ljava/lang/Runnable;)V
    //   15: return }
  
  public void onPlayerStateChanged(boolean paramBoolean, int paramInt) {
    if (paramInt == 4)
      this.mediaState.notifyEnded(); 
    if (paramInt == 2) {
      this.progressBar_buffer.setVisibility(0);
      return;
    } 
    this.progressBar_buffer.setVisibility(8);
  }
  
  public void onPositionDiscontinuity(int paramInt) {
    if (paramInt == 0) {
      Log.i("TVPlayerFragment", "Transition to next item");
      if (getCurrentMediaIndex() == this.playlist.getSize() - 1) {
        Log.i("TVPlayerFragment", "Last item in playlist, requesting new one");
        App.getInstance().getMediaState().requestNextMediaSource((MediaState.MediaSourceTag)this.player.getCurrentTag());
      } 
    } 
  }
  
  public void onStart() {
    initPlayer();
    this.mediaState.addEventListener(this);
    this.mediaState.initSplashScreen();
    super.onStart();
  }
  
  public void onStop() {
    deinitPlayer();
    this.mediaState.removeEventListener(this);
    super.onStop();
  }
  
  public void onTracksChanged(TrackGroupArray paramTrackGroupArray, TrackSelectionArray paramTrackSelectionArray) {
    Log.w("TVPlayerFragment", "Tracks changed");
    DebugUtil.printTrackGroups("TVPlayerFragment", paramTrackGroupArray);
    this.currentMappedTrackInfo = this.trackSelector.getCurrentMappedTrackInfo();
    this.trackSelectionViewModel.getAudioFormats().setValue(getAudioTracks());
    this.trackSelectionViewModel.getTextFormats().setValue(getTextTracks());
  }
  
  public void reinitPlayer() {
    deinitPlayer();
    initPlayer();
  }
}
