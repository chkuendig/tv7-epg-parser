package ch.andeo.init7.tvapp.fragments;

import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;
import ch.andeo.init7.core.model.EPGInfo;
import ch.andeo.init7.tvapp.TVPlayerActivity;
import ch.andeo.init7.tvapp.databinding.FragmentTransportControlsBinding;
import ch.andeo.init7.tvapp.ui.TintedImageButton;
import ch.andeo.init7.tvapp.ui.TrackSelectionDialog;
import ch.andeo.init7.tvapp.viewmodels.TVPlayerControlsViewModel;
import com.bumptech.glide.Glide;
import java.util.List;

public class TVPlayerControlsFragment extends TVPlayerActivity.TVPlayerActivityFragment implements TVPlayerActivity.FragmentKeyListener {
  private FragmentTransportControlsBinding view;
  
  private TVPlayerControlsViewModel viewModel;
  
  private <T> void observe(LiveData<T> paramLiveData, Observer<? super T> paramObserver) { paramLiveData.observe(getViewLifecycleOwner(), paramObserver); }
  
  public void onActivityCreated(Bundle paramBundle) { // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokespecial onActivityCreated : (Landroid/os/Bundle;)V
    //   5: aload_0
    //   6: aload_0
    //   7: getfield viewModel : Lch/andeo/init7/tvapp/viewmodels/TVPlayerControlsViewModel;
    //   10: invokevirtual getChannelLogoUrl : ()Landroidx/lifecycle/LiveData;
    //   13: new ch/andeo/init7/tvapp/fragments/-$$Lambda$TVPlayerControlsFragment$lRk-Lxd-a6vZAAUypjr5wXU65vg
    //   16: dup
    //   17: aload_0
    //   18: invokespecial <init> : (Lch/andeo/init7/tvapp/fragments/TVPlayerControlsFragment;)V
    //   21: invokespecial observe : (Landroidx/lifecycle/LiveData;Landroidx/lifecycle/Observer;)V
    //   24: aload_0
    //   25: getfield view : Lch/andeo/init7/tvapp/databinding/FragmentTransportControlsBinding;
    //   28: getfield seekBar : Landroid/widget/SeekBar;
    //   31: new ch/andeo/init7/tvapp/fragments/TVPlayerControlsFragment$1
    //   34: dup
    //   35: aload_0
    //   36: invokespecial <init> : (Lch/andeo/init7/tvapp/fragments/TVPlayerControlsFragment;)V
    //   39: invokevirtual setOnSeekBarChangeListener : (Landroid/widget/SeekBar$OnSeekBarChangeListener;)V
    //   42: aload_0
    //   43: getfield view : Lch/andeo/init7/tvapp/databinding/FragmentTransportControlsBinding;
    //   46: getfield seekBar : Landroid/widget/SeekBar;
    //   49: bipush #30
    //   51: invokevirtual setKeyProgressIncrement : (I)V
    //   54: aload_0
    //   55: aload_0
    //   56: getfield viewModel : Lch/andeo/init7/tvapp/viewmodels/TVPlayerControlsViewModel;
    //   59: invokevirtual getEpgLength : ()Landroidx/lifecycle/LiveData;
    //   62: new ch/andeo/init7/tvapp/fragments/-$$Lambda$TVPlayerControlsFragment$26nrJu2oNemhhd4RupLzV7gjUY0
    //   65: dup
    //   66: aload_0
    //   67: invokespecial <init> : (Lch/andeo/init7/tvapp/fragments/TVPlayerControlsFragment;)V
    //   70: invokespecial observe : (Landroidx/lifecycle/LiveData;Landroidx/lifecycle/Observer;)V
    //   73: aload_0
    //   74: aload_0
    //   75: getfield viewModel : Lch/andeo/init7/tvapp/viewmodels/TVPlayerControlsViewModel;
    //   78: invokevirtual getCurrentPlaybackPosition : ()Landroidx/lifecycle/LiveData;
    //   81: new ch/andeo/init7/tvapp/fragments/-$$Lambda$TVPlayerControlsFragment$y-AleFBMgG4djbEQa_XBQ4L6adg
    //   84: dup
    //   85: aload_0
    //   86: invokespecial <init> : (Lch/andeo/init7/tvapp/fragments/TVPlayerControlsFragment;)V
    //   89: invokespecial observe : (Landroidx/lifecycle/LiveData;Landroidx/lifecycle/Observer;)V
    //   92: aload_0
    //   93: aload_0
    //   94: getfield viewModel : Lch/andeo/init7/tvapp/viewmodels/TVPlayerControlsViewModel;
    //   97: invokevirtual getBufferedPlaybackPosition : ()Landroidx/lifecycle/MediatorLiveData;
    //   100: getstatic ch/andeo/init7/tvapp/fragments/-$$Lambda$TVPlayerControlsFragment$7njsSAAp8geQfM8d8GMm-0WKuX4.INSTANCE : Lch/andeo/init7/tvapp/fragments/-$$Lambda$TVPlayerControlsFragment$7njsSAAp8geQfM8d8GMm-0WKuX4;
    //   103: invokespecial observe : (Landroidx/lifecycle/LiveData;Landroidx/lifecycle/Observer;)V
    //   106: aload_0
    //   107: aload_0
    //   108: getfield viewModel : Lch/andeo/init7/tvapp/viewmodels/TVPlayerControlsViewModel;
    //   111: invokevirtual getCurrentEPGInfo : ()Landroidx/lifecycle/LiveData;
    //   114: new ch/andeo/init7/tvapp/fragments/-$$Lambda$TVPlayerControlsFragment$SwHTcp9s6z3SlulDhDSBeZt9QFM
    //   117: dup
    //   118: aload_0
    //   119: invokespecial <init> : (Lch/andeo/init7/tvapp/fragments/TVPlayerControlsFragment;)V
    //   122: invokespecial observe : (Landroidx/lifecycle/LiveData;Landroidx/lifecycle/Observer;)V
    //   125: aload_0
    //   126: aload_0
    //   127: getfield viewModel : Lch/andeo/init7/tvapp/viewmodels/TVPlayerControlsViewModel;
    //   130: invokevirtual getSeekAvailable : ()Landroidx/lifecycle/LiveData;
    //   133: new ch/andeo/init7/tvapp/fragments/-$$Lambda$TVPlayerControlsFragment$88PD2L5KzrN_n6Y8YIDld7u0h4g
    //   136: dup
    //   137: aload_0
    //   138: invokespecial <init> : (Lch/andeo/init7/tvapp/fragments/TVPlayerControlsFragment;)V
    //   141: invokespecial observe : (Landroidx/lifecycle/LiveData;Landroidx/lifecycle/Observer;)V
    //   144: aload_0
    //   145: getfield view : Lch/andeo/init7/tvapp/databinding/FragmentTransportControlsBinding;
    //   148: getfield buttonTracksAudio : Lch/andeo/init7/tvapp/ui/TintedImageButton;
    //   151: new ch/andeo/init7/tvapp/fragments/-$$Lambda$TVPlayerControlsFragment$fznWnaYYvJ9r4qDqhBINSrEaQaI
    //   154: dup
    //   155: aload_0
    //   156: invokespecial <init> : (Lch/andeo/init7/tvapp/fragments/TVPlayerControlsFragment;)V
    //   159: invokevirtual setOnClickListener : (Landroid/view/View$OnClickListener;)V
    //   162: aload_0
    //   163: getfield view : Lch/andeo/init7/tvapp/databinding/FragmentTransportControlsBinding;
    //   166: getfield buttonTracksText : Lch/andeo/init7/tvapp/ui/TintedImageButton;
    //   169: new ch/andeo/init7/tvapp/fragments/-$$Lambda$TVPlayerControlsFragment$dww7o1UUDIksLgRSFGzRgy8_WsY
    //   172: dup
    //   173: aload_0
    //   174: invokespecial <init> : (Lch/andeo/init7/tvapp/fragments/TVPlayerControlsFragment;)V
    //   177: invokevirtual setOnClickListener : (Landroid/view/View$OnClickListener;)V
    //   180: aload_0
    //   181: invokevirtual getViewModelProvider : ()Landroidx/lifecycle/ViewModelProvider;
    //   184: ldc ch/andeo/init7/tvapp/viewmodels/TrackSelectionViewModel
    //   186: invokevirtual get : (Ljava/lang/Class;)Landroidx/lifecycle/ViewModel;
    //   189: checkcast ch/andeo/init7/tvapp/viewmodels/TrackSelectionViewModel
    //   192: astore_1
    //   193: aload_1
    //   194: invokevirtual getAudioFormats : ()Landroidx/lifecycle/MutableLiveData;
    //   197: aload_0
    //   198: invokevirtual getViewLifecycleOwner : ()Landroidx/lifecycle/LifecycleOwner;
    //   201: new ch/andeo/init7/tvapp/fragments/-$$Lambda$TVPlayerControlsFragment$BJuY2-efPDV6J0Tpm3OFOQh31Ws
    //   204: dup
    //   205: aload_0
    //   206: invokespecial <init> : (Lch/andeo/init7/tvapp/fragments/TVPlayerControlsFragment;)V
    //   209: invokevirtual observe : (Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Observer;)V
    //   212: aload_1
    //   213: invokevirtual getTextFormats : ()Landroidx/lifecycle/MutableLiveData;
    //   216: aload_0
    //   217: invokevirtual getViewLifecycleOwner : ()Landroidx/lifecycle/LifecycleOwner;
    //   220: new ch/andeo/init7/tvapp/fragments/-$$Lambda$TVPlayerControlsFragment$rkCyd2E6Gu9GhnzsATkgP_KJa5c
    //   223: dup
    //   224: aload_0
    //   225: invokespecial <init> : (Lch/andeo/init7/tvapp/fragments/TVPlayerControlsFragment;)V
    //   228: invokevirtual observe : (Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Observer;)V
    //   231: return }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    this.viewModel = (TVPlayerControlsViewModel)getViewModelProvider().get(TVPlayerControlsViewModel.class);
  }
  
  public View onCreateView(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle) {
    this.view = FragmentTransportControlsBinding.inflate(paramLayoutInflater, paramViewGroup, false);
    this.view.setLifecycleOwner(getViewLifecycleOwner());
    this.view.setVm(this.viewModel);
    this.view.seekBar.setKeyProgressIncrement(30);
    return this.view.getRoot();
  }
  
  public void onFragmentFocused() { this.view.buttonPlay.requestFocus(); }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    TVPlayerActivity tVPlayerActivity = (TVPlayerActivity)getActivity();
    if (tVPlayerActivity == null)
      return false; 
    if ((this.view.seekBar.hasFocus() || !this.view.seekBar.isFocusable()) && paramInt == 19) {
      tVPlayerActivity.showFragment(0);
      return true;
    } 
    if (paramInt == 20 && !this.view.seekBar.hasFocus()) {
      tVPlayerActivity.showFragment(2131296459);
      return true;
    } 
    return false;
  }
}
