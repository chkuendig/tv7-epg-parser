package ch.andeo.init7.tvapp.fragments;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import butterknife.Unbinder;
import butterknife.internal.Utils;

public class TVPlayerChannelOverviewFragment_ViewBinding implements Unbinder {
  private TVPlayerChannelOverviewFragment target;
  
  public TVPlayerChannelOverviewFragment_ViewBinding(TVPlayerChannelOverviewFragment paramTVPlayerChannelOverviewFragment, View paramView) {
    this.target = paramTVPlayerChannelOverviewFragment;
    paramTVPlayerChannelOverviewFragment.recyclerViewChannel = (RecyclerView)Utils.findRequiredViewAsType(paramView, 2131296612, "field 'recyclerViewChannel'", RecyclerView.class);
    paramTVPlayerChannelOverviewFragment.recyclerViewPrograms = (RecyclerView)Utils.findRequiredViewAsType(paramView, 2131296613, "field 'recyclerViewPrograms'", RecyclerView.class);
    paramTVPlayerChannelOverviewFragment.textViewChannelName = (TextView)Utils.findRequiredViewAsType(paramView, 2131296681, "field 'textViewChannelName'", TextView.class);
    paramTVPlayerChannelOverviewFragment.textViewTime = (TextView)Utils.findRequiredViewAsType(paramView, 2131296685, "field 'textViewTime'", TextView.class);
    paramTVPlayerChannelOverviewFragment.imageViewChannelLogo = (ImageView)Utils.findRequiredViewAsType(paramView, 2131296501, "field 'imageViewChannelLogo'", ImageView.class);
    paramTVPlayerChannelOverviewFragment.imageViewLogoSmall = (ImageView)Utils.findRequiredViewAsType(paramView, 2131296502, "field 'imageViewLogoSmall'", ImageView.class);
    paramTVPlayerChannelOverviewFragment.textViewDate = (TextView)Utils.findRequiredViewAsType(paramView, 2131296682, "field 'textViewDate'", TextView.class);
    paramTVPlayerChannelOverviewFragment.viewProgramBackground = Utils.findRequiredView(paramView, 2131296717, "field 'viewProgramBackground'");
  }
  
  public void unbind() {
    TVPlayerChannelOverviewFragment tVPlayerChannelOverviewFragment = this.target;
    if (tVPlayerChannelOverviewFragment != null) {
      this.target = null;
      tVPlayerChannelOverviewFragment.recyclerViewChannel = null;
      tVPlayerChannelOverviewFragment.recyclerViewPrograms = null;
      tVPlayerChannelOverviewFragment.textViewChannelName = null;
      tVPlayerChannelOverviewFragment.textViewTime = null;
      tVPlayerChannelOverviewFragment.imageViewChannelLogo = null;
      tVPlayerChannelOverviewFragment.imageViewLogoSmall = null;
      tVPlayerChannelOverviewFragment.textViewDate = null;
      tVPlayerChannelOverviewFragment.viewProgramBackground = null;
      return;
    } 
    throw new IllegalStateException("Bindings already cleared.");
  }
}
