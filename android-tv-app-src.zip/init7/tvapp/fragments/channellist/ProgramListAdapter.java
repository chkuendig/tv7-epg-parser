package ch.andeo.init7.tvapp.fragments.channellist;

import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import androidx.lifecycle.LiveData;
import androidx.recyclerview.widget.RecyclerView;
import ch.andeo.init7.core.model.EPGInfo;
import ch.andeo.init7.tvapp.databinding.LayoutProgramListitemBinding;
import ch.andeo.init7.tvapp.ui.BoundViewHolder;
import java.util.List;

public class ProgramListAdapter extends RecyclerView.Adapter<BoundViewHolder<LayoutProgramListitemBinding>> {
  private static final String TAG = "ProgramListAdapter";
  
  private ProgramInteractionListener clickListener;
  
  private LiveData<EPGInfo> currentPlayingChannel;
  
  private List<EPGInfo> epgInfoList;
  
  private boolean focusEnabled = false;
  
  private final ProgramInteractionListener focusListener;
  
  private EPGInfo focusedEPG;
  
  private boolean hasReplay;
  
  private EPGInfo selectedEPG;
  
  public ProgramListAdapter(ProgramInteractionListener paramProgramInteractionListener1, ProgramInteractionListener paramProgramInteractionListener2, LiveData<EPGInfo> paramLiveData) {
    this.clickListener = paramProgramInteractionListener1;
    this.focusListener = paramProgramInteractionListener2;
    this.currentPlayingChannel = paramLiveData;
  }
  
  private void setFocus() {
    if (this.focusedEPG == null)
      this.focusedEPG = this.selectedEPG; 
    notifyItemChanged(this.epgInfoList.indexOf(this.focusedEPG));
  }
  
  public int getItemCount() {
    List list = this.epgInfoList;
    return (list == null) ? 0 : list.size();
  }
  
  public void onBindViewHolder(BoundViewHolder<LayoutProgramListitemBinding> paramBoundViewHolder, int paramInt) { // Byte code:
    //   0: aload_1
    //   1: invokevirtual isAttached : ()Z
    //   4: ifne -> 11
    //   7: aload_1
    //   8: invokevirtual notifyAttached : ()V
    //   11: aload_0
    //   12: getfield epgInfoList : Ljava/util/List;
    //   15: iload_2
    //   16: invokeinterface get : (I)Ljava/lang/Object;
    //   21: checkcast ch/andeo/init7/core/model/EPGInfo
    //   24: astore #4
    //   26: getstatic ch/andeo/init7/tvapp/App.FORMAT_TIME : Ljava/text/DateFormat;
    //   29: new java/util/Date
    //   32: dup
    //   33: aload #4
    //   35: getfield tsStart : J
    //   38: invokespecial <init> : (J)V
    //   41: invokevirtual format : (Ljava/util/Date;)Ljava/lang/String;
    //   44: astore #5
    //   46: getstatic ch/andeo/init7/tvapp/App.FORMAT_TIME : Ljava/text/DateFormat;
    //   49: new java/util/Date
    //   52: dup
    //   53: aload #4
    //   55: getfield tsEnd : J
    //   58: invokespecial <init> : (J)V
    //   61: invokevirtual format : (Ljava/util/Date;)Ljava/lang/String;
    //   64: astore #6
    //   66: aload_1
    //   67: invokevirtual getRootView : ()Landroidx/databinding/ViewDataBinding;
    //   70: checkcast ch/andeo/init7/tvapp/databinding/LayoutProgramListitemBinding
    //   73: astore #7
    //   75: aload #7
    //   77: aload #4
    //   79: invokevirtual setEpg : (Lch/andeo/init7/core/model/EPGInfo;)V
    //   82: aload_0
    //   83: getfield hasReplay : Z
    //   86: ifeq -> 108
    //   89: aload #4
    //   91: getstatic ch/andeo/init7/tvapp/App.CLOCK : Lorg/threeten/bp/Clock;
    //   94: invokevirtual millis : ()J
    //   97: invokevirtual isInPast : (J)Z
    //   100: ifeq -> 108
    //   103: iconst_1
    //   104: istore_3
    //   105: goto -> 110
    //   108: iconst_0
    //   109: istore_3
    //   110: aload #7
    //   112: iload_3
    //   113: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   116: invokevirtual setHasReplay : (Ljava/lang/Boolean;)V
    //   119: new java/lang/StringBuilder
    //   122: dup
    //   123: invokespecial <init> : ()V
    //   126: astore #8
    //   128: aload #8
    //   130: aload #5
    //   132: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   135: pop
    //   136: aload #8
    //   138: ldc ' - '
    //   140: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   143: pop
    //   144: aload #8
    //   146: aload #6
    //   148: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   151: pop
    //   152: aload #7
    //   154: aload #8
    //   156: invokevirtual toString : ()Ljava/lang/String;
    //   159: invokevirtual setShowTime : (Ljava/lang/String;)V
    //   162: aload_0
    //   163: getfield focusEnabled : Z
    //   166: ifeq -> 190
    //   169: aload #4
    //   171: aload_0
    //   172: getfield focusedEPG : Lch/andeo/init7/core/model/EPGInfo;
    //   175: invokevirtual equals : (Ljava/lang/Object;)Z
    //   178: ifeq -> 190
    //   181: aload #7
    //   183: getfield constraintLayoutWrapper : Lch/andeo/init7/tvapp/ui/MultiStateConstraintLayout;
    //   186: invokevirtual requestFocus : ()Z
    //   189: pop
    //   190: aload #7
    //   192: getfield constraintLayoutWrapper : Lch/andeo/init7/tvapp/ui/MultiStateConstraintLayout;
    //   195: new ch/andeo/init7/tvapp/fragments/channellist/-$$Lambda$ProgramListAdapter$uMqtwUkPGVWrbXHfztRHuvfIG8I
    //   198: dup
    //   199: aload_0
    //   200: aload #4
    //   202: iload_2
    //   203: invokespecial <init> : (Lch/andeo/init7/tvapp/fragments/channellist/ProgramListAdapter;Lch/andeo/init7/core/model/EPGInfo;I)V
    //   206: invokevirtual setOnFocusChangeListener : (Landroid/view/View$OnFocusChangeListener;)V
    //   209: aload #7
    //   211: getfield constraintLayoutWrapper : Lch/andeo/init7/tvapp/ui/MultiStateConstraintLayout;
    //   214: new ch/andeo/init7/tvapp/fragments/channellist/-$$Lambda$ProgramListAdapter$0REoZqel3gyI69sXBE3xRSO2yAs
    //   217: dup
    //   218: aload_0
    //   219: aload #4
    //   221: iload_2
    //   222: invokespecial <init> : (Lch/andeo/init7/tvapp/fragments/channellist/ProgramListAdapter;Lch/andeo/init7/core/model/EPGInfo;I)V
    //   225: invokevirtual setOnClickListener : (Landroid/view/View$OnClickListener;)V
    //   228: aload_0
    //   229: getfield currentPlayingChannel : Landroidx/lifecycle/LiveData;
    //   232: aload_1
    //   233: new ch/andeo/init7/tvapp/fragments/channellist/-$$Lambda$ProgramListAdapter$P6kzyVq0RPnKeQRphSv3c9DOghI
    //   236: dup
    //   237: aload #4
    //   239: aload #7
    //   241: invokespecial <init> : (Lch/andeo/init7/core/model/EPGInfo;Lch/andeo/init7/tvapp/databinding/LayoutProgramListitemBinding;)V
    //   244: invokevirtual observe : (Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Observer;)V
    //   247: return }
  
  public BoundViewHolder<LayoutProgramListitemBinding> onCreateViewHolder(ViewGroup paramViewGroup, int paramInt) { return BoundViewHolder.create(LayoutProgramListitemBinding.class, paramViewGroup); }
  
  public void onViewDetachedFromWindow(BoundViewHolder<LayoutProgramListitemBinding> paramBoundViewHolder) {
    if (paramBoundViewHolder.isAttached())
      paramBoundViewHolder.notifyDetached(); 
    super.onViewDetachedFromWindow(paramBoundViewHolder);
  }
  
  public void setFocusEnabled(boolean paramBoolean) {
    if (!this.focusEnabled && paramBoolean)
      setFocus(); 
    this.focusEnabled = paramBoolean;
  }
  
  public void setFocusedEPG(EPGInfo paramEPGInfo) { this.focusedEPG = paramEPGInfo; }
  
  public void setSelectedEPG(EPGInfo paramEPGInfo) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Selected channel set: ");
    stringBuilder.append(paramEPGInfo);
    Log.i("ProgramListAdapter", stringBuilder.toString());
    this.selectedEPG = paramEPGInfo;
    notifyDataSetChanged();
  }
  
  public void updateList(List<EPGInfo> paramList, boolean paramBoolean) {
    this.epgInfoList = paramList;
    this.hasReplay = paramBoolean;
    notifyDataSetChanged();
  }
}
