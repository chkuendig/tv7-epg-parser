package ch.andeo.init7.tvapp.fragments.channellist;

import android.view.ViewGroup;
import androidx.lifecycle.MutableLiveData;
import androidx.recyclerview.widget.RecyclerView;
import ch.andeo.init7.core.dao.TvChannelDao;
import ch.andeo.init7.core.model.TvChannel;
import ch.andeo.init7.core.util.Util;
import ch.andeo.init7.tvapp.databinding.LayoutChannelListitemBinding;
import ch.andeo.init7.tvapp.ui.BoundViewHolder;

public class ChannelListAdapter extends RecyclerView.Adapter<ChannelListAdapter.ChannelViewHolder> {
  private static final String TAG = "ChannelListAdapter";
  
  private final TvChannelDao channelDao;
  
  private MutableLiveData<TvChannel> channelFocusRequest = new MutableLiveData();
  
  private final ChannelInteractionListener clickListener;
  
  private final ChannelInteractionListener focusListener;
  
  private int listSize = 0;
  
  private MutableLiveData<TvChannel> playingChannel = new MutableLiveData();
  
  private MutableLiveData<TvChannel> selectedChannel = new MutableLiveData();
  
  public ChannelListAdapter(TvChannelDao paramTvChannelDao, ChannelInteractionListener paramChannelInteractionListener1, ChannelInteractionListener paramChannelInteractionListener2) {
    this.channelDao = paramTvChannelDao;
    this.clickListener = paramChannelInteractionListener1;
    this.focusListener = paramChannelInteractionListener2;
  }
  
  public MutableLiveData<TvChannel> getChannelFocusRequest() { return this.channelFocusRequest; }
  
  public int getItemCount() { return this.listSize; }
  
  public void onBindViewHolder(ChannelViewHolder paramChannelViewHolder, int paramInt) {
    if (paramChannelViewHolder.isAttached()) {
      paramChannelViewHolder.notifyDetached();
      return;
    } 
    paramChannelViewHolder.notifyAttached();
    paramChannelViewHolder.init(paramInt);
  }
  
  public ChannelViewHolder onCreateViewHolder(ViewGroup paramViewGroup, int paramInt) { return new ChannelViewHolder(this, (LayoutChannelListitemBinding)BoundViewHolder.createDataBinding(LayoutChannelListitemBinding.class, paramViewGroup)); }
  
  public void onViewRecycled(ChannelViewHolder paramChannelViewHolder) {
    if (paramChannelViewHolder.isAttached())
      paramChannelViewHolder.notifyDetached(); 
    super.onViewRecycled(paramChannelViewHolder);
  }
  
  public void registerAdapterDataObserver(RecyclerView.AdapterDataObserver paramAdapterDataObserver) { super.registerAdapterDataObserver(paramAdapterDataObserver); }
  
  public void setListSize(int paramInt) {
    if (this.listSize != paramInt) {
      this.listSize = paramInt;
      notifyDataSetChanged();
    } 
  }
  
  public void setPlayingChannel(TvChannel paramTvChannel) { Util.update(this.playingChannel, paramTvChannel); }
}
