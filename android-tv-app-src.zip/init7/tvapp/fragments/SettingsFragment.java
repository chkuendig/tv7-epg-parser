package ch.andeo.init7.tvapp.fragments;

import android.os.Bundle;
import android.view.KeyEvent;
import androidx.leanback.preference.LeanbackPreferenceFragmentCompat;
import androidx.preference.Preference;
import ch.andeo.init7.tvapp.TVPlayerActivity;

public class SettingsFragment extends LeanbackPreferenceFragmentCompat implements TVPlayerActivity.FragmentKeyListener {
  private TVPlayerActivity owner;
  
  public void onCreatePreferences(Bundle paramBundle, String paramString) {
    this.owner = (TVPlayerActivity)getActivity();
    getPreferenceManager().setSharedPreferencesName("App");
    setPreferencesFromResource(2131951616, paramString);
    Preference preference = findPreference("app_version");
    if (preference != null)
      preference.setSummary("0.0.13-dev (13)"); 
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    if (paramInt == 22)
      this.owner.showFragment(0); 
    return false;
  }
}
