package ch.andeo.init7.tvapp.fragments;

import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import ch.andeo.init7.core.model.EPGInfo;
import ch.andeo.init7.core.model.TvChannel;
import ch.andeo.init7.tvapp.TVPlayerActivity;
import ch.andeo.init7.tvapp.androidutil.ViewUtil;
import ch.andeo.init7.tvapp.databinding.FragmentTvplayerEpgBinding;
import ch.andeo.init7.tvapp.viewmodels.EPGSelectorViewModel;
import ch.andeo.init7.tvapp.viewmodels.MediaState;
import com.bumptech.glide.Glide;

public class TVPlayerEPGFragment extends TVPlayerActivity.TVPlayerActivityFragment implements TVPlayerActivity.FragmentKeyListener {
  private EPGSelectorViewModel livedata;
  
  private MediaState mediaState;
  
  private FragmentTvplayerEpgBinding view;
  
  public View onCreateView(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle) { // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: aload_2
    //   3: iconst_0
    //   4: invokestatic inflate : (Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Z)Lch/andeo/init7/tvapp/databinding/FragmentTvplayerEpgBinding;
    //   7: putfield view : Lch/andeo/init7/tvapp/databinding/FragmentTvplayerEpgBinding;
    //   10: aload_0
    //   11: aload_0
    //   12: invokevirtual getViewModelProvider : ()Landroidx/lifecycle/ViewModelProvider;
    //   15: ldc ch/andeo/init7/tvapp/viewmodels/EPGSelectorViewModel
    //   17: invokevirtual get : (Ljava/lang/Class;)Landroidx/lifecycle/ViewModel;
    //   20: checkcast ch/andeo/init7/tvapp/viewmodels/EPGSelectorViewModel
    //   23: putfield livedata : Lch/andeo/init7/tvapp/viewmodels/EPGSelectorViewModel;
    //   26: aload_0
    //   27: invokestatic getInstance : ()Lch/andeo/init7/tvapp/App;
    //   30: invokevirtual getMediaState : ()Lch/andeo/init7/tvapp/viewmodels/MediaState;
    //   33: putfield mediaState : Lch/andeo/init7/tvapp/viewmodels/MediaState;
    //   36: aload_0
    //   37: getfield view : Lch/andeo/init7/tvapp/databinding/FragmentTvplayerEpgBinding;
    //   40: aload_0
    //   41: getfield livedata : Lch/andeo/init7/tvapp/viewmodels/EPGSelectorViewModel;
    //   44: invokevirtual setLivedata : (Lch/andeo/init7/tvapp/viewmodels/EPGSelectorViewModel;)V
    //   47: aload_0
    //   48: getfield view : Lch/andeo/init7/tvapp/databinding/FragmentTvplayerEpgBinding;
    //   51: aload_0
    //   52: invokevirtual getViewLifecycleOwner : ()Landroidx/lifecycle/LifecycleOwner;
    //   55: invokevirtual setLifecycleOwner : (Landroidx/lifecycle/LifecycleOwner;)V
    //   58: aload_0
    //   59: getfield mediaState : Lch/andeo/init7/tvapp/viewmodels/MediaState;
    //   62: invokevirtual getCurrentChannel : ()Landroidx/lifecycle/LiveData;
    //   65: aload_0
    //   66: invokevirtual getViewLifecycleOwner : ()Landroidx/lifecycle/LifecycleOwner;
    //   69: new ch/andeo/init7/tvapp/fragments/-$$Lambda$TVPlayerEPGFragment$TapTOgvwjWy3rR6TzWBxIED4dU4
    //   72: dup
    //   73: aload_0
    //   74: invokespecial <init> : (Lch/andeo/init7/tvapp/fragments/TVPlayerEPGFragment;)V
    //   77: invokevirtual observe : (Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Observer;)V
    //   80: aload_0
    //   81: getfield view : Lch/andeo/init7/tvapp/databinding/FragmentTvplayerEpgBinding;
    //   84: invokevirtual getRoot : ()Landroid/view/View;
    //   87: areturn }
  
  public void onFragmentFocused() {}
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    if (paramInt == 19) {
      ((TVPlayerActivity)getOwner()).showFragment(2131296458);
      return true;
    } 
    switch (paramInt) {
      default:
        return false;
      case 23:
        if (((Boolean)this.livedata.getHasReplay().getValue()).booleanValue()) {
          this.mediaState.selectEPG((EPGInfo)this.livedata.getDisplayEPG().getValue());
          ViewUtil.forceRippleAnimation(this.view.imageViewStartReplayButton);
        } 
        return true;
      case 22:
        this.livedata.nextEPG();
        return true;
      case 21:
        break;
    } 
    this.livedata.prevEPG();
    return true;
  }
}
