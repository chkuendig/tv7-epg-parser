package ch.andeo.init7.tvapp.exoplayerutil;

import android.net.Uri;
import ch.andeo.init7.tvapp.App;
import ch.andeo.init7.tvapp.viewmodels.MediaState;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.source.ProgressiveMediaSource;
import com.google.android.exoplayer2.source.hls.DefaultHlsExtractorFactory;
import com.google.android.exoplayer2.source.hls.HlsMediaSource;
import com.google.android.exoplayer2.upstream.DataSource;

public class MediaSourceFactory {
  public static MediaSource createMediaSource(String paramString) { return createMediaSource(paramString, null); }
  
  public static MediaSource createMediaSource(String paramString, MediaState.MediaSourceTag paramMediaSourceTag) {
    DataSource.Factory factory = App.getInstance().getDataSourceFactory();
    if (paramString.startsWith("asset://") || paramString.startsWith("udp://"))
      return (new ProgressiveMediaSource.Factory(factory)).setTag(paramMediaSourceTag).createMediaSource(Uri.parse(paramString)); 
    if (paramString.startsWith("http"))
      return (new HlsMediaSource.Factory(factory)).setTag(paramMediaSourceTag).setExtractorFactory(new DefaultHlsExtractorFactory(17, true)).createMediaSource(Uri.parse(paramString)); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Unsupported media source format: ");
    stringBuilder.append(paramString);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
}
