package ch.andeo.init7.tvapp.exoplayerutil;

import android.util.Log;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.Timeline;
import com.google.android.exoplayer2.source.TrackGroup;
import com.google.android.exoplayer2.source.TrackGroupArray;
import java.lang.reflect.Field;

public class DebugUtil {
  public static void printTrackGroups(String paramString, TrackGroupArray paramTrackGroupArray) {
    for (byte b = 0; b < paramTrackGroupArray.length; b++) {
      TrackGroup trackGroup = paramTrackGroupArray.get(b);
      for (byte b1 = 0; b1 < trackGroup.length; b1++) {
        Format format = trackGroup.getFormat(b1);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Format[");
        stringBuilder.append(b);
        stringBuilder.append("][");
        stringBuilder.append(b1);
        stringBuilder.append("]: ");
        stringBuilder.append(format.id);
        stringBuilder.append("\t");
        stringBuilder.append(format.sampleMimeType);
        stringBuilder.append("\t");
        stringBuilder.append(format.language);
        stringBuilder.append("\t");
        stringBuilder.append(format.label);
        Log.i(paramString, stringBuilder.toString());
      } 
    } 
  }
  
  public static void printWindows(String paramString, int paramInt, Timeline paramTimeline) {
    int i = paramTimeline.getWindowCount();
    Timeline.Window window = new Timeline.Window();
    byte b = 0;
    label17: while (true) {
      if (b < i) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Timeline [");
        stringBuilder.append(b);
        stringBuilder.append("]:");
        Log.println(paramInt, paramString, stringBuilder.toString());
        window = paramTimeline.getWindow(b, window);
        Field[] arrayOfField = window.getClass().getDeclaredFields();
        int j = arrayOfField.length;
        byte b1 = 0;
        while (true) {
          if (b1 < j) {
            field = arrayOfField[b1];
            try {
              StringBuilder stringBuilder1 = new StringBuilder();
              stringBuilder1.append("  - ");
              stringBuilder1.append(field.getName());
              stringBuilder1.append(": ");
              stringBuilder1.append(field.get(window));
              Log.println(paramInt, paramString, stringBuilder1.toString());
            } catch (IllegalAccessException field) {}
            b1++;
            continue;
          } 
          b++;
          continue label17;
        } 
        break;
      } 
      return;
    } 
  }
}
