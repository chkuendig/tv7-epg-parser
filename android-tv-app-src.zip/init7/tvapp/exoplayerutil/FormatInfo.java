package ch.andeo.init7.tvapp.exoplayerutil;

import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.source.TrackGroupArray;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import java.util.Locale;

public class FormatInfo {
  private String displayName;
  
  private int rendererIndex;
  
  private DefaultTrackSelector.SelectionOverride selectionOverride;
  
  private TrackGroupArray trackGroupArray;
  
  public FormatInfo(int paramInt1, int paramInt2, Format paramFormat, int paramInt3, TrackGroupArray paramTrackGroupArray) {
    this.selectionOverride = new DefaultTrackSelector.SelectionOverride(paramInt1, new int[] { paramInt2 });
    this.rendererIndex = paramInt3;
    this.trackGroupArray = paramTrackGroupArray;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Track ");
    stringBuilder.append(paramInt1 + 1);
    this.displayName = stringBuilder.toString();
    if (paramFormat.language != null) {
      stringBuilder = new StringBuilder();
      stringBuilder.append(this.displayName);
      stringBuilder.append(" (");
      stringBuilder.append(Locale.forLanguageTag(paramFormat.language).getDisplayLanguage(Locale.GERMANY));
      stringBuilder.append(")");
      this.displayName = stringBuilder.toString();
    } 
  }
  
  public String getDisplayName() { return this.displayName; }
  
  public DefaultTrackSelector.Parameters updateParametersWithOverride(DefaultTrackSelector.Parameters paramParameters) { return paramParameters.buildUpon().clearSelectionOverrides(this.rendererIndex).setRendererDisabled(this.rendererIndex, false).setSelectionOverride(this.rendererIndex, this.trackGroupArray, this.selectionOverride).build(); }
}
