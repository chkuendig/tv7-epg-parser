package ch.andeo.init7.tvapp.exoplayerutil;

import android.widget.TextView;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.ui.DebugTextViewHelper;

public class ExtendedDebugTextViewHelper extends DebugTextViewHelper {
  private String mediaSource;
  
  public ExtendedDebugTextViewHelper(SimpleExoPlayer paramSimpleExoPlayer, TextView paramTextView) { super(paramSimpleExoPlayer, paramTextView); }
  
  private String getMediaSource() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("src:");
    stringBuilder.append(this.mediaSource);
    stringBuilder.append("\n");
    return stringBuilder.toString();
  }
  
  protected String getDebugString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(getMediaSource());
    stringBuilder.append(super.getDebugString());
    return stringBuilder.toString();
  }
  
  public void updateMediaSource(String paramString) { this.mediaSource = paramString; }
}
