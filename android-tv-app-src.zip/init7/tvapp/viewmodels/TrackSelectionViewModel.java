package ch.andeo.init7.tvapp.viewmodels;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import ch.andeo.init7.tvapp.exoplayerutil.FormatInfo;
import java.util.List;

public class TrackSelectionViewModel extends ViewModel {
  private MutableLiveData<List<FormatInfo>> audioFormats = new MutableLiveData();
  
  private MutableLiveData<FormatInfo> audioOverride = new MutableLiveData();
  
  private MutableLiveData<List<FormatInfo>> textFormats = new MutableLiveData();
  
  private MutableLiveData<FormatInfo> textOverride = new MutableLiveData();
  
  public MutableLiveData<List<FormatInfo>> getAudioFormats() { return this.audioFormats; }
  
  public MutableLiveData<FormatInfo> getAudioOverride() { return this.audioOverride; }
  
  public MutableLiveData<List<FormatInfo>> getFormats(int paramInt) {
    if (paramInt != 1) {
      if (paramInt == 3)
        return this.textFormats; 
      throw new IllegalArgumentException();
    } 
    return this.audioFormats;
  }
  
  public MutableLiveData<FormatInfo> getOverride(int paramInt) {
    if (paramInt != 1) {
      if (paramInt == 3)
        return this.textOverride; 
      throw new IllegalArgumentException();
    } 
    return this.audioOverride;
  }
  
  public MutableLiveData<List<FormatInfo>> getTextFormats() { return this.textFormats; }
  
  public MutableLiveData<FormatInfo> getTextOverride() { return this.textOverride; }
}
