package ch.andeo.init7.tvapp.viewmodels;

import android.app.Application;
import android.util.Log;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MediatorLiveData;
import androidx.lifecycle.MutableLiveData;
import ch.andeo.init7.core.model.EPGInfo;
import ch.andeo.init7.core.model.TvChannel;
import ch.andeo.init7.core.util.Util;
import ch.andeo.init7.tvapp.App;
import ch.andeo.init7.tvapp.androidutil.MutableLiveDataReference;
import ch.andeo.init7.tvapp.androidutil.NNMediatorLiveData;
import java.util.List;

public class TVPlayerChannelOverviewViewModel extends AndroidViewModel {
  private static final String TAG = "TVPChannelOverviewVM";
  
  private final App app;
  
  private final MediatorLiveData<List<TvChannel>> channelList;
  
  private final MediatorLiveData<EPGInfo> currentPlayingEPG;
  
  private final MediatorLiveData<TvChannel> currentPlayingTVChannel;
  
  private final MutableLiveData<EPGInfo> currentSelectedEPG;
  
  private final NNMediatorLiveData<List<EPGInfo>> epgList;
  
  private final MutableLiveDataReference<List<EPGInfo>> epgReference;
  
  private final MediatorLiveData<TvChannel> selectedTVChannel;
  
  public TVPlayerChannelOverviewViewModel(Application paramApplication) { // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokespecial <init> : (Landroid/app/Application;)V
    //   5: aload_0
    //   6: new androidx/lifecycle/MediatorLiveData
    //   9: dup
    //   10: invokespecial <init> : ()V
    //   13: putfield currentPlayingTVChannel : Landroidx/lifecycle/MediatorLiveData;
    //   16: aload_0
    //   17: new androidx/lifecycle/MediatorLiveData
    //   20: dup
    //   21: invokespecial <init> : ()V
    //   24: putfield currentPlayingEPG : Landroidx/lifecycle/MediatorLiveData;
    //   27: aload_0
    //   28: new androidx/lifecycle/MediatorLiveData
    //   31: dup
    //   32: invokespecial <init> : ()V
    //   35: putfield selectedTVChannel : Landroidx/lifecycle/MediatorLiveData;
    //   38: aload_0
    //   39: new androidx/lifecycle/MediatorLiveData
    //   42: dup
    //   43: invokespecial <init> : ()V
    //   46: putfield currentSelectedEPG : Landroidx/lifecycle/MutableLiveData;
    //   49: aload_0
    //   50: new ch/andeo/init7/tvapp/androidutil/MutableLiveDataReference
    //   53: dup
    //   54: invokespecial <init> : ()V
    //   57: putfield epgReference : Lch/andeo/init7/tvapp/androidutil/MutableLiveDataReference;
    //   60: aload_0
    //   61: new ch/andeo/init7/tvapp/androidutil/NNMediatorLiveData
    //   64: dup
    //   65: new java/util/ArrayList
    //   68: dup
    //   69: invokespecial <init> : ()V
    //   72: invokespecial <init> : (Ljava/lang/Object;)V
    //   75: putfield epgList : Lch/andeo/init7/tvapp/androidutil/NNMediatorLiveData;
    //   78: aload_0
    //   79: aload_0
    //   80: invokevirtual getApplication : ()Landroid/app/Application;
    //   83: checkcast ch/andeo/init7/tvapp/App
    //   86: putfield app : Lch/andeo/init7/tvapp/App;
    //   89: aload_0
    //   90: getfield app : Lch/andeo/init7/tvapp/App;
    //   93: invokevirtual getMediaState : ()Lch/andeo/init7/tvapp/viewmodels/MediaState;
    //   96: astore_1
    //   97: aload_0
    //   98: getfield currentPlayingTVChannel : Landroidx/lifecycle/MediatorLiveData;
    //   101: aload_1
    //   102: invokevirtual getCurrentChannel : ()Landroidx/lifecycle/LiveData;
    //   105: new ch/andeo/init7/tvapp/viewmodels/-$$Lambda$TVPlayerChannelOverviewViewModel$yBmkBqKrl6cYGbfFOhNxvMkDp_c
    //   108: dup
    //   109: aload_0
    //   110: invokespecial <init> : (Lch/andeo/init7/tvapp/viewmodels/TVPlayerChannelOverviewViewModel;)V
    //   113: invokevirtual addSource : (Landroidx/lifecycle/LiveData;Landroidx/lifecycle/Observer;)V
    //   116: aload_0
    //   117: getfield selectedTVChannel : Landroidx/lifecycle/MediatorLiveData;
    //   120: aload_1
    //   121: invokevirtual getCurrentChannel : ()Landroidx/lifecycle/LiveData;
    //   124: new ch/andeo/init7/tvapp/viewmodels/-$$Lambda$TVPlayerChannelOverviewViewModel$bhVO2ZkvB_GlCEDHa-QQOvR1nsI
    //   127: dup
    //   128: aload_0
    //   129: invokespecial <init> : (Lch/andeo/init7/tvapp/viewmodels/TVPlayerChannelOverviewViewModel;)V
    //   132: invokevirtual addSource : (Landroidx/lifecycle/LiveData;Landroidx/lifecycle/Observer;)V
    //   135: aload_0
    //   136: getfield currentPlayingEPG : Landroidx/lifecycle/MediatorLiveData;
    //   139: aload_1
    //   140: invokevirtual getCurrentEPG : ()Landroidx/lifecycle/LiveData;
    //   143: new ch/andeo/init7/tvapp/viewmodels/-$$Lambda$TVPlayerChannelOverviewViewModel$cy0ocNTHkHnE5Ex_Wd2XCEFKN0w
    //   146: dup
    //   147: aload_0
    //   148: invokespecial <init> : (Lch/andeo/init7/tvapp/viewmodels/TVPlayerChannelOverviewViewModel;)V
    //   151: invokevirtual addSource : (Landroidx/lifecycle/LiveData;Landroidx/lifecycle/Observer;)V
    //   154: aload_0
    //   155: new androidx/lifecycle/MediatorLiveData
    //   158: dup
    //   159: invokespecial <init> : ()V
    //   162: putfield channelList : Landroidx/lifecycle/MediatorLiveData;
    //   165: aload_0
    //   166: getfield channelList : Landroidx/lifecycle/MediatorLiveData;
    //   169: aload_0
    //   170: getfield app : Lch/andeo/init7/tvapp/App;
    //   173: invokevirtual getDb : ()Lch/andeo/init7/core/TvDB;
    //   176: invokevirtual tvChannelDao : ()Lch/andeo/init7/core/dao/TvChannelDao;
    //   179: aload_0
    //   180: getfield app : Lch/andeo/init7/tvapp/App;
    //   183: invokevirtual getLanguageCode : ()Ljava/lang/String;
    //   186: invokeinterface getAll : (Ljava/lang/String;)Landroidx/lifecycle/LiveData;
    //   191: new ch/andeo/init7/tvapp/viewmodels/-$$Lambda$TVPlayerChannelOverviewViewModel$F9Eb75WdBkpxFwACN3o4GtSSwuQ
    //   194: dup
    //   195: aload_0
    //   196: invokespecial <init> : (Lch/andeo/init7/tvapp/viewmodels/TVPlayerChannelOverviewViewModel;)V
    //   199: invokevirtual addSource : (Landroidx/lifecycle/LiveData;Landroidx/lifecycle/Observer;)V
    //   202: aload_0
    //   203: getfield epgReference : Lch/andeo/init7/tvapp/androidutil/MutableLiveDataReference;
    //   206: aload_0
    //   207: getfield selectedTVChannel : Landroidx/lifecycle/MediatorLiveData;
    //   210: new ch/andeo/init7/tvapp/viewmodels/-$$Lambda$TVPlayerChannelOverviewViewModel$n-9cQk8SkQsIT7P7gejuLOOko7Q
    //   213: dup
    //   214: aload_0
    //   215: invokespecial <init> : (Lch/andeo/init7/tvapp/viewmodels/TVPlayerChannelOverviewViewModel;)V
    //   218: invokevirtual addSource : (Landroidx/lifecycle/LiveData;Landroidx/lifecycle/Observer;)V
    //   221: aload_0
    //   222: getfield epgList : Lch/andeo/init7/tvapp/androidutil/NNMediatorLiveData;
    //   225: aload_0
    //   226: getfield epgReference : Lch/andeo/init7/tvapp/androidutil/MutableLiveDataReference;
    //   229: new ch/andeo/init7/tvapp/viewmodels/-$$Lambda$TVPlayerChannelOverviewViewModel$srYr2nT-OascWWQsTtdV7yX199k
    //   232: dup
    //   233: aload_0
    //   234: invokespecial <init> : (Lch/andeo/init7/tvapp/viewmodels/TVPlayerChannelOverviewViewModel;)V
    //   237: invokevirtual addSource : (Landroidx/lifecycle/LiveData;Landroidx/lifecycle/Observer;)V
    //   240: return }
  
  public LiveData<List<TvChannel>> getChannelList() { return this.channelList; }
  
  public LiveData<EPGInfo> getCurrentPlayingEPG() { return this.currentPlayingEPG; }
  
  public LiveData<TvChannel> getCurrentPlayingTVChannel() { return this.currentPlayingTVChannel; }
  
  public MutableLiveData<EPGInfo> getCurrentSelectedEPG() { return this.currentSelectedEPG; }
  
  public LiveData<List<EPGInfo>> getEpgList() { return this.epgList; }
  
  public MutableLiveData<TvChannel> getSelectedTVChannel() { return this.selectedTVChannel; }
}
