package ch.andeo.init7.tvapp.viewmodels;

import android.app.Application;
import androidx.lifecycle.AndroidViewModel;
import ch.andeo.init7.core.model.EPGInfo;
import ch.andeo.init7.core.model.TvChannel;
import ch.andeo.init7.tvapp.App;
import ch.andeo.init7.tvapp.androidutil.NNMediatorLiveData;
import java.util.Date;
import java.util.concurrent.ExecutorService;

public class EPGSelectorViewModel extends AndroidViewModel {
  private final App app;
  
  private NNMediatorLiveData<String> channelName;
  
  private NNMediatorLiveData<EPGInfo> displayEPG;
  
  private NNMediatorLiveData<Boolean> hasReplay;
  
  private NNMediatorLiveData<String> programDate;
  
  private NNMediatorLiveData<String> programDesc;
  
  private NNMediatorLiveData<String> programName;
  
  private NNMediatorLiveData<String> programSubtitle;
  
  private NNMediatorLiveData<String> programTime;
  
  private ExecutorService service;
  
  public EPGSelectorViewModel(Application paramApplication) { // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokespecial <init> : (Landroid/app/Application;)V
    //   5: aload_0
    //   6: new ch/andeo/init7/tvapp/androidutil/NNMediatorLiveData
    //   9: dup
    //   10: iconst_0
    //   11: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   14: invokespecial <init> : (Ljava/lang/Object;)V
    //   17: putfield hasReplay : Lch/andeo/init7/tvapp/androidutil/NNMediatorLiveData;
    //   20: aload_0
    //   21: new ch/andeo/init7/tvapp/androidutil/NNMediatorLiveData
    //   24: dup
    //   25: ldc ''
    //   27: ldc ''
    //   29: invokespecial <init> : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   32: putfield programName : Lch/andeo/init7/tvapp/androidutil/NNMediatorLiveData;
    //   35: aload_0
    //   36: new ch/andeo/init7/tvapp/androidutil/NNMediatorLiveData
    //   39: dup
    //   40: ldc ''
    //   42: ldc ''
    //   44: invokespecial <init> : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   47: putfield channelName : Lch/andeo/init7/tvapp/androidutil/NNMediatorLiveData;
    //   50: aload_0
    //   51: new ch/andeo/init7/tvapp/androidutil/NNMediatorLiveData
    //   54: dup
    //   55: ldc ''
    //   57: ldc ''
    //   59: invokespecial <init> : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   62: putfield programDesc : Lch/andeo/init7/tvapp/androidutil/NNMediatorLiveData;
    //   65: aload_0
    //   66: new ch/andeo/init7/tvapp/androidutil/NNMediatorLiveData
    //   69: dup
    //   70: ldc ''
    //   72: ldc ''
    //   74: invokespecial <init> : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   77: putfield programDate : Lch/andeo/init7/tvapp/androidutil/NNMediatorLiveData;
    //   80: aload_0
    //   81: new ch/andeo/init7/tvapp/androidutil/NNMediatorLiveData
    //   84: dup
    //   85: ldc ''
    //   87: ldc ''
    //   89: invokespecial <init> : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   92: putfield programSubtitle : Lch/andeo/init7/tvapp/androidutil/NNMediatorLiveData;
    //   95: aload_0
    //   96: new ch/andeo/init7/tvapp/androidutil/NNMediatorLiveData
    //   99: dup
    //   100: ldc ''
    //   102: ldc ''
    //   104: invokespecial <init> : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   107: putfield programTime : Lch/andeo/init7/tvapp/androidutil/NNMediatorLiveData;
    //   110: aload_0
    //   111: invokestatic newSingleThreadExecutor : ()Ljava/util/concurrent/ExecutorService;
    //   114: putfield service : Ljava/util/concurrent/ExecutorService;
    //   117: aload_0
    //   118: aload_0
    //   119: invokevirtual getApplication : ()Landroid/app/Application;
    //   122: checkcast ch/andeo/init7/tvapp/App
    //   125: putfield app : Lch/andeo/init7/tvapp/App;
    //   128: aload_0
    //   129: getfield app : Lch/andeo/init7/tvapp/App;
    //   132: invokevirtual getMediaState : ()Lch/andeo/init7/tvapp/viewmodels/MediaState;
    //   135: astore_1
    //   136: aload_0
    //   137: new ch/andeo/init7/tvapp/androidutil/NNMediatorLiveData
    //   140: dup
    //   141: invokestatic emptyEPG : ()Lch/andeo/init7/core/model/EPGInfo;
    //   144: invokestatic emptyEPG : ()Lch/andeo/init7/core/model/EPGInfo;
    //   147: invokespecial <init> : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   150: putfield displayEPG : Lch/andeo/init7/tvapp/androidutil/NNMediatorLiveData;
    //   153: aload_0
    //   154: getfield displayEPG : Lch/andeo/init7/tvapp/androidutil/NNMediatorLiveData;
    //   157: aload_1
    //   158: invokevirtual getCurrentEPG : ()Landroidx/lifecycle/LiveData;
    //   161: new ch/andeo/init7/tvapp/viewmodels/-$$Lambda$EPGSelectorViewModel$Q8G2yKzD2TYU7jyNa-aOHTiG07U
    //   164: dup
    //   165: aload_0
    //   166: invokespecial <init> : (Lch/andeo/init7/tvapp/viewmodels/EPGSelectorViewModel;)V
    //   169: invokevirtual addSource : (Landroidx/lifecycle/LiveData;Landroidx/lifecycle/Observer;)V
    //   172: aload_0
    //   173: getfield programName : Lch/andeo/init7/tvapp/androidutil/NNMediatorLiveData;
    //   176: aload_0
    //   177: getfield displayEPG : Lch/andeo/init7/tvapp/androidutil/NNMediatorLiveData;
    //   180: new ch/andeo/init7/tvapp/viewmodels/-$$Lambda$EPGSelectorViewModel$fD0Fz80scLHyiC21P-S4tWXCHQo
    //   183: dup
    //   184: aload_0
    //   185: invokespecial <init> : (Lch/andeo/init7/tvapp/viewmodels/EPGSelectorViewModel;)V
    //   188: invokevirtual addSource : (Landroidx/lifecycle/LiveData;Landroidx/lifecycle/Observer;)V
    //   191: aload_0
    //   192: getfield programDesc : Lch/andeo/init7/tvapp/androidutil/NNMediatorLiveData;
    //   195: aload_0
    //   196: getfield displayEPG : Lch/andeo/init7/tvapp/androidutil/NNMediatorLiveData;
    //   199: new ch/andeo/init7/tvapp/viewmodels/-$$Lambda$EPGSelectorViewModel$mlm1Pw4idB1Uh-PChAgKZnGPeOQ
    //   202: dup
    //   203: aload_0
    //   204: invokespecial <init> : (Lch/andeo/init7/tvapp/viewmodels/EPGSelectorViewModel;)V
    //   207: invokevirtual addSource : (Landroidx/lifecycle/LiveData;Landroidx/lifecycle/Observer;)V
    //   210: aload_0
    //   211: getfield programDate : Lch/andeo/init7/tvapp/androidutil/NNMediatorLiveData;
    //   214: aload_0
    //   215: getfield displayEPG : Lch/andeo/init7/tvapp/androidutil/NNMediatorLiveData;
    //   218: new ch/andeo/init7/tvapp/viewmodels/-$$Lambda$EPGSelectorViewModel$I4yhsHpCXIZzg4CqQA9_OShqxYs
    //   221: dup
    //   222: aload_0
    //   223: invokespecial <init> : (Lch/andeo/init7/tvapp/viewmodels/EPGSelectorViewModel;)V
    //   226: invokevirtual addSource : (Landroidx/lifecycle/LiveData;Landroidx/lifecycle/Observer;)V
    //   229: aload_0
    //   230: getfield programSubtitle : Lch/andeo/init7/tvapp/androidutil/NNMediatorLiveData;
    //   233: aload_0
    //   234: getfield displayEPG : Lch/andeo/init7/tvapp/androidutil/NNMediatorLiveData;
    //   237: new ch/andeo/init7/tvapp/viewmodels/-$$Lambda$EPGSelectorViewModel$1-tD_qsVpMU_u3aF6qS3nMewGNw
    //   240: dup
    //   241: aload_0
    //   242: invokespecial <init> : (Lch/andeo/init7/tvapp/viewmodels/EPGSelectorViewModel;)V
    //   245: invokevirtual addSource : (Landroidx/lifecycle/LiveData;Landroidx/lifecycle/Observer;)V
    //   248: aload_0
    //   249: getfield programTime : Lch/andeo/init7/tvapp/androidutil/NNMediatorLiveData;
    //   252: aload_0
    //   253: getfield displayEPG : Lch/andeo/init7/tvapp/androidutil/NNMediatorLiveData;
    //   256: new ch/andeo/init7/tvapp/viewmodels/-$$Lambda$EPGSelectorViewModel$0iLEnzoQ1V_nwD_4pszQxJNKS5g
    //   259: dup
    //   260: aload_0
    //   261: invokespecial <init> : (Lch/andeo/init7/tvapp/viewmodels/EPGSelectorViewModel;)V
    //   264: invokevirtual addSource : (Landroidx/lifecycle/LiveData;Landroidx/lifecycle/Observer;)V
    //   267: aload_0
    //   268: getfield channelName : Lch/andeo/init7/tvapp/androidutil/NNMediatorLiveData;
    //   271: aload_1
    //   272: invokevirtual getCurrentChannel : ()Landroidx/lifecycle/LiveData;
    //   275: new ch/andeo/init7/tvapp/viewmodels/-$$Lambda$EPGSelectorViewModel$666DUossrjrAr2tf6FrGei2B6_c
    //   278: dup
    //   279: aload_0
    //   280: invokespecial <init> : (Lch/andeo/init7/tvapp/viewmodels/EPGSelectorViewModel;)V
    //   283: invokevirtual addSource : (Landroidx/lifecycle/LiveData;Landroidx/lifecycle/Observer;)V
    //   286: aload_0
    //   287: getfield hasReplay : Lch/andeo/init7/tvapp/androidutil/NNMediatorLiveData;
    //   290: aload_0
    //   291: getfield displayEPG : Lch/andeo/init7/tvapp/androidutil/NNMediatorLiveData;
    //   294: new ch/andeo/init7/tvapp/viewmodels/-$$Lambda$EPGSelectorViewModel$4hYE8-kTaKWds9-_5jsb5ZQNHaY
    //   297: dup
    //   298: aload_0
    //   299: aload_1
    //   300: invokespecial <init> : (Lch/andeo/init7/tvapp/viewmodels/EPGSelectorViewModel;Lch/andeo/init7/tvapp/viewmodels/MediaState;)V
    //   303: invokevirtual addSource : (Landroidx/lifecycle/LiveData;Landroidx/lifecycle/Observer;)V
    //   306: return }
  
  public NNMediatorLiveData<String> getChannelName() { return this.channelName; }
  
  public NNMediatorLiveData<EPGInfo> getDisplayEPG() { return this.displayEPG; }
  
  public NNMediatorLiveData<Boolean> getHasReplay() { return this.hasReplay; }
  
  public NNMediatorLiveData<String> getProgramDate() { return this.programDate; }
  
  public NNMediatorLiveData<String> getProgramDesc() { return this.programDesc; }
  
  public NNMediatorLiveData<String> getProgramName() { return this.programName; }
  
  public NNMediatorLiveData<String> getProgramSubtitle() { return this.programSubtitle; }
  
  public NNMediatorLiveData<String> getProgramTime() { return this.programTime; }
  
  public void nextEPG() { // Byte code:
    //   0: aload_0
    //   1: getfield service : Ljava/util/concurrent/ExecutorService;
    //   4: new ch/andeo/init7/tvapp/viewmodels/-$$Lambda$EPGSelectorViewModel$G9a_l_tuvNpcNK5P25XHbT1tJmc
    //   7: dup
    //   8: aload_0
    //   9: invokespecial <init> : (Lch/andeo/init7/tvapp/viewmodels/EPGSelectorViewModel;)V
    //   12: invokeinterface submit : (Ljava/lang/Runnable;)Ljava/util/concurrent/Future;
    //   17: pop
    //   18: return }
  
  public void prevEPG() { // Byte code:
    //   0: aload_0
    //   1: getfield service : Ljava/util/concurrent/ExecutorService;
    //   4: new ch/andeo/init7/tvapp/viewmodels/-$$Lambda$EPGSelectorViewModel$50sN2q6UooAJT9uOinPT3LjUD9k
    //   7: dup
    //   8: aload_0
    //   9: invokespecial <init> : (Lch/andeo/init7/tvapp/viewmodels/EPGSelectorViewModel;)V
    //   12: invokeinterface submit : (Ljava/lang/Runnable;)Ljava/util/concurrent/Future;
    //   17: pop
    //   18: return }
}
