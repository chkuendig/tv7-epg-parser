package ch.andeo.init7.tvapp.viewmodels;

import android.app.Application;
import android.os.Bundle;
import android.util.Log;
import android.util.LruCache;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import ch.andeo.init7.core.dao.AllowedStore;
import ch.andeo.init7.core.dao.EPGDao;
import ch.andeo.init7.core.dao.TvChannelDao;
import ch.andeo.init7.core.model.EPGInfo;
import ch.andeo.init7.core.model.TvChannel;
import ch.andeo.init7.core.util.NamedThreadFactory;
import ch.andeo.init7.core.util.Util;
import ch.andeo.init7.tvapp.App;
import ch.andeo.init7.tvapp.IApp;
import ch.andeo.init7.tvapp.androidutil.NNMutableLiveData;
import ch.andeo.init7.tvapp.exoplayerutil.MediaSourceFactory;
import com.google.android.exoplayer2.source.MediaSource;
import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java9.util.concurrent.CompletableFuture;
import org.matomo.sdk.extra.TrackHelper;

public class MediaState implements AllowedStore {
  private static final String BANNER_VIDEO = "asset:///splashVideo.mp4";
  
  private static final String TAG = "MediaState";
  
  private MutableLiveData<Boolean> allowed;
  
  private LruCache<String, TvChannel> channelCache = new LruCache(20);
  
  private NNMutableLiveData<TvChannel> currentChannel;
  
  private NNMutableLiveData<EPGInfo> currentEPG;
  
  private NNMutableLiveData<Long> currentPosition;
  
  private EPGDao epgDao;
  
  private final Set<MediaStateEventListener> eventListeners = new HashSet();
  
  private final ExecutorService executor;
  
  private MediaStateInstanceState instanceState;
  
  private NNMutableLiveData<Boolean> isLivePlayback;
  
  private NNMutableLiveData<Boolean> isPaused;
  
  private final LiveActions live = new LiveActions(this, null);
  
  private Queue<MediaSource> mediaSources;
  
  private final MulticastActions multicast = new MulticastActions(this, null);
  
  private final LiveData<Boolean> multicastEnabled;
  
  private NNMutableLiveData<PlaybackMode> playbackMode;
  
  private final ReplayActions replay = new ReplayActions(this, null);
  
  private NNMutableLiveData<Boolean> seekAvailable;
  
  private NNMutableLiveData<Long> seekRequest = new NNMutableLiveData(Long.valueOf(-1L));
  
  private NNMutableLiveData<Boolean> splashVideoDone;
  
  private TvChannelDao tvChannelDao;
  
  private final ViewModelStore viewModelStore = new ViewModelStore();
  
  public MediaState(IApp paramIApp) {
    Boolean bool = Boolean.valueOf(false);
    this.seekAvailable = new NNMutableLiveData(bool);
    this.isLivePlayback = new NNMutableLiveData(Boolean.valueOf(true));
    this.isPaused = new NNMutableLiveData(bool);
    this.playbackMode = new NNMutableLiveData(PlaybackMode.REPLAY);
    this.allowed = new MutableLiveData();
    this.splashVideoDone = new NNMutableLiveData(bool);
    Log.e("MediaState", "Construct!");
    this.epgDao = paramIApp.getDb().epgDao();
    this.tvChannelDao = paramIApp.getDb().tvChannelDao();
    this.executor = Executors.newSingleThreadExecutor(new NamedThreadFactory("MediaState"));
    this.currentChannel = new NNMutableLiveData(TvChannel.empty());
    this.currentEPG = new NNMutableLiveData(EPGInfo.emptyEPG());
    this.currentPosition = new NNMutableLiveData(Long.valueOf(0L));
    this.mediaSources = new ArrayDeque();
    this.multicastEnabled = ((PreferenceViewModel)(new ViewModelProvider(this.viewModelStore, ViewModelProvider.AndroidViewModelFactory.getInstance((Application)paramIApp))).get(PreferenceViewModel.class)).getMulticastEnabled();
  }
  
  private ActionHandler getActionHandlerFor(TvChannel paramTvChannel) {
    if (paramTvChannel.hasMulticast() && Boolean.TRUE.equals(this.multicastEnabled.getValue()))
      return this.multicast; 
    if (paramTvChannel.hasReplay) {
      Log.v("MediaState", "handler: replay");
      return this.replay;
    } 
    Log.v("MediaState", "handler: live");
    return this.live;
  }
  
  private TvChannel getChannelByUuid(String paramString) {
    TvChannel tvChannel2 = (TvChannel)this.channelCache.get(paramString);
    TvChannel tvChannel1 = tvChannel2;
    if (tvChannel2 == null) {
      tvChannel1 = this.tvChannelDao.getChannel(paramString);
      this.channelCache.put(paramString, tvChannel1);
    } 
    return tvChannel1;
  }
  
  private Future<Void> selectChannel(Future<TvChannel> paramFuture) { // Byte code:
    //   0: aload_0
    //   1: getfield executor : Ljava/util/concurrent/ExecutorService;
    //   4: new ch/andeo/init7/tvapp/viewmodels/-$$Lambda$MediaState$z88jfKOZVedo7Sji4jcRr5tuPBc
    //   7: dup
    //   8: aload_0
    //   9: aload_1
    //   10: invokespecial <init> : (Lch/andeo/init7/tvapp/viewmodels/MediaState;Ljava/util/concurrent/Future;)V
    //   13: invokeinterface submit : (Ljava/util/concurrent/Callable;)Ljava/util/concurrent/Future;
    //   18: areturn }
  
  private boolean shouldClearQueue() { return ((Boolean)this.splashVideoDone.getValue()).booleanValue(); }
  
  public void addEventListener(MediaStateEventListener paramMediaStateEventListener) { this.eventListeners.add(paramMediaStateEventListener); }
  
  public MutableLiveData<Boolean> getAllowed() { return this.allowed; }
  
  public LiveData<TvChannel> getCurrentChannel() { return this.currentChannel; }
  
  public LiveData<EPGInfo> getCurrentEPG() { return this.currentEPG; }
  
  public NNMutableLiveData<Long> getCurrentPosition() { return this.currentPosition; }
  
  public LiveData<Boolean> getIsLivePlayback() { return this.isLivePlayback; }
  
  public NNMutableLiveData<Boolean> getIsPaused() { return this.isPaused; }
  
  public Queue<MediaSource> getMediaSources() { return this.mediaSources; }
  
  public LiveData<PlaybackMode> getPlaybackMode() { return this.playbackMode; }
  
  public LiveData<Boolean> getSeekAvailable() { return this.seekAvailable; }
  
  public NNMutableLiveData<Long> getSeekRequest() { return this.seekRequest; }
  
  public NNMutableLiveData<Boolean> getSplashVideoDone() { return this.splashVideoDone; }
  
  public void initSplashScreen() {
    Log.e("MediaState", "initSplashScreen");
    if (this.instanceState != null) {
      returnToReplay();
      return;
    } 
    MediaSource mediaSource = MediaSourceFactory.createMediaSource("asset:///splashVideo.mp4", new MediaSourceTag("asset:///splashVideo.mp4", TvChannel.empty(), EPGInfo.emptyEPG()));
    this.mediaSources.clear();
    this.mediaSources.add(mediaSource);
    Iterator iterator = this.eventListeners.iterator();
    while (iterator.hasNext())
      ((MediaStateEventListener)iterator.next()).onMediaSourcesChanged(); 
  }
  
  public void notifyEnded() {
    if (!((Boolean)this.splashVideoDone.getValue()).booleanValue()) {
      Util.setSafe(this.splashVideoDone, Boolean.valueOf(true));
      return;
    } 
    Log.e("MediaState", "Playback has ended unexpectedly!");
  }
  
  public void onDestroy() { this.viewModelStore.clear(); }
  
  public void removeEventListener(MediaStateEventListener paramMediaStateEventListener) { this.eventListeners.remove(paramMediaStateEventListener); }
  
  public Future<Void> requestNextMediaSource(MediaSourceTag paramMediaSourceTag) { // Byte code:
    //   0: ldc 'MediaState'
    //   2: ldc_w 'requestNextMediaSource'
    //   5: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   8: pop
    //   9: aload_0
    //   10: getfield executor : Ljava/util/concurrent/ExecutorService;
    //   13: new ch/andeo/init7/tvapp/viewmodels/-$$Lambda$MediaState$fpUagatVQddFwByGcM3U50WJ9lo
    //   16: dup
    //   17: aload_0
    //   18: aload_1
    //   19: invokespecial <init> : (Lch/andeo/init7/tvapp/viewmodels/MediaState;Lch/andeo/init7/tvapp/viewmodels/MediaState$MediaSourceTag;)V
    //   22: invokeinterface submit : (Ljava/util/concurrent/Callable;)Ljava/util/concurrent/Future;
    //   27: areturn }
  
  public void reset() {
    Util.setSafe(this.splashVideoDone, Boolean.valueOf(false));
    this.mediaSources.clear();
  }
  
  public void restore(Bundle paramBundle) {
    Log.e("MediaState", "restore");
    this.instanceState = null;
    if (paramBundle != null && paramBundle.containsKey("MediaState"))
      try {
        this.instanceState = (MediaStateInstanceState)paramBundle.getSerializable("MediaState");
        Log.i("MediaState", "Restore successful!");
        return;
      } catch (Exception paramBundle) {
        Log.e("MediaState", "Unable to restore instanceState", paramBundle);
      }  
  }
  
  public Future<Void> returnToReplay() { // Byte code:
    //   0: aload_0
    //   1: getfield executor : Ljava/util/concurrent/ExecutorService;
    //   4: new ch/andeo/init7/tvapp/viewmodels/-$$Lambda$MediaState$eUy8ZqJUTuXxyfaSZVSgRBaQRLU
    //   7: dup
    //   8: aload_0
    //   9: invokespecial <init> : (Lch/andeo/init7/tvapp/viewmodels/MediaState;)V
    //   12: invokeinterface submit : (Ljava/util/concurrent/Callable;)Ljava/util/concurrent/Future;
    //   17: areturn }
  
  public Future<Void> selectChannel(TvChannel paramTvChannel) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("selectChannel(");
    stringBuilder.append(paramTvChannel.name);
    stringBuilder.append(")");
    Log.v("MediaState", stringBuilder.toString());
    return selectChannel(CompletableFuture.completedFuture(paramTvChannel));
  }
  
  public Future<Void> selectChannelIndex(int paramInt) { // Byte code:
    //   0: new java/lang/StringBuilder
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore_2
    //   8: aload_2
    //   9: ldc_w 'selectChannelIndex('
    //   12: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   15: pop
    //   16: aload_2
    //   17: iload_1
    //   18: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   21: pop
    //   22: aload_2
    //   23: ldc_w ')'
    //   26: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   29: pop
    //   30: ldc 'MediaState'
    //   32: aload_2
    //   33: invokevirtual toString : ()Ljava/lang/String;
    //   36: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   39: pop
    //   40: aload_0
    //   41: aload_0
    //   42: getfield executor : Ljava/util/concurrent/ExecutorService;
    //   45: new ch/andeo/init7/tvapp/viewmodels/-$$Lambda$MediaState$BRo7Qgc3NVA8f1KH0hI4BZRl5pY
    //   48: dup
    //   49: aload_0
    //   50: iload_1
    //   51: invokespecial <init> : (Lch/andeo/init7/tvapp/viewmodels/MediaState;I)V
    //   54: invokeinterface submit : (Ljava/util/concurrent/Callable;)Ljava/util/concurrent/Future;
    //   59: invokespecial selectChannel : (Ljava/util/concurrent/Future;)Ljava/util/concurrent/Future;
    //   62: areturn }
  
  public Future<Void> selectChannelOffset(int paramInt) { // Byte code:
    //   0: new java/lang/StringBuilder
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore_2
    //   8: aload_2
    //   9: ldc_w 'selectChannelOffset('
    //   12: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   15: pop
    //   16: aload_2
    //   17: iload_1
    //   18: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   21: pop
    //   22: aload_2
    //   23: ldc_w ')'
    //   26: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   29: pop
    //   30: ldc 'MediaState'
    //   32: aload_2
    //   33: invokevirtual toString : ()Ljava/lang/String;
    //   36: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   39: pop
    //   40: aload_0
    //   41: aload_0
    //   42: getfield executor : Ljava/util/concurrent/ExecutorService;
    //   45: new ch/andeo/init7/tvapp/viewmodels/-$$Lambda$MediaState$TjCiI7TVMujNmh1Q2rwh9z2X3bo
    //   48: dup
    //   49: aload_0
    //   50: iload_1
    //   51: invokespecial <init> : (Lch/andeo/init7/tvapp/viewmodels/MediaState;I)V
    //   54: invokeinterface submit : (Ljava/util/concurrent/Callable;)Ljava/util/concurrent/Future;
    //   59: invokespecial selectChannel : (Ljava/util/concurrent/Future;)Ljava/util/concurrent/Future;
    //   62: areturn }
  
  public Future<Void> selectEPG(EPGInfo paramEPGInfo) { // Byte code:
    //   0: new java/lang/StringBuilder
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore_2
    //   8: aload_2
    //   9: ldc_w 'selectEPG('
    //   12: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   15: pop
    //   16: aload_2
    //   17: aload_1
    //   18: getfield title : Ljava/lang/String;
    //   21: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   24: pop
    //   25: aload_2
    //   26: ldc_w ')'
    //   29: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   32: pop
    //   33: ldc 'MediaState'
    //   35: aload_2
    //   36: invokevirtual toString : ()Ljava/lang/String;
    //   39: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   42: pop
    //   43: aload_0
    //   44: getfield executor : Ljava/util/concurrent/ExecutorService;
    //   47: new ch/andeo/init7/tvapp/viewmodels/-$$Lambda$MediaState$16jWZyMQVJC6QQ3OEbVpp_0pkdU
    //   50: dup
    //   51: aload_0
    //   52: aload_1
    //   53: invokespecial <init> : (Lch/andeo/init7/tvapp/viewmodels/MediaState;Lch/andeo/init7/core/model/EPGInfo;)V
    //   56: invokeinterface submit : (Ljava/util/concurrent/Callable;)Ljava/util/concurrent/Future;
    //   61: areturn }
  
  public void setIsAllowed(Boolean paramBoolean) { Util.setSafe(this.allowed, paramBoolean); }
  
  public void startOperation() { // Byte code:
    //   0: aload_0
    //   1: getfield executor : Ljava/util/concurrent/ExecutorService;
    //   4: new ch/andeo/init7/tvapp/viewmodels/-$$Lambda$MediaState$qngOPrOvySgSH_9nFCAIo9PATO0
    //   7: dup
    //   8: aload_0
    //   9: invokespecial <init> : (Lch/andeo/init7/tvapp/viewmodels/MediaState;)V
    //   12: invokeinterface submit : (Ljava/util/concurrent/Callable;)Ljava/util/concurrent/Future;
    //   17: pop
    //   18: return }
  
  public void store(Bundle paramBundle) {
    MediaStateInstanceState mediaStateInstanceState;
    Log.e("MediaState", "store");
    if (((EPGInfo)this.currentEPG.getValue()).isEmpty() || ((EPGInfo)this.currentEPG.getValue()).isLive(App.CLOCK.millis())) {
      mediaStateInstanceState = new MediaStateInstanceState(((TvChannel)this.currentChannel.getValue()).uuid, false);
    } else {
      mediaStateInstanceState = new MediaStateInstanceState(((EPGInfo)this.currentEPG.getValue()).uuid, true);
    } 
    paramBundle.putSerializable("MediaState", mediaStateInstanceState);
  }
}
