package ch.andeo.init7.tvapp.viewmodels;

import android.app.Application;
import android.view.View;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MediatorLiveData;
import ch.andeo.init7.core.model.EPGInfo;
import ch.andeo.init7.core.model.TvChannel;
import ch.andeo.init7.tvapp.App;
import ch.andeo.init7.tvapp.androidutil.NNMediatorLiveData;
import java.util.Date;
import java.util.Objects;

public class TVPlayerControlsViewModel extends AndroidViewModel {
  private static final String TAG = "TVPlayerControlsViewMod";
  
  private MediatorLiveData<Integer> bufferedPlaybackPosition;
  
  private MediatorLiveData<String> channelLogoUrl;
  
  private MediatorLiveData<String> channelName;
  
  private MediatorLiveData<EPGInfo> currentEPGInfo;
  
  private MediatorLiveData<Integer> currentPlaybackPosition;
  
  private MediatorLiveData<String> currentSeekTime;
  
  private MediatorLiveData<Integer> epgLength;
  
  private MediatorLiveData<Boolean> isLivePlayback;
  
  private NNMediatorLiveData<Boolean> isPaused;
  
  private MediaState mediaState;
  
  private MediatorLiveData<String> programName;
  
  private MediatorLiveData<String> programStartEndTime;
  
  private MediatorLiveData<Boolean> seekAvailable;
  
  public TVPlayerControlsViewModel(Application paramApplication) { // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokespecial <init> : (Landroid/app/Application;)V
    //   5: aload_0
    //   6: new androidx/lifecycle/MediatorLiveData
    //   9: dup
    //   10: invokespecial <init> : ()V
    //   13: putfield channelName : Landroidx/lifecycle/MediatorLiveData;
    //   16: aload_0
    //   17: new androidx/lifecycle/MediatorLiveData
    //   20: dup
    //   21: invokespecial <init> : ()V
    //   24: putfield channelLogoUrl : Landroidx/lifecycle/MediatorLiveData;
    //   27: aload_0
    //   28: new androidx/lifecycle/MediatorLiveData
    //   31: dup
    //   32: invokespecial <init> : ()V
    //   35: putfield currentEPGInfo : Landroidx/lifecycle/MediatorLiveData;
    //   38: aload_0
    //   39: new androidx/lifecycle/MediatorLiveData
    //   42: dup
    //   43: invokespecial <init> : ()V
    //   46: putfield programName : Landroidx/lifecycle/MediatorLiveData;
    //   49: aload_0
    //   50: new androidx/lifecycle/MediatorLiveData
    //   53: dup
    //   54: invokespecial <init> : ()V
    //   57: putfield programStartEndTime : Landroidx/lifecycle/MediatorLiveData;
    //   60: aload_0
    //   61: new androidx/lifecycle/MediatorLiveData
    //   64: dup
    //   65: invokespecial <init> : ()V
    //   68: putfield currentSeekTime : Landroidx/lifecycle/MediatorLiveData;
    //   71: aload_0
    //   72: new androidx/lifecycle/MediatorLiveData
    //   75: dup
    //   76: invokespecial <init> : ()V
    //   79: putfield seekAvailable : Landroidx/lifecycle/MediatorLiveData;
    //   82: aload_0
    //   83: new androidx/lifecycle/MediatorLiveData
    //   86: dup
    //   87: invokespecial <init> : ()V
    //   90: putfield isLivePlayback : Landroidx/lifecycle/MediatorLiveData;
    //   93: aload_0
    //   94: new ch/andeo/init7/tvapp/androidutil/NNMediatorLiveData
    //   97: dup
    //   98: iconst_0
    //   99: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   102: invokespecial <init> : (Ljava/lang/Object;)V
    //   105: putfield isPaused : Lch/andeo/init7/tvapp/androidutil/NNMediatorLiveData;
    //   108: aload_0
    //   109: new androidx/lifecycle/MediatorLiveData
    //   112: dup
    //   113: invokespecial <init> : ()V
    //   116: putfield epgLength : Landroidx/lifecycle/MediatorLiveData;
    //   119: aload_0
    //   120: new androidx/lifecycle/MediatorLiveData
    //   123: dup
    //   124: invokespecial <init> : ()V
    //   127: putfield currentPlaybackPosition : Landroidx/lifecycle/MediatorLiveData;
    //   130: aload_0
    //   131: new androidx/lifecycle/MediatorLiveData
    //   134: dup
    //   135: invokespecial <init> : ()V
    //   138: putfield bufferedPlaybackPosition : Landroidx/lifecycle/MediatorLiveData;
    //   141: aload_0
    //   142: lconst_0
    //   143: putfield lastSeek : J
    //   146: aload_0
    //   147: invokevirtual getApplication : ()Landroid/app/Application;
    //   150: checkcast ch/andeo/init7/tvapp/App
    //   153: invokevirtual getMediaState : ()Lch/andeo/init7/tvapp/viewmodels/MediaState;
    //   156: astore_1
    //   157: aload_0
    //   158: getfield channelName : Landroidx/lifecycle/MediatorLiveData;
    //   161: aload_1
    //   162: invokevirtual getCurrentChannel : ()Landroidx/lifecycle/LiveData;
    //   165: new ch/andeo/init7/tvapp/viewmodels/-$$Lambda$TVPlayerControlsViewModel$LLXKyQSkHnn2pqQGIRaTTO3s-dU
    //   168: dup
    //   169: aload_0
    //   170: invokespecial <init> : (Lch/andeo/init7/tvapp/viewmodels/TVPlayerControlsViewModel;)V
    //   173: invokevirtual addSource : (Landroidx/lifecycle/LiveData;Landroidx/lifecycle/Observer;)V
    //   176: aload_0
    //   177: getfield channelLogoUrl : Landroidx/lifecycle/MediatorLiveData;
    //   180: aload_1
    //   181: invokevirtual getCurrentChannel : ()Landroidx/lifecycle/LiveData;
    //   184: new ch/andeo/init7/tvapp/viewmodels/-$$Lambda$TVPlayerControlsViewModel$LjlczqKLyqcNc0VyRR9uhba_Wt4
    //   187: dup
    //   188: aload_0
    //   189: invokespecial <init> : (Lch/andeo/init7/tvapp/viewmodels/TVPlayerControlsViewModel;)V
    //   192: invokevirtual addSource : (Landroidx/lifecycle/LiveData;Landroidx/lifecycle/Observer;)V
    //   195: aload_0
    //   196: getfield currentEPGInfo : Landroidx/lifecycle/MediatorLiveData;
    //   199: aload_1
    //   200: invokevirtual getCurrentEPG : ()Landroidx/lifecycle/LiveData;
    //   203: new ch/andeo/init7/tvapp/viewmodels/-$$Lambda$TVPlayerControlsViewModel$5UboqK17tYLDWMa6XWUDRgVW5n4
    //   206: dup
    //   207: aload_0
    //   208: invokespecial <init> : (Lch/andeo/init7/tvapp/viewmodels/TVPlayerControlsViewModel;)V
    //   211: invokevirtual addSource : (Landroidx/lifecycle/LiveData;Landroidx/lifecycle/Observer;)V
    //   214: aload_0
    //   215: getfield programName : Landroidx/lifecycle/MediatorLiveData;
    //   218: aload_0
    //   219: getfield currentEPGInfo : Landroidx/lifecycle/MediatorLiveData;
    //   222: new ch/andeo/init7/tvapp/viewmodels/-$$Lambda$TVPlayerControlsViewModel$jV-fC80RWkAQ8-LRG_fSF3lK4NU
    //   225: dup
    //   226: aload_0
    //   227: invokespecial <init> : (Lch/andeo/init7/tvapp/viewmodels/TVPlayerControlsViewModel;)V
    //   230: invokevirtual addSource : (Landroidx/lifecycle/LiveData;Landroidx/lifecycle/Observer;)V
    //   233: aload_0
    //   234: getfield programStartEndTime : Landroidx/lifecycle/MediatorLiveData;
    //   237: aload_0
    //   238: getfield currentEPGInfo : Landroidx/lifecycle/MediatorLiveData;
    //   241: new ch/andeo/init7/tvapp/viewmodels/-$$Lambda$TVPlayerControlsViewModel$Msyl_Qxg5rag1S-ndNiTTudWaEU
    //   244: dup
    //   245: aload_0
    //   246: invokespecial <init> : (Lch/andeo/init7/tvapp/viewmodels/TVPlayerControlsViewModel;)V
    //   249: invokevirtual addSource : (Landroidx/lifecycle/LiveData;Landroidx/lifecycle/Observer;)V
    //   252: aload_0
    //   253: getfield seekAvailable : Landroidx/lifecycle/MediatorLiveData;
    //   256: aload_1
    //   257: invokevirtual getSeekAvailable : ()Landroidx/lifecycle/LiveData;
    //   260: new ch/andeo/init7/tvapp/viewmodels/-$$Lambda$TVPlayerControlsViewModel$NkfWz4JH4QPJYWM_IhnMLRXBkZs
    //   263: dup
    //   264: aload_0
    //   265: invokespecial <init> : (Lch/andeo/init7/tvapp/viewmodels/TVPlayerControlsViewModel;)V
    //   268: invokevirtual addSource : (Landroidx/lifecycle/LiveData;Landroidx/lifecycle/Observer;)V
    //   271: aload_0
    //   272: getfield isLivePlayback : Landroidx/lifecycle/MediatorLiveData;
    //   275: aload_1
    //   276: invokevirtual getIsLivePlayback : ()Landroidx/lifecycle/LiveData;
    //   279: new ch/andeo/init7/tvapp/viewmodels/-$$Lambda$TVPlayerControlsViewModel$e-zwMVS8NR1msGzjzlccJnECZCA
    //   282: dup
    //   283: aload_0
    //   284: invokespecial <init> : (Lch/andeo/init7/tvapp/viewmodels/TVPlayerControlsViewModel;)V
    //   287: invokevirtual addSource : (Landroidx/lifecycle/LiveData;Landroidx/lifecycle/Observer;)V
    //   290: aload_0
    //   291: getfield epgLength : Landroidx/lifecycle/MediatorLiveData;
    //   294: aload_0
    //   295: getfield currentEPGInfo : Landroidx/lifecycle/MediatorLiveData;
    //   298: new ch/andeo/init7/tvapp/viewmodels/-$$Lambda$TVPlayerControlsViewModel$yBYbWmFg0p-AKZhim5ITWrbv4Z8
    //   301: dup
    //   302: aload_0
    //   303: invokespecial <init> : (Lch/andeo/init7/tvapp/viewmodels/TVPlayerControlsViewModel;)V
    //   306: invokevirtual addSource : (Landroidx/lifecycle/LiveData;Landroidx/lifecycle/Observer;)V
    //   309: aload_0
    //   310: getfield currentPlaybackPosition : Landroidx/lifecycle/MediatorLiveData;
    //   313: aload_1
    //   314: invokevirtual getCurrentPosition : ()Lch/andeo/init7/tvapp/androidutil/NNMutableLiveData;
    //   317: new ch/andeo/init7/tvapp/viewmodels/-$$Lambda$TVPlayerControlsViewModel$kk-N-lm26F4iQS4aROC1KjBnC04
    //   320: dup
    //   321: aload_0
    //   322: aload_1
    //   323: invokespecial <init> : (Lch/andeo/init7/tvapp/viewmodels/TVPlayerControlsViewModel;Lch/andeo/init7/tvapp/viewmodels/MediaState;)V
    //   326: invokevirtual addSource : (Landroidx/lifecycle/LiveData;Landroidx/lifecycle/Observer;)V
    //   329: aload_0
    //   330: getfield currentSeekTime : Landroidx/lifecycle/MediatorLiveData;
    //   333: aload_0
    //   334: getfield currentPlaybackPosition : Landroidx/lifecycle/MediatorLiveData;
    //   337: getstatic ch/andeo/init7/tvapp/viewmodels/-$$Lambda$TVPlayerControlsViewModel$C0hc3YDie1w8x7hHAlgk0EvC9zw.INSTANCE : Lch/andeo/init7/tvapp/viewmodels/-$$Lambda$TVPlayerControlsViewModel$C0hc3YDie1w8x7hHAlgk0EvC9zw;
    //   340: invokevirtual addSource : (Landroidx/lifecycle/LiveData;Landroidx/lifecycle/Observer;)V
    //   343: aload_0
    //   344: getfield bufferedPlaybackPosition : Landroidx/lifecycle/MediatorLiveData;
    //   347: aload_1
    //   348: invokevirtual getCurrentPosition : ()Lch/andeo/init7/tvapp/androidutil/NNMutableLiveData;
    //   351: new ch/andeo/init7/tvapp/viewmodels/-$$Lambda$TVPlayerControlsViewModel$SvDiO7aUJAjVp4PttqrLzNDvZXU
    //   354: dup
    //   355: aload_0
    //   356: aload_1
    //   357: invokespecial <init> : (Lch/andeo/init7/tvapp/viewmodels/TVPlayerControlsViewModel;Lch/andeo/init7/tvapp/viewmodels/MediaState;)V
    //   360: invokevirtual addSource : (Landroidx/lifecycle/LiveData;Landroidx/lifecycle/Observer;)V
    //   363: aload_0
    //   364: getfield isPaused : Lch/andeo/init7/tvapp/androidutil/NNMediatorLiveData;
    //   367: aload_1
    //   368: invokevirtual getIsPaused : ()Lch/andeo/init7/tvapp/androidutil/NNMutableLiveData;
    //   371: new ch/andeo/init7/tvapp/viewmodels/-$$Lambda$TVPlayerControlsViewModel$kdPckuW1SkctqbgU202xBl_CwMo
    //   374: dup
    //   375: aload_0
    //   376: invokespecial <init> : (Lch/andeo/init7/tvapp/viewmodels/TVPlayerControlsViewModel;)V
    //   379: invokevirtual addSource : (Landroidx/lifecycle/LiveData;Landroidx/lifecycle/Observer;)V
    //   382: aload_0
    //   383: aload_1
    //   384: putfield mediaState : Lch/andeo/init7/tvapp/viewmodels/MediaState;
    //   387: return }
  
  public MediatorLiveData<Integer> getBufferedPlaybackPosition() { return this.bufferedPlaybackPosition; }
  
  public LiveData<String> getChannelLogoUrl() { return this.channelLogoUrl; }
  
  public LiveData<String> getChannelName() { return this.channelName; }
  
  public LiveData<EPGInfo> getCurrentEPGInfo() { return this.currentEPGInfo; }
  
  public LiveData<Integer> getCurrentPlaybackPosition() { return this.currentPlaybackPosition; }
  
  public LiveData<String> getCurrentSeekTime() { return this.currentSeekTime; }
  
  public LiveData<Integer> getEpgLength() { return this.epgLength; }
  
  public LiveData<Boolean> getIsLivePlayback() { return this.isLivePlayback; }
  
  public LiveData<Boolean> getIsPaused() { return this.isPaused; }
  
  public LiveData<String> getProgramName() { return this.programName; }
  
  public LiveData<String> getProgramStartEndTime() { return this.programStartEndTime; }
  
  public LiveData<Boolean> getSeekAvailable() { return this.seekAvailable; }
  
  public void onTogglePause() { this.mediaState.getIsPaused().setValue(Boolean.valueOf(((Boolean)this.mediaState.getIsPaused().getValue()).booleanValue() ^ true)); }
  
  public void onUserSeek(int paramInt) {
    Integer integer = (Integer)this.bufferedPlaybackPosition.getValue();
    if (integer == null)
      return; 
    this.lastSeek = System.currentTimeMillis();
    int i = paramInt;
    if (paramInt > integer.intValue()) {
      i = integer.intValue() - 10;
      this.currentPlaybackPosition.setValue(Integer.valueOf(i));
    } 
    this.mediaState.getSeekRequest().setValue(Long.valueOf(i * 1000L));
  }
  
  public void requestLivePlayback(View paramView) { // Byte code:
    //   0: aload_1
    //   1: invokevirtual getContext : ()Landroid/content/Context;
    //   4: ldc_w 2131689503
    //   7: new ch/andeo/init7/tvapp/viewmodels/-$$Lambda$TVPlayerControlsViewModel$kb6FtGCcN52ZihDaotp02ZU0UTA
    //   10: dup
    //   11: aload_0
    //   12: invokespecial <init> : (Lch/andeo/init7/tvapp/viewmodels/TVPlayerControlsViewModel;)V
    //   15: invokestatic confirm : (Landroid/content/Context;ILjava/lang/Runnable;)V
    //   18: return }
}
