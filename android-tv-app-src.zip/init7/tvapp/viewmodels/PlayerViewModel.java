package ch.andeo.init7.tvapp.viewmodels;

public class PlayerViewModel {}
