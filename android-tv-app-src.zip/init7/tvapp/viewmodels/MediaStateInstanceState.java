package ch.andeo.init7.tvapp.viewmodels;

import java.io.Serializable;

public class MediaStateInstanceState implements Serializable {
  public final boolean isEPG;
  
  public final String uuid;
  
  public MediaStateInstanceState(String paramString, boolean paramBoolean) {
    this.uuid = paramString;
    this.isEPG = paramBoolean;
  }
}
