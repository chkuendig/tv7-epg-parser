package ch.andeo.init7.tvapp.viewmodels;

import android.app.Application;
import android.content.SharedPreferences;
import android.util.Log;
import androidx.lifecycle.AndroidViewModel;
import ch.andeo.init7.core.util.Util;
import ch.andeo.init7.tvapp.androidutil.NNMutableLiveData;

public class PreferenceViewModel extends AndroidViewModel implements SharedPreferences.OnSharedPreferenceChangeListener {
  private static final String TAG = "PreferenceViewModel";
  
  private final NNMutableLiveData<Boolean> debugInfoEnabled;
  
  private final NNMutableLiveData<Boolean> multicastEnabled;
  
  private final SharedPreferences prefs;
  
  public PreferenceViewModel(Application paramApplication) {
    super(paramApplication);
    Boolean bool = Boolean.valueOf(false);
    this.multicastEnabled = new NNMutableLiveData(bool);
    this.debugInfoEnabled = new NNMutableLiveData(bool);
    this.prefs = paramApplication.getSharedPreferences("App", 0);
    this.prefs.registerOnSharedPreferenceChangeListener(this);
    updatePrefs(this.prefs);
  }
  
  private void updatePrefs(SharedPreferences paramSharedPreferences) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Multicast State: ");
    stringBuilder.append(paramSharedPreferences.getBoolean("enable_multicast", false));
    Log.i("PreferenceViewModel", stringBuilder.toString());
    Util.update(this.multicastEnabled, Boolean.valueOf(paramSharedPreferences.getBoolean("enable_multicast", false)));
    Util.update(this.debugInfoEnabled, Boolean.valueOf(paramSharedPreferences.getBoolean("enable_debug_info", false)));
  }
  
  public NNMutableLiveData<Boolean> getDebugInfoEnabled() { return this.debugInfoEnabled; }
  
  public NNMutableLiveData<Boolean> getMulticastEnabled() { return this.multicastEnabled; }
  
  protected void onCleared() { this.prefs.unregisterOnSharedPreferenceChangeListener(this); }
  
  public void onSharedPreferenceChanged(SharedPreferences paramSharedPreferences, String paramString) { updatePrefs(paramSharedPreferences); }
}
