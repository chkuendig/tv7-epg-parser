package ch.andeo.init7.tvapp;

import android.app.Application;
import android.content.Context;
import android.util.Log;
import ch.andeo.init7.core.TvDB;
import ch.andeo.init7.core.TvDbFactory;
import ch.andeo.init7.core.api.TvApi;
import ch.andeo.init7.core.api.TvApiFactory;
import ch.andeo.init7.core.model.EPGInfo;
import ch.andeo.init7.core.sync.AllowedSync;
import ch.andeo.init7.core.sync.ChannelListSync;
import ch.andeo.init7.core.sync.EPGSync;
import ch.andeo.init7.core.sync.EPGSyncTask;
import ch.andeo.init7.core.util.NamedThreadFactory;
import ch.andeo.init7.core.util.Util;
import ch.andeo.init7.tvapp.viewmodels.MediaState;
import com.google.android.exoplayer2.upstream.DataSource;
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory;
import com.google.android.exoplayer2.upstream.DefaultHttpDataSourceFactory;
import com.google.android.exoplayer2.upstream.HttpDataSource;
import com.jakewharton.threetenabp.AndroidThreeTen;
import io.github.inflationx.calligraphy3.CalligraphyConfig;
import io.github.inflationx.calligraphy3.CalligraphyInterceptor;
import io.github.inflationx.viewpump.ViewPump;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.matomo.sdk.Tracker;
import org.threeten.bp.Clock;

public class App extends Application implements IApp {
  public static Clock CLOCK;
  
  private static final int EXOPLAYER_TIMEOUT = 15000;
  
  public static DateFormat FORMAT_DATE = new SimpleDateFormat("EEEE d. MMMM yyyy", Locale.GERMANY);
  
  public static DateFormat FORMAT_TIME = new SimpleDateFormat("HH:mm", Locale.GERMANY);
  
  public static DateFormat FORMAT_TIME_P = new SimpleDateFormat("HH:mm:ss", Locale.GERMANY);
  
  protected static App INSTANCE;
  
  public static final String PREFS_NAME = "App";
  
  private static final String TAG = "App";
  
  private TvDB db;
  
  private DataSource.Factory factory;
  
  private MediaState mediaState;
  
  protected boolean skipInit = false;
  
  private Tracker tracker;
  
  protected String userAgent;
  
  public static App getInstance() { return INSTANCE; }
  
  DataSource.Factory buildDataSourceFactory() { return new DefaultDataSourceFactory(this, buildHttpDataSourceFactory()); }
  
  HttpDataSource.Factory buildHttpDataSourceFactory() { return new DefaultHttpDataSourceFactory(this.userAgent, 15000, 15000, false); }
  
  public Context getApplicationContext() { return super.getApplicationContext(); }
  
  public DataSource.Factory getDataSourceFactory() {
    if (this.factory == null)
      this.factory = buildDataSourceFactory(); 
    return this.factory;
  }
  
  public TvDB getDb() { return this.db; }
  
  public String getLanguageCode() {
    HashMap hashMap = new HashMap();
    hashMap.put(Locale.forLanguageTag("de").getLanguage(), "de");
    hashMap.put(Locale.forLanguageTag("fr").getLanguage(), "fr");
    hashMap.put(Locale.forLanguageTag("it").getLanguage(), "it");
    String str = Locale.getDefault().getLanguage();
    return hashMap.containsKey(str) ? (String)hashMap.get(str) : "";
  }
  
  public MediaState getMediaState() { return this.mediaState; }
  
  public Tracker getTracker() { // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield tracker : Lorg/matomo/sdk/Tracker;
    //   6: ifnonnull -> 27
    //   9: aload_0
    //   10: ldc 'https://matomo.init7.net/piwik/matomo.php'
    //   12: bipush #6
    //   14: invokestatic createDefault : (Ljava/lang/String;I)Lorg/matomo/sdk/TrackerBuilder;
    //   17: aload_0
    //   18: invokestatic getInstance : (Landroid/content/Context;)Lorg/matomo/sdk/Matomo;
    //   21: invokevirtual build : (Lorg/matomo/sdk/Matomo;)Lorg/matomo/sdk/Tracker;
    //   24: putfield tracker : Lorg/matomo/sdk/Tracker;
    //   27: aload_0
    //   28: getfield tracker : Lorg/matomo/sdk/Tracker;
    //   31: astore_1
    //   32: aload_0
    //   33: monitorexit
    //   34: aload_1
    //   35: areturn
    //   36: astore_1
    //   37: aload_0
    //   38: monitorexit
    //   39: aload_1
    //   40: athrow
    // Exception table:
    //   from	to	target	type
    //   2	27	36	finally
    //   27	32	36	finally }
  
  public void loadAllowed() { (new AllowedSync(TvApiFactory.provideTvApi(this, this.userAgent), this.mediaState)).execute(new Void[0]); }
  
  public void onCreate() {
    super.onCreate();
    if (this.skipInit)
      return; 
    AndroidThreeTen.init(this);
    CLOCK = Clock.systemDefaultZone();
    EPGInfo.initEmpty(this);
    this.userAgent = Util.getUserAgent(this, getString(2131689499), "ExoPlayerLib/2.10.2");
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Starting with UserAgent: ");
    stringBuilder.append(this.userAgent);
    Log.i("App", stringBuilder.toString());
    INSTANCE = this;
    ViewPump.init(ViewPump.builder().addInterceptor(new CalligraphyInterceptor((new CalligraphyConfig.Builder()).setDefaultFontPath("fonts/patron_regular.otf").setFontAttrId(2130903265).build())).build());
    TvApi tvApi = TvApiFactory.provideTvApi(this, this.userAgent);
    this.db = TvDbFactory.createDB(this);
    if (this.mediaState == null)
      this.mediaState = new MediaState(this); 
    loadAllowed();
    ExecutorService executorService = Executors.newSingleThreadExecutor(new NamedThreadFactory("App-AsyncTask"));
    (new ChannelListSync(tvApi, this.db.tvChannelDao())).executeOnExecutor(executorService, new Void[0]);
    (new EPGSyncTask(this.db.tvChannelDao(), new EPGSync(tvApi, this.db.epgDao(), this.db.tvChannelDao()))).executeOnExecutor(executorService, new Void[0]);
  }
  
  public void onTerminate() {
    this.mediaState.onDestroy();
    super.onTerminate();
  }
}
