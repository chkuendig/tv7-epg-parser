package ch.andeo.init7.tvapp;

import android.util.SparseIntArray;
import android.view.View;
import androidx.databinding.DataBinderMapper;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import androidx.databinding.library.baseAdapters.DataBinderMapperImpl;
import ch.andeo.init7.tvapp.databinding.FragmentTransportControlsBindingImpl;
import ch.andeo.init7.tvapp.databinding.FragmentTvplayerEpgBindingImpl;
import ch.andeo.init7.tvapp.databinding.LayoutChannelListitemBindingImpl;
import ch.andeo.init7.tvapp.databinding.LayoutProgramListitemBindingImpl;
import java.util.ArrayList;
import java.util.List;

public class DataBinderMapperImpl extends DataBinderMapper {
  private static final SparseIntArray INTERNAL_LAYOUT_ID_LOOKUP = new SparseIntArray(4);
  
  private static final int LAYOUT_FRAGMENTTRANSPORTCONTROLS = 1;
  
  private static final int LAYOUT_FRAGMENTTVPLAYEREPG = 2;
  
  private static final int LAYOUT_LAYOUTCHANNELLISTITEM = 3;
  
  private static final int LAYOUT_LAYOUTPROGRAMLISTITEM = 4;
  
  static  {
    INTERNAL_LAYOUT_ID_LOOKUP.put(2131492904, 1);
    INTERNAL_LAYOUT_ID_LOOKUP.put(2131492906, 2);
    INTERNAL_LAYOUT_ID_LOOKUP.put(2131492908, 3);
    INTERNAL_LAYOUT_ID_LOOKUP.put(2131492910, 4);
  }
  
  public List<DataBinderMapper> collectDependencies() {
    ArrayList arrayList = new ArrayList(1);
    arrayList.add(new DataBinderMapperImpl());
    return arrayList;
  }
  
  public String convertBrIdToString(int paramInt) { return (String)InnerBrLookup.sKeys.get(paramInt); }
  
  public ViewDataBinding getDataBinder(DataBindingComponent paramDataBindingComponent, View paramView, int paramInt) {
    paramInt = INTERNAL_LAYOUT_ID_LOOKUP.get(paramInt);
    if (paramInt > 0) {
      Object object = paramView.getTag();
      if (object != null) {
        StringBuilder stringBuilder;
        if (paramInt != 1) {
          if (paramInt != 2) {
            if (paramInt != 3) {
              if (paramInt == 4) {
                if ("layout/layout_program_listitem_0".equals(object))
                  return new LayoutProgramListitemBindingImpl(paramDataBindingComponent, paramView); 
                stringBuilder = new StringBuilder();
                stringBuilder.append("The tag for layout_program_listitem is invalid. Received: ");
                stringBuilder.append(object);
                throw new IllegalArgumentException(stringBuilder.toString());
              } 
            } else {
              if ("layout/layout_channel_listitem_0".equals(object))
                return new LayoutChannelListitemBindingImpl(stringBuilder, paramView); 
              stringBuilder = new StringBuilder();
              stringBuilder.append("The tag for layout_channel_listitem is invalid. Received: ");
              stringBuilder.append(object);
              throw new IllegalArgumentException(stringBuilder.toString());
            } 
          } else {
            if ("layout/fragment_tvplayer_epg_0".equals(object))
              return new FragmentTvplayerEpgBindingImpl(stringBuilder, paramView); 
            stringBuilder = new StringBuilder();
            stringBuilder.append("The tag for fragment_tvplayer_epg is invalid. Received: ");
            stringBuilder.append(object);
            throw new IllegalArgumentException(stringBuilder.toString());
          } 
        } else {
          if ("layout/fragment_transport_controls_0".equals(object))
            return new FragmentTransportControlsBindingImpl(stringBuilder, paramView); 
          stringBuilder = new StringBuilder();
          stringBuilder.append("The tag for fragment_transport_controls is invalid. Received: ");
          stringBuilder.append(object);
          throw new IllegalArgumentException(stringBuilder.toString());
        } 
      } else {
        throw new RuntimeException("view must have a tag");
      } 
    } 
    return null;
  }
  
  public ViewDataBinding getDataBinder(DataBindingComponent paramDataBindingComponent, View[] paramArrayOfView, int paramInt) {
    if (paramArrayOfView != null) {
      if (paramArrayOfView.length == 0)
        return null; 
      if (INTERNAL_LAYOUT_ID_LOOKUP.get(paramInt) > 0) {
        if (paramArrayOfView[false].getTag() != null)
          return null; 
        throw new RuntimeException("view must have a tag");
      } 
    } 
    return null;
  }
  
  public int getLayoutId(String paramString) {
    if (paramString == null)
      return 0; 
    Integer integer = (Integer)InnerLayoutIdLookup.sKeys.get(paramString);
    return (integer == null) ? 0 : integer.intValue();
  }
}
