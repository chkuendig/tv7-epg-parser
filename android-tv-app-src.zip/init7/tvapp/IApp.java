package ch.andeo.init7.tvapp;

import android.content.Context;
import ch.andeo.init7.core.TvDB;
import com.google.android.exoplayer2.upstream.DataSource;
import org.matomo.sdk.Tracker;

public interface IApp {
  Context getApplicationContext();
  
  DataSource.Factory getDataSourceFactory();
  
  TvDB getDb();
  
  String getLanguageCode();
  
  Tracker getTracker();
}
