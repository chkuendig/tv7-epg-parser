package ch.andeo.init7.tvapp.generated.callback;

import android.view.View;

public final class OnClickListener implements View.OnClickListener {
  final Listener mListener;
  
  final int mSourceId;
  
  public OnClickListener(Listener paramListener, int paramInt) {
    this.mListener = paramListener;
    this.mSourceId = paramInt;
  }
  
  public void onClick(View paramView) { this.mListener._internalCallbackOnClick(this.mSourceId, paramView); }
}
