package ch.andeo.init7.tvapp;

public class DataBindingInfo {}
