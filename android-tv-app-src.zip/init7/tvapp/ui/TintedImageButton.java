package ch.andeo.init7.tvapp.ui;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.widget.TextView;
import androidx.appcompat.widget.AppCompatImageButton;
import ch.andeo.init7.tvapp.R;

public class TintedImageButton extends AppCompatImageButton {
  private int linkedView;
  
  private final int mColorDisabled;
  
  private final int mColorFocused;
  
  private final int mColorNormal;
  
  public TintedImageButton(Context paramContext) { this(paramContext, null); }
  
  public TintedImageButton(Context paramContext, AttributeSet paramAttributeSet) { this(paramContext, paramAttributeSet, 2130903344); }
  
  public TintedImageButton(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    TypedArray typedArray = paramContext.getTheme().obtainStyledAttributes(paramAttributeSet, R.styleable.TintedImageButton, 0, 0);
    this.linkedView = typedArray.getResourceId(3, 0);
    this.mColorNormal = typedArray.getColor(2, -65281);
    this.mColorFocused = typedArray.getColor(1, -65281);
    this.mColorDisabled = typedArray.getColor(0, -65281);
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    if (this.linkedView != 0) {
      TextView textView = (TextView)getRootView().findViewById(this.linkedView);
      if (!isEnabled()) {
        textView.setTextColor(this.mColorDisabled);
        textView.setVisibility(4);
      } else if (isFocused() || isHovered()) {
        textView.setTextColor(this.mColorFocused);
        textView.setVisibility(0);
      } else {
        textView.setTextColor(this.mColorNormal);
        textView.setVisibility(4);
      } 
    } 
    if (!isEnabled()) {
      setColorFilter(this.mColorDisabled);
      return;
    } 
    if (isFocused() || isHovered()) {
      setColorFilter(this.mColorFocused);
      return;
    } 
    setColorFilter(this.mColorNormal);
  }
  
  public void setEnabled(boolean paramBoolean) {
    super.setEnabled(paramBoolean);
    if (this.linkedView != 0)
      getRootView().findViewById(this.linkedView).setEnabled(paramBoolean); 
  }
  
  public void setVisibility(int paramInt) {
    super.setVisibility(paramInt);
    if (this.linkedView != 0)
      getRootView().findViewById(this.linkedView).setVisibility(paramInt); 
  }
}
