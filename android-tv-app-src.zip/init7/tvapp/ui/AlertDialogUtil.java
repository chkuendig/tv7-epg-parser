package ch.andeo.init7.tvapp.ui;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.widget.Button;

public class AlertDialogUtil {
  public static void confirm(Context paramContext, int paramInt, Runnable paramRunnable) { confirm(paramContext, paramInt, paramRunnable, true); }
  
  public static void confirm(Context paramContext, int paramInt1, Runnable paramRunnable, int paramInt2, boolean paramBoolean) { // Byte code:
    //   0: new android/app/AlertDialog$Builder
    //   3: dup
    //   4: aload_0
    //   5: invokespecial <init> : (Landroid/content/Context;)V
    //   8: astore_0
    //   9: aload_0
    //   10: iload_3
    //   11: new ch/andeo/init7/tvapp/ui/-$$Lambda$AlertDialogUtil$U199CEIV8wYMOTdTL5PgPWe0YfQ
    //   14: dup
    //   15: aload_2
    //   16: invokespecial <init> : (Ljava/lang/Runnable;)V
    //   19: invokevirtual setPositiveButton : (ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;
    //   22: pop
    //   23: iload #4
    //   25: ifeq -> 38
    //   28: aload_0
    //   29: ldc 2131689501
    //   31: getstatic ch/andeo/init7/tvapp/ui/-$$Lambda$AlertDialogUtil$8Ifa9gGYUML59_HK6R1R4NPCzTk.INSTANCE : Lch/andeo/init7/tvapp/ui/-$$Lambda$AlertDialogUtil$8Ifa9gGYUML59_HK6R1R4NPCzTk;
    //   34: invokevirtual setNegativeButton : (ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;
    //   37: pop
    //   38: aload_0
    //   39: iload #4
    //   41: invokevirtual setCancelable : (Z)Landroid/app/AlertDialog$Builder;
    //   44: pop
    //   45: aload_0
    //   46: ldc 2131689500
    //   48: invokevirtual setTitle : (I)Landroid/app/AlertDialog$Builder;
    //   51: pop
    //   52: aload_0
    //   53: iload_1
    //   54: invokevirtual setMessage : (I)Landroid/app/AlertDialog$Builder;
    //   57: pop
    //   58: aload_0
    //   59: invokevirtual create : ()Landroid/app/AlertDialog;
    //   62: astore_0
    //   63: aload_0
    //   64: new ch/andeo/init7/tvapp/ui/-$$Lambda$AlertDialogUtil$_yg1s7Ot1R6Im8fxuD4SIf-x-4A
    //   67: dup
    //   68: aload_0
    //   69: invokespecial <init> : (Landroid/app/AlertDialog;)V
    //   72: invokevirtual setOnShowListener : (Landroid/content/DialogInterface$OnShowListener;)V
    //   75: aload_0
    //   76: invokevirtual show : ()V
    //   79: return }
  
  public static void confirm(Context paramContext, int paramInt, Runnable paramRunnable, boolean paramBoolean) { confirm(paramContext, paramInt, paramRunnable, 2131689587, paramBoolean); }
}
