package ch.andeo.init7.tvapp.ui;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import androidx.fragment.app.DialogFragment;
import androidx.lifecycle.MutableLiveData;
import java.util.List;

public class TrackSelectionDialog extends DialogFragment {
  private int trackType;
  
  public TrackSelectionDialog(int paramInt) { this.trackType = paramInt; }
  
  private int getTextResourceForType(int paramInt) {
    if (paramInt != 1) {
      if (paramInt == 3)
        return 2131689598; 
      throw new IllegalArgumentException();
    } 
    return 2131689545;
  }
  
  public Dialog onCreateDialog(Bundle paramBundle) { // Byte code:
    //   0: aload_0
    //   1: invokevirtual getActivity : ()Landroidx/fragment/app/FragmentActivity;
    //   4: ifnull -> 165
    //   7: aload_0
    //   8: invokevirtual getActivity : ()Landroidx/fragment/app/FragmentActivity;
    //   11: invokestatic of : (Landroidx/fragment/app/FragmentActivity;)Landroidx/lifecycle/ViewModelProvider;
    //   14: ldc ch/andeo/init7/tvapp/viewmodels/TrackSelectionViewModel
    //   16: invokevirtual get : (Ljava/lang/Class;)Landroidx/lifecycle/ViewModel;
    //   19: checkcast ch/andeo/init7/tvapp/viewmodels/TrackSelectionViewModel
    //   22: astore_2
    //   23: aload_2
    //   24: aload_0
    //   25: getfield trackType : I
    //   28: invokevirtual getFormats : (I)Landroidx/lifecycle/MutableLiveData;
    //   31: invokevirtual getValue : ()Ljava/lang/Object;
    //   34: checkcast java/util/List
    //   37: astore_1
    //   38: aload_2
    //   39: aload_0
    //   40: getfield trackType : I
    //   43: invokevirtual getOverride : (I)Landroidx/lifecycle/MutableLiveData;
    //   46: astore_2
    //   47: aload_1
    //   48: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   51: pop
    //   52: new java/util/ArrayList
    //   55: dup
    //   56: aload_1
    //   57: invokeinterface size : ()I
    //   62: invokespecial <init> : (I)V
    //   65: astore_3
    //   66: aload_1
    //   67: invokeinterface iterator : ()Ljava/util/Iterator;
    //   72: astore #4
    //   74: aload #4
    //   76: invokeinterface hasNext : ()Z
    //   81: ifeq -> 107
    //   84: aload_3
    //   85: aload #4
    //   87: invokeinterface next : ()Ljava/lang/Object;
    //   92: checkcast ch/andeo/init7/tvapp/exoplayerutil/FormatInfo
    //   95: invokevirtual getDisplayName : ()Ljava/lang/String;
    //   98: invokeinterface add : (Ljava/lang/Object;)Z
    //   103: pop
    //   104: goto -> 74
    //   107: new android/app/AlertDialog$Builder
    //   110: dup
    //   111: aload_0
    //   112: invokevirtual getActivity : ()Landroidx/fragment/app/FragmentActivity;
    //   115: invokespecial <init> : (Landroid/content/Context;)V
    //   118: astore #4
    //   120: aload #4
    //   122: aload_0
    //   123: aload_0
    //   124: getfield trackType : I
    //   127: invokespecial getTextResourceForType : (I)I
    //   130: invokevirtual setTitle : (I)Landroid/app/AlertDialog$Builder;
    //   133: aload_3
    //   134: iconst_0
    //   135: anewarray java/lang/String
    //   138: invokeinterface toArray : ([Ljava/lang/Object;)[Ljava/lang/Object;
    //   143: checkcast [Ljava/lang/CharSequence;
    //   146: new ch/andeo/init7/tvapp/ui/-$$Lambda$TrackSelectionDialog$kBsBXI-G4b1IlFytjLTsrha37lg
    //   149: dup
    //   150: aload_2
    //   151: aload_1
    //   152: invokespecial <init> : (Landroidx/lifecycle/MutableLiveData;Ljava/util/List;)V
    //   155: invokevirtual setItems : ([Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;
    //   158: pop
    //   159: aload #4
    //   161: invokevirtual create : ()Landroid/app/AlertDialog;
    //   164: areturn
    //   165: new java/lang/RuntimeException
    //   168: dup
    //   169: invokespecial <init> : ()V
    //   172: athrow }
}
