package ch.andeo.init7.tvapp.ui;

import android.content.Context;
import android.util.AttributeSet;
import androidx.constraintlayout.widget.ConstraintLayout;

public class MultiStateConstraintLayout extends ConstraintLayout {
  private static final int[] STATE_ACTIVE = { 2130903602 };
  
  private boolean mIsActive = false;
  
  public MultiStateConstraintLayout(Context paramContext) { super(paramContext); }
  
  public MultiStateConstraintLayout(Context paramContext, AttributeSet paramAttributeSet) { super(paramContext, paramAttributeSet); }
  
  public MultiStateConstraintLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt) { super(paramContext, paramAttributeSet, paramInt); }
  
  public boolean getIsActive() { return this.mIsActive; }
  
  protected int[] onCreateDrawableState(int paramInt) {
    int[] arrayOfInt = super.onCreateDrawableState(paramInt + 1);
    if (this.mIsActive)
      mergeDrawableStates(arrayOfInt, STATE_ACTIVE); 
    return arrayOfInt;
  }
  
  public void setIsActive(boolean paramBoolean) {
    this.mIsActive = paramBoolean;
    refreshDrawableState();
  }
}
