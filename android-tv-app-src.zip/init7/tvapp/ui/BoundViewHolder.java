package ch.andeo.init7.tvapp.ui;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import androidx.databinding.ViewDataBinding;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LifecycleRegistry;
import androidx.recyclerview.widget.RecyclerView;
import java.util.Objects;

public class BoundViewHolder<T extends ViewDataBinding> extends RecyclerView.ViewHolder implements LifecycleOwner {
  private LifecycleRegistry lifecycle;
  
  private T rootView;
  
  protected BoundViewHolder(T paramT) {
    super(paramT.getRoot());
    this.rootView = paramT;
  }
  
  public static <T extends ViewDataBinding> BoundViewHolder<T> create(Class<T> paramClass, ViewGroup paramViewGroup) {
    try {
      Object object = paramClass.getMethod("inflate", new Class[] { LayoutInflater.class, ViewGroup.class, boolean.class }).invoke(null, new Object[] { LayoutInflater.from(paramViewGroup.getContext()), paramViewGroup, Boolean.valueOf(false) });
      if (paramClass.isInstance(object))
        return new BoundViewHolder((ViewDataBinding)Objects.requireNonNull(paramClass.cast(object))); 
      throw new RuntimeException("Wrong type created");
    } catch (Exception paramClass) {
      throw new RuntimeException(paramClass);
    } 
  }
  
  public static <T extends ViewDataBinding> T createDataBinding(Class<T> paramClass, ViewGroup paramViewGroup) {
    try {
      Object object = paramClass.getMethod("inflate", new Class[] { LayoutInflater.class, ViewGroup.class, boolean.class }).invoke(null, new Object[] { LayoutInflater.from(paramViewGroup.getContext()), paramViewGroup, Boolean.valueOf(false) });
      if (paramClass.isInstance(object))
        return (T)(ViewDataBinding)Objects.requireNonNull(paramClass.cast(object)); 
      throw new RuntimeException("Wrong type created");
    } catch (Exception paramClass) {
      throw new RuntimeException(paramClass);
    } 
  }
  
  public Lifecycle getLifecycle() { return this.lifecycle; }
  
  public T getRootView() { return (T)this.rootView; }
  
  public boolean isAttached() { return (this.lifecycle != null); }
  
  public void notifyAttached() {
    if (this.lifecycle == null) {
      this.lifecycle = new LifecycleRegistry(this);
      this.lifecycle.setCurrentState(Lifecycle.State.STARTED);
      return;
    } 
    throw new IllegalStateException("Lifecycle already active, but we've been attached");
  }
  
  public void notifyDetached() {
    LifecycleRegistry lifecycleRegistry = this.lifecycle;
    if (lifecycleRegistry != null) {
      lifecycleRegistry.setCurrentState(Lifecycle.State.DESTROYED);
      this.lifecycle = null;
      return;
    } 
    throw new IllegalStateException("Lifecycle already inactive");
  }
}
