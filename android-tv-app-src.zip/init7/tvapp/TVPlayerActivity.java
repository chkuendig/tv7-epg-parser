package ch.andeo.init7.tvapp;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import ch.andeo.init7.core.model.TvChannel;
import ch.andeo.init7.tvapp.androidutil.FragmentTransitionManager;
import ch.andeo.init7.tvapp.fragments.TVPlayerFragment;
import ch.andeo.init7.tvapp.ui.TrackSelectionDialog;
import ch.andeo.init7.tvapp.viewmodels.MediaState;
import io.github.inflationx.viewpump.ViewPumpContextWrapper;
import java.util.Set;

public class TVPlayerActivity extends FragmentActivity {
  private static final String TAG = "TVPlayerActivity";
  
  private long lastButtonInteraction = 0L;
  
  private MediaState mediaState;
  
  private Long playbackPositionCache = null;
  
  private FragmentTransitionManager transitionManager;
  
  TVPlayerFragment tvPlayerFragment;
  
  private void handleAllowedChange(Boolean paramBoolean) {
    if (paramBoolean == null) {
      showForbiddenAlert();
      return;
    } 
    if (!paramBoolean.booleanValue()) {
      showForbiddenAlert();
      return;
    } 
    if (((Boolean)this.mediaState.getSplashVideoDone().getValue()).booleanValue())
      this.mediaState.startOperation(); 
  }
  
  private void handleOperationStatusChange(Boolean paramBoolean) {
    if (!paramBoolean.booleanValue())
      return; 
    paramBoolean = (Boolean)this.mediaState.getAllowed().getValue();
    if (paramBoolean != null && paramBoolean.booleanValue())
      this.mediaState.startOperation(); 
  }
  
  private void showForbiddenAlert() { // Byte code:
    //   0: aload_0
    //   1: ldc 2131689504
    //   3: getstatic ch/andeo/init7/tvapp/-$$Lambda$TVPlayerActivity$LdVGtRL-LqzQaiJmaMOniyRRk98.INSTANCE : Lch/andeo/init7/tvapp/-$$Lambda$TVPlayerActivity$LdVGtRL-LqzQaiJmaMOniyRRk98;
    //   6: ldc 2131689590
    //   8: iconst_0
    //   9: invokestatic confirm : (Landroid/content/Context;ILjava/lang/Runnable;IZ)V
    //   12: return }
  
  protected void attachBaseContext(Context paramContext) { super.attachBaseContext(ViewPumpContextWrapper.wrap(paramContext)); }
  
  public void onBackPressed() { // Byte code:
    //   0: aload_0
    //   1: getfield transitionManager : Lch/andeo/init7/tvapp/androidutil/FragmentTransitionManager;
    //   4: invokevirtual getCurrentFragment : ()Landroidx/fragment/app/Fragment;
    //   7: ifnull -> 18
    //   10: aload_0
    //   11: getfield transitionManager : Lch/andeo/init7/tvapp/androidutil/FragmentTransitionManager;
    //   14: invokevirtual hideAllFragments : ()V
    //   17: return
    //   18: aload_0
    //   19: getfield mediaState : Lch/andeo/init7/tvapp/viewmodels/MediaState;
    //   22: invokevirtual getIsLivePlayback : ()Landroidx/lifecycle/LiveData;
    //   25: invokevirtual getValue : ()Ljava/lang/Object;
    //   28: checkcast java/lang/Boolean
    //   31: invokevirtual booleanValue : ()Z
    //   34: ifeq -> 52
    //   37: aload_0
    //   38: ldc 2131689502
    //   40: new ch/andeo/init7/tvapp/-$$Lambda$YKhAjK5lLjS3sBBusydfSnPK1jE
    //   43: dup
    //   44: aload_0
    //   45: invokespecial <init> : (Lch/andeo/init7/tvapp/TVPlayerActivity;)V
    //   48: invokestatic confirm : (Landroid/content/Context;ILjava/lang/Runnable;)V
    //   51: return
    //   52: aload_0
    //   53: ldc 2131689503
    //   55: new ch/andeo/init7/tvapp/-$$Lambda$TVPlayerActivity$Ks1e4n1H_izSkF5Wo7rBjfdYhe0
    //   58: dup
    //   59: aload_0
    //   60: invokespecial <init> : (Lch/andeo/init7/tvapp/TVPlayerActivity;)V
    //   63: invokestatic confirm : (Landroid/content/Context;ILjava/lang/Runnable;)V
    //   66: return }
  
  protected void onCreate(Bundle paramBundle) { // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokespecial onCreate : (Landroid/os/Bundle;)V
    //   5: aload_0
    //   6: ldc 2131492894
    //   8: invokevirtual setContentView : (I)V
    //   11: aload_0
    //   12: invokevirtual getSupportFragmentManager : ()Landroidx/fragment/app/FragmentManager;
    //   15: astore_2
    //   16: aload_0
    //   17: new ch/andeo/init7/tvapp/androidutil/FragmentTransitionManager
    //   20: dup
    //   21: aload_2
    //   22: invokespecial <init> : (Landroidx/fragment/app/FragmentManager;)V
    //   25: putfield transitionManager : Lch/andeo/init7/tvapp/androidutil/FragmentTransitionManager;
    //   28: aload_0
    //   29: invokestatic getInstance : ()Lch/andeo/init7/tvapp/App;
    //   32: invokevirtual getMediaState : ()Lch/andeo/init7/tvapp/viewmodels/MediaState;
    //   35: putfield mediaState : Lch/andeo/init7/tvapp/viewmodels/MediaState;
    //   38: aload_0
    //   39: getfield mediaState : Lch/andeo/init7/tvapp/viewmodels/MediaState;
    //   42: invokevirtual reset : ()V
    //   45: aload_0
    //   46: getfield mediaState : Lch/andeo/init7/tvapp/viewmodels/MediaState;
    //   49: aload_1
    //   50: invokevirtual restore : (Landroid/os/Bundle;)V
    //   53: aload_0
    //   54: getfield transitionManager : Lch/andeo/init7/tvapp/androidutil/FragmentTransitionManager;
    //   57: ldc 2131296459
    //   59: ldc 2130771997
    //   61: ldc 17432577
    //   63: ldc 2131296458
    //   65: getstatic ch/andeo/init7/tvapp/androidutil/FragmentTransitionManager$VisibilityCondition.BECOMING_HIDDEN : Lch/andeo/init7/tvapp/androidutil/FragmentTransitionManager$VisibilityCondition;
    //   68: invokevirtual addFragment : (IIIILch/andeo/init7/tvapp/androidutil/FragmentTransitionManager$VisibilityCondition;)V
    //   71: aload_0
    //   72: getfield transitionManager : Lch/andeo/init7/tvapp/androidutil/FragmentTransitionManager;
    //   75: ldc 2131296458
    //   77: ldc 17432576
    //   79: ldc 2130772001
    //   81: ldc 2131296459
    //   83: getstatic ch/andeo/init7/tvapp/androidutil/FragmentTransitionManager$VisibilityCondition.BECOMING_VISIBLE : Lch/andeo/init7/tvapp/androidutil/FragmentTransitionManager$VisibilityCondition;
    //   86: invokevirtual addFragment : (IIIILch/andeo/init7/tvapp/androidutil/FragmentTransitionManager$VisibilityCondition;)V
    //   89: aload_0
    //   90: getfield transitionManager : Lch/andeo/init7/tvapp/androidutil/FragmentTransitionManager;
    //   93: ldc 2131296458
    //   95: ldc 2130771994
    //   97: ldc 17432577
    //   99: ldc 2131296459
    //   101: getstatic ch/andeo/init7/tvapp/androidutil/FragmentTransitionManager$VisibilityCondition.BECOMING_HIDDEN : Lch/andeo/init7/tvapp/androidutil/FragmentTransitionManager$VisibilityCondition;
    //   104: invokevirtual addFragment : (IIIILch/andeo/init7/tvapp/androidutil/FragmentTransitionManager$VisibilityCondition;)V
    //   107: aload_0
    //   108: getfield transitionManager : Lch/andeo/init7/tvapp/androidutil/FragmentTransitionManager;
    //   111: ldc 2131296459
    //   113: ldc 17432576
    //   115: ldc 2130771998
    //   117: ldc 2131296458
    //   119: getstatic ch/andeo/init7/tvapp/androidutil/FragmentTransitionManager$VisibilityCondition.BECOMING_VISIBLE : Lch/andeo/init7/tvapp/androidutil/FragmentTransitionManager$VisibilityCondition;
    //   122: invokevirtual addFragment : (IIIILch/andeo/init7/tvapp/androidutil/FragmentTransitionManager$VisibilityCondition;)V
    //   125: aload_0
    //   126: getfield transitionManager : Lch/andeo/init7/tvapp/androidutil/FragmentTransitionManager;
    //   129: ldc 2131296458
    //   131: ldc 2130771997
    //   133: ldc 2130771998
    //   135: invokevirtual addFragment : (III)V
    //   138: aload_0
    //   139: getfield transitionManager : Lch/andeo/init7/tvapp/androidutil/FragmentTransitionManager;
    //   142: ldc 2131296459
    //   144: ldc 2130771997
    //   146: ldc 2130771998
    //   148: invokevirtual addFragment : (III)V
    //   151: aload_0
    //   152: getfield transitionManager : Lch/andeo/init7/tvapp/androidutil/FragmentTransitionManager;
    //   155: ldc 2131296456
    //   157: ldc 2130771995
    //   159: ldc 2130772000
    //   161: invokevirtual addFragment : (III)V
    //   164: aload_0
    //   165: getfield transitionManager : Lch/andeo/init7/tvapp/androidutil/FragmentTransitionManager;
    //   168: ldc 2131296460
    //   170: ldc 2130771996
    //   172: ldc 2130771999
    //   174: invokevirtual addFragment : (III)V
    //   177: aload_0
    //   178: getfield transitionManager : Lch/andeo/init7/tvapp/androidutil/FragmentTransitionManager;
    //   181: invokevirtual initialHide : ()V
    //   184: aload_0
    //   185: aload_2
    //   186: ldc 2131296457
    //   188: invokevirtual findFragmentById : (I)Landroidx/fragment/app/Fragment;
    //   191: checkcast ch/andeo/init7/tvapp/fragments/TVPlayerFragment
    //   194: putfield tvPlayerFragment : Lch/andeo/init7/tvapp/fragments/TVPlayerFragment;
    //   197: new java/util/HashSet
    //   200: dup
    //   201: invokespecial <init> : ()V
    //   204: astore_1
    //   205: aload_1
    //   206: ldc 2131296459
    //   208: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   211: invokeinterface add : (Ljava/lang/Object;)Z
    //   216: pop
    //   217: aload_2
    //   218: invokevirtual getFragments : ()Ljava/util/List;
    //   221: invokeinterface iterator : ()Ljava/util/Iterator;
    //   226: astore_2
    //   227: aload_2
    //   228: invokeinterface hasNext : ()Z
    //   233: ifeq -> 288
    //   236: aload_2
    //   237: invokeinterface next : ()Ljava/lang/Object;
    //   242: checkcast androidx/fragment/app/Fragment
    //   245: astore_3
    //   246: new java/lang/StringBuilder
    //   249: dup
    //   250: invokespecial <init> : ()V
    //   253: astore #4
    //   255: aload #4
    //   257: ldc_w 'Fragment: '
    //   260: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   263: pop
    //   264: aload #4
    //   266: aload_3
    //   267: invokevirtual getClass : ()Ljava/lang/Class;
    //   270: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   273: pop
    //   274: ldc 'TVPlayerActivity'
    //   276: aload #4
    //   278: invokevirtual toString : ()Ljava/lang/String;
    //   281: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   284: pop
    //   285: goto -> 227
    //   288: aload_0
    //   289: ldc 2131296460
    //   291: invokevirtual findViewById : (I)Landroid/view/View;
    //   294: astore_2
    //   295: aload_2
    //   296: ifnonnull -> 311
    //   299: ldc 'TVPlayerActivity'
    //   301: ldc_w 'SettingsF is null'
    //   304: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   307: pop
    //   308: goto -> 366
    //   311: new java/lang/StringBuilder
    //   314: dup
    //   315: invokespecial <init> : ()V
    //   318: astore_3
    //   319: aload_3
    //   320: ldc_w 'SettingsF: '
    //   323: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   326: pop
    //   327: aload_3
    //   328: aload_2
    //   329: invokevirtual getClass : ()Ljava/lang/Class;
    //   332: invokevirtual getName : ()Ljava/lang/String;
    //   335: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   338: pop
    //   339: aload_3
    //   340: ldc_w ', '
    //   343: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   346: pop
    //   347: aload_3
    //   348: aload_2
    //   349: invokevirtual getId : ()I
    //   352: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   355: pop
    //   356: ldc 'TVPlayerActivity'
    //   358: aload_3
    //   359: invokevirtual toString : ()Ljava/lang/String;
    //   362: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   365: pop
    //   366: aload_0
    //   367: getfield mediaState : Lch/andeo/init7/tvapp/viewmodels/MediaState;
    //   370: invokevirtual getCurrentPosition : ()Lch/andeo/init7/tvapp/androidutil/NNMutableLiveData;
    //   373: aload_0
    //   374: new ch/andeo/init7/tvapp/-$$Lambda$TVPlayerActivity$g9WotZp0XIr-FBrqXBvJDRf7gOk
    //   377: dup
    //   378: aload_0
    //   379: aload_1
    //   380: invokespecial <init> : (Lch/andeo/init7/tvapp/TVPlayerActivity;Ljava/util/Set;)V
    //   383: invokevirtual observe : (Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Observer;)V
    //   386: aload_0
    //   387: getfield mediaState : Lch/andeo/init7/tvapp/viewmodels/MediaState;
    //   390: invokevirtual getSplashVideoDone : ()Lch/andeo/init7/tvapp/androidutil/NNMutableLiveData;
    //   393: aload_0
    //   394: new ch/andeo/init7/tvapp/-$$Lambda$TVPlayerActivity$AfmP_Od-QRUAAXv7QwOl5GVmcFI
    //   397: dup
    //   398: aload_0
    //   399: invokespecial <init> : (Lch/andeo/init7/tvapp/TVPlayerActivity;)V
    //   402: invokevirtual observe : (Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Observer;)V
    //   405: aload_0
    //   406: getfield mediaState : Lch/andeo/init7/tvapp/viewmodels/MediaState;
    //   409: invokevirtual getAllowed : ()Landroidx/lifecycle/MutableLiveData;
    //   412: aload_0
    //   413: new ch/andeo/init7/tvapp/-$$Lambda$TVPlayerActivity$34e_Cwju55S1YP0-udlvxazqrFM
    //   416: dup
    //   417: aload_0
    //   418: invokespecial <init> : (Lch/andeo/init7/tvapp/TVPlayerActivity;)V
    //   421: invokevirtual observe : (Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Observer;)V
    //   424: iconst_2
    //   425: ldc_w 'FOCUS'
    //   428: aload_0
    //   429: sipush #2000
    //   432: invokestatic startFocusLogger : (ILjava/lang/String;Landroidx/fragment/app/FragmentActivity;I)V
    //   435: return }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    if (((Boolean)this.mediaState.getSplashVideoDone().getValue()).booleanValue() && this.mediaState.getAllowed().getValue() != null) {
      if (!((Boolean)this.mediaState.getAllowed().getValue()).booleanValue())
        return true; 
      this.lastButtonInteraction = App.CLOCK.millis();
      Fragment fragment = this.transitionManager.getCurrentFragment();
      if (paramInt != 172)
        if (paramInt != 175) {
          if (paramInt != 183) {
            if (paramInt != 233) {
              if (paramInt != 378) {
                StringBuilder stringBuilder;
                switch (paramInt) {
                  default:
                    if (paramInt >= 8 && paramInt <= 16) {
                      this.mediaState.selectChannelIndex(paramInt - 8);
                      return true;
                    } 
                    if (fragment == null) {
                      if (this.tvPlayerFragment.onKeyDown(paramInt, paramKeyEvent))
                        return true; 
                      switch (paramInt) {
                        case 22:
                          showFragment(2131296456);
                          return true;
                        case 21:
                          showFragment(2131296460);
                          return true;
                        case 20:
                        case 23:
                          showFragment(2131296458);
                          return true;
                      } 
                    } else if (((FragmentKeyListener)fragment).onKeyDown(paramInt, paramKeyEvent)) {
                      return true;
                    } 
                    switch (paramInt) {
                      default:
                        stringBuilder = new StringBuilder();
                        stringBuilder.append("Unhandled Key: ");
                        stringBuilder.append(paramInt);
                        Log.d("TVPlayerActivity", stringBuilder.toString());
                        return super.onKeyDown(paramInt, paramKeyEvent);
                      case 184:
                      case 185:
                      case 186:
                        break;
                    } 
                    return true;
                  case 167:
                    this.mediaState.selectChannelOffset(-1);
                    return true;
                  case 166:
                    this.mediaState.selectChannelOffset(1);
                    return true;
                  case 165:
                    break;
                } 
                showFragment(2131296459);
                return true;
              } 
            } else {
              (new TrackSelectionDialog(3)).show(getSupportFragmentManager(), "TRACK_SELECTOR");
              return true;
            } 
          } else {
            this.tvPlayerFragment.reinitPlayer();
            return true;
          } 
        } else {
          (new TrackSelectionDialog(3)).show(getSupportFragmentManager(), "TRACK_SELECTOR");
          return true;
        }  
      showFragment(2131296456);
    } 
    return true;
  }
  
  protected void onRestoreInstanceState(Bundle paramBundle) {
    this.mediaState.restore(paramBundle);
    super.onRestoreInstanceState(paramBundle);
  }
  
  protected void onSaveInstanceState(Bundle paramBundle) {
    this.mediaState.store(paramBundle);
    super.onSaveInstanceState(paramBundle);
  }
  
  protected void onStart() {
    super.onStart();
    Long long = this.playbackPositionCache;
  }
  
  protected void onStop() { super.onStop(); }
  
  public void resetButtonInteraction() { this.lastButtonInteraction = App.CLOCK.millis(); }
  
  public void showFragment(int paramInt) {
    this.transitionManager.showFragment(paramInt);
    Fragment fragment = this.transitionManager.getFragment(paramInt);
    TVPlayerFragment tVPlayerFragment = fragment;
    if (fragment == null)
      tVPlayerFragment = this.tvPlayerFragment; 
    if (tVPlayerFragment instanceof FragmentKeyListener)
      ((FragmentKeyListener)tVPlayerFragment).onFragmentFocused(); 
  }
}
