package ch.andeo.init7.tvapp;

public class BR {
  public static final int _all = 0;
  
  public static final int channelName = 4;
  
  public static final int epg = 5;
  
  public static final int hasReplay = 6;
  
  public static final int livedata = 1;
  
  public static final int showTime = 3;
  
  public static final int vm = 2;
}
