package ch.andeo.init7.tvapp.androidutil;

import android.content.Context;
import android.util.DisplayMetrics;
import androidx.recyclerview.widget.LinearSmoothScroller;

public class CenterSmoothScroller extends LinearSmoothScroller {
  public CenterSmoothScroller(Context paramContext) { super(paramContext); }
  
  public int calculateDtToFit(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) { return paramInt3 + (paramInt4 - paramInt3) / 2 - paramInt1 + (paramInt2 - paramInt1) / 2; }
  
  protected float calculateSpeedPerPixel(DisplayMetrics paramDisplayMetrics) { return 120.0F / paramDisplayMetrics.densityDpi; }
}
