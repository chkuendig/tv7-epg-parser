package ch.andeo.init7.tvapp.androidutil;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MediatorLiveData;

public class MutableLiveDataReference<T> extends MediatorLiveData<T> {
  private LiveData<T> reference = null;
  
  public void postValue(T paramT) { throw new UnsupportedOperationException("Cannot change value"); }
  
  public void setValue(T paramT) { throw new UnsupportedOperationException("Cannot change value"); }
  
  public void updateReference(LiveData<T> paramLiveData) { // Byte code:
    //   0: aload_0
    //   1: getfield reference : Landroidx/lifecycle/LiveData;
    //   4: astore_2
    //   5: aload_1
    //   6: aload_2
    //   7: if_acmpne -> 11
    //   10: return
    //   11: aload_2
    //   12: ifnull -> 20
    //   15: aload_0
    //   16: aload_2
    //   17: invokevirtual removeSource : (Landroidx/lifecycle/LiveData;)V
    //   20: aload_0
    //   21: aload_1
    //   22: putfield reference : Landroidx/lifecycle/LiveData;
    //   25: aload_0
    //   26: aload_0
    //   27: getfield reference : Landroidx/lifecycle/LiveData;
    //   30: new ch/andeo/init7/tvapp/androidutil/-$$Lambda$MutableLiveDataReference$Xj4TjeNXXR6hWqphMv4nTq1f6oU
    //   33: dup
    //   34: aload_0
    //   35: invokespecial <init> : (Lch/andeo/init7/tvapp/androidutil/MutableLiveDataReference;)V
    //   38: invokevirtual addSource : (Landroidx/lifecycle/LiveData;Landroidx/lifecycle/Observer;)V
    //   41: return }
}
