package ch.andeo.init7.tvapp.androidutil;

import androidx.lifecycle.MediatorLiveData;
import java.util.Objects;

public class NNMediatorLiveData<T> extends MediatorLiveData<T> implements NNLiveData<T> {
  private T valueOnNull = null;
  
  public NNMediatorLiveData(T paramT) { setValue(paramT); }
  
  public NNMediatorLiveData(T paramT1, T paramT2) {
    setValue(paramT1);
    this.valueOnNull = paramT2;
  }
  
  public T getValue() {
    Object object2 = super.getValue();
    Object object1 = object2;
    if (object2 == null)
      object1 = this.valueOnNull; 
    return (T)Objects.requireNonNull(object1);
  }
  
  public void postValue(T paramT) {
    T t = paramT;
    if (paramT == null)
      t = (T)this.valueOnNull; 
    super.postValue(t);
  }
  
  public void setValue(T paramT) {
    T t = paramT;
    if (paramT == null)
      t = (T)this.valueOnNull; 
    super.setValue(t);
  }
}
