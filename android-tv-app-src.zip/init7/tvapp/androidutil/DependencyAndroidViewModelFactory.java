package ch.andeo.init7.tvapp.androidutil;

import android.app.Application;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelProviders;
import java.lang.reflect.Constructor;
import java.util.Objects;

public class DependencyAndroidViewModelFactory extends ViewModelProvider.AndroidViewModelFactory {
  private Application mApplication;
  
  private ViewModelProvider provider;
  
  public DependencyAndroidViewModelFactory(Application paramApplication) {
    super(paramApplication);
    this.mApplication = paramApplication;
  }
  
  DependencyAndroidViewModelFactory(Fragment paramFragment) {
    this(((FragmentActivity)Objects.requireNonNull(paramFragment.getActivity())).getApplication());
    this.provider = ViewModelProviders.of((FragmentActivity)Objects.requireNonNull(paramFragment.getActivity()), this);
  }
  
  public <T extends ViewModel> T create(Class<T> paramClass) {
    Constructor[] arrayOfConstructor = paramClass.getConstructors();
    byte b = 0;
    Class[] arrayOfClass = arrayOfConstructor[0].getParameterTypes();
    Object[] arrayOfObject = new Object[arrayOfClass.length];
    while (b < arrayOfClass.length) {
      Class clazz = arrayOfClass[b];
      if (Application.class.isAssignableFrom(clazz)) {
        arrayOfObject[b] = this.mApplication;
      } else {
        arrayOfObject[b] = this.provider.get(clazz);
      } 
      b++;
    } 
    try {
      return (T)(ViewModel)paramClass.getConstructor(arrayOfClass).newInstance(arrayOfObject);
    } catch (Exception paramClass) {
      throw new RuntimeException(paramClass);
    } 
  }
}
