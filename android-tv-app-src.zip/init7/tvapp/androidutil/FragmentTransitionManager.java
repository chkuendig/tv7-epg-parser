package ch.andeo.init7.tvapp.androidutil;

import android.util.Log;
import android.util.SparseArray;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

public class FragmentTransitionManager {
  private static final String TAG = "FragmentTransitionMgr";
  
  private final List<Fragment> fragmentList = new ArrayList();
  
  private final FragmentManager fragmentManager;
  
  private final SparseArray<Fragment> fragmentMap = new SparseArray();
  
  private final List<FragmentTransition> transitions = new ArrayList();
  
  public FragmentTransitionManager(FragmentManager paramFragmentManager) { this.fragmentManager = paramFragmentManager; }
  
  public void addFragment(int paramInt1, int paramInt2, int paramInt3) { addFragment(paramInt1, paramInt2, paramInt3, 0, null); }
  
  public void addFragment(int paramInt1, int paramInt2, int paramInt3, int paramInt4, VisibilityCondition paramVisibilityCondition) {
    if (this.fragmentMap.get(paramInt1) == null) {
      StringBuilder stringBuilder = this.fragmentManager.findFragmentById(paramInt1);
      if (stringBuilder == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Couldn't find fragment with ID: ");
        stringBuilder.append(paramInt1);
        Log.w("FragmentTransitionMgr", stringBuilder.toString());
      } else {
        this.fragmentMap.put(paramInt1, stringBuilder);
        this.fragmentList.add(this.fragmentMap.get(paramInt1));
      } 
    } 
    this.transitions.add(new FragmentTransition(this, paramInt1, paramInt2, paramInt3, paramInt4, paramVisibilityCondition, null));
  }
  
  public Fragment getCurrentFragment() {
    for (Fragment fragment : this.fragmentList) {
      if (fragment.isVisible())
        return fragment; 
    } 
    return null;
  }
  
  public Fragment getFragment(int paramInt) { return (Fragment)this.fragmentMap.get(paramInt); }
  
  public void hideAllFragments() { showFragment(0); }
  
  public void initialHide() {
    FragmentTransaction fragmentTransaction = this.fragmentManager.beginTransaction();
    Iterator iterator = this.fragmentList.iterator();
    while (iterator.hasNext())
      fragmentTransaction.hide((Fragment)iterator.next()); 
    fragmentTransaction.commit();
  }
  
  public void showFragment(int paramInt) {
    HashSet hashSet = new HashSet();
    FragmentTransaction fragmentTransaction = this.fragmentManager.beginTransaction();
    Iterator iterator = this.transitions.iterator();
    while (iterator.hasNext()) {
      FragmentTransition fragmentTransition;
      if (hashSet.contains(Integer.valueOf(fragmentTransition.fragmentId)) || !(fragmentTransition = (FragmentTransition)iterator.next()).access$000(fragmentTransition, paramInt))
        continue; 
      Fragment fragment = (Fragment)this.fragmentMap.get(fragmentTransition.fragmentId);
      if (fragmentTransition.fragmentId == paramInt) {
        if (!fragment.isVisible()) {
          fragmentTransaction.setCustomAnimations(fragmentTransition.enterTransition, fragmentTransition.exitTransition);
          fragmentTransaction.show(fragment);
        } 
      } else if (fragment.isVisible()) {
        fragmentTransaction.setCustomAnimations(fragmentTransition.enterTransition, fragmentTransition.exitTransition);
        fragmentTransaction.hide(fragment);
      } 
      hashSet.add(Integer.valueOf(fragmentTransition.fragmentId));
    } 
    fragmentTransaction.commit();
  }
}
