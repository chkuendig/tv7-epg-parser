package ch.andeo.init7.tvapp.androidutil;

public interface NNLiveData<T> {
  T getValue();
}
