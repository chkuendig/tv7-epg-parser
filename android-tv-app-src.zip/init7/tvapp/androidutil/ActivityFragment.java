package ch.andeo.init7.tvapp.androidutil;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelProviders;

public abstract class ActivityFragment<T extends FragmentActivity> extends Fragment {
  protected abstract Class<T> getActivityClass();
  
  protected T getOwner() {
    if (getActivity() != null) {
      FragmentActivity fragmentActivity = (FragmentActivity)getActivityClass().cast(getActivity());
      if (fragmentActivity != null)
        return (T)fragmentActivity; 
      throw new RuntimeException();
    } 
    throw new RuntimeException();
  }
  
  protected ViewModelProvider getViewModelProvider() { return ViewModelProviders.of(getOwner(), new DependencyAndroidViewModelFactory(this)); }
}
