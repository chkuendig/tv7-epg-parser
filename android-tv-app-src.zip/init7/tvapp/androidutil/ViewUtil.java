package ch.andeo.init7.tvapp.androidutil;

import android.graphics.drawable.RippleDrawable;
import android.view.View;

public class ViewUtil {
  public static void forceRippleAnimation(View paramView) { // Byte code:
    //   0: aload_0
    //   1: invokevirtual getBackground : ()Landroid/graphics/drawable/Drawable;
    //   4: astore_0
    //   5: getstatic android/os/Build$VERSION.SDK_INT : I
    //   8: bipush #21
    //   10: if_icmplt -> 65
    //   13: aload_0
    //   14: instanceof android/graphics/drawable/RippleDrawable
    //   17: ifeq -> 65
    //   20: aload_0
    //   21: checkcast android/graphics/drawable/RippleDrawable
    //   24: astore_0
    //   25: aload_0
    //   26: iconst_2
    //   27: newarray int
    //   29: dup
    //   30: iconst_0
    //   31: ldc 16842919
    //   33: iastore
    //   34: dup
    //   35: iconst_1
    //   36: ldc 16842910
    //   38: iastore
    //   39: invokevirtual setState : ([I)Z
    //   42: pop
    //   43: new android/os/Handler
    //   46: dup
    //   47: invokespecial <init> : ()V
    //   50: new ch/andeo/init7/tvapp/androidutil/-$$Lambda$ViewUtil$-41RSqncwYJtgcLxIAP4761kuZ4
    //   53: dup
    //   54: aload_0
    //   55: invokespecial <init> : (Landroid/graphics/drawable/RippleDrawable;)V
    //   58: ldc2_w 200
    //   61: invokevirtual postDelayed : (Ljava/lang/Runnable;J)Z
    //   64: pop
    //   65: return }
}
