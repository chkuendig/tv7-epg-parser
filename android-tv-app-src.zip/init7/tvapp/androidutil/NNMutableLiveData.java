package ch.andeo.init7.tvapp.androidutil;

import androidx.lifecycle.MutableLiveData;
import java.util.Objects;

public class NNMutableLiveData<T> extends MutableLiveData<T> implements NNLiveData<T> {
  public NNMutableLiveData(T paramT) { setValue(paramT); }
  
  public T getValue() { return (T)Objects.requireNonNull(super.getValue()); }
  
  public void postValue(T paramT) { super.postValue(paramT); }
  
  public void setValue(T paramT) { super.setValue(paramT); }
}
